package com.example.mobilityapp.tracking

import android.content.Context
import android.location.Location
import com.example.mobilityapp.network.MobilityApiService
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RealTimeTrackingService @Inject constructor(
    private val context: Context,
    private val apiService: MobilityApiService
) {
    private var fusedLocationClient: FusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(context)
    private var locationCallback: LocationCallback? = null

    fun trackDriverLocation(rideId: String): Flow<Location> = callbackFlow {
        val locationRequest = LocationRequest.create().apply {
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
            interval = 5000 // Update every 5 seconds
            fastestInterval = 3000
        }

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                locationResult.lastLocation?.let { location ->
                    trySend(location)
                }
            }
        }

        try {
            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback!!,
                context.mainLooper
            )
        } catch (e: SecurityException) {
            close(e)
        }

        awaitClose {
            locationCallback?.let {
                fusedLocationClient.removeLocationUpdates(it)
            }
        }
    }

    suspend fun getDriverLocation(rideId: String): Result<Pair<Double, Double>> {
        return try {
            val response = apiService.getDriverLocation(rideId)
            if (response.isSuccessful) {
                val location = response.body()
                if (location != null) {
                    Result.success(Pair(
                        location["latitude"] ?: 0.0,
                        location["longitude"] ?: 0.0
                    ))
                } else {
                    Result.failure(Exception("No location data available"))
                }
            } else {
                Result.failure(Exception("Failed to get driver location"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun stopTracking() {
        locationCallback?.let {
            fusedLocationClient.removeLocationUpdates(it)
            locationCallback = null
        }
    }
} 