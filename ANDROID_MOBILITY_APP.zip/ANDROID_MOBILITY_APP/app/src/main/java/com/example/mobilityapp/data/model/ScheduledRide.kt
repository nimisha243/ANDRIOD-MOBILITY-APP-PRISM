package com.example.mobilityapp.data.model

import java.util.Date

data class ScheduledRide(
    val id: String,
    val userId: String,
    val pickupLocation: String,
    val dropoffLocation: String,
    val scheduledTime: Date,
    val status: String = "SCHEDULED",
    val vehicleType: String = "STANDARD",
    val estimatedPrice: Double,
    val notes: String? = null,
    val createdAt: Date = Date(),
    val updatedAt: Date = Date()
) 