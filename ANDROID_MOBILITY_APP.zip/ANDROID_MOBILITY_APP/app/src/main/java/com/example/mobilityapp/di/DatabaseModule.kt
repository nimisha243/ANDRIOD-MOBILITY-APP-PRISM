package com.example.mobilityapp.di

import android.content.Context
import androidx.room.Room
import com.example.mobilityapp.data.local.AppDatabase
import com.example.mobilityapp.data.local.PaymentDao
import com.example.mobilityapp.data.local.SavedCardDao
import com.example.mobilityapp.data.local.UserDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideAppDatabase(
        @ApplicationContext context: Context
    ): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "mobility_app.db"
        ).build()
    }

    @Provides
    @Singleton
    fun provideUserDao(database: AppDatabase): UserDao {
        return database.userDao()
    }

    @Provides
    @Singleton
    fun providePaymentDao(database: AppDatabase): PaymentDao {
        return database.paymentDao()
    }

    @Provides
    @Singleton
    fun provideSavedCardDao(database: AppDatabase): SavedCardDao {
        return database.savedCardDao()
    }
} 