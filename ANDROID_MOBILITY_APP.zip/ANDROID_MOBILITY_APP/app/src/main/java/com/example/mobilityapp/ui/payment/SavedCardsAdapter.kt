package com.example.mobilityapp.ui.payment

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.mobilityapp.R
import com.example.mobilityapp.data.model.SavedCard

class SavedCardsAdapter(
    private val onCardSelected: (SavedCard) -> Unit
) : ListAdapter<SavedCard, SavedCardsAdapter.SavedCardViewHolder>(SavedCardDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SavedCardViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_saved_card, parent, false)
        return SavedCardViewHolder(view)
    }

    override fun onBindViewHolder(holder: SavedCardViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class SavedCardViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val cardTypeIcon: ImageView = itemView.findViewById(R.id.cardTypeIcon)
        private val cardNumber: TextView = itemView.findViewById(R.id.cardNumber)
        private val cardholderName: TextView = itemView.findViewById(R.id.cardholderName)
        private val expiryDate: TextView = itemView.findViewById(R.id.expiryDate)
        private val selectedIndicator: ImageView = itemView.findViewById(R.id.selectedIndicator)

        fun bind(card: SavedCard) {
            cardNumber.text = "**** **** **** ${card.lastFourDigits}"
            cardholderName.text = card.cardholderName
            expiryDate.text = "Expires ${card.expiryMonth}/${card.expiryYear}"
            
            // Set card type icon based on cardType
            val iconResId = when (card.cardType.lowercase()) {
                "visa" -> R.drawable.ic_visa
                "mastercard" -> R.drawable.ic_mastercard
                "amex" -> R.drawable.ic_amex
                else -> R.drawable.ic_credit_card
            }
            cardTypeIcon.setImageResource(iconResId)

            // Show/hide selected indicator
            selectedIndicator.visibility = if (card.isDefault) View.VISIBLE else View.GONE

            itemView.setOnClickListener {
                onCardSelected(card)
            }
        }
    }

    private class SavedCardDiffCallback : DiffUtil.ItemCallback<SavedCard>() {
        override fun areItemsTheSame(oldItem: SavedCard, newItem: SavedCard): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: SavedCard, newItem: SavedCard): Boolean {
            return oldItem == newItem
        }
    }
} 