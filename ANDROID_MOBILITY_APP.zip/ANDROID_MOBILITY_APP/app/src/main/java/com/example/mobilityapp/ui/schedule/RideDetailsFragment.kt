package com.example.mobilityapp.ui.schedule

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.mobilityapp.databinding.FragmentRideDetailsBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale

@AndroidEntryPoint
class RideDetailsFragment : Fragment() {

    private var _binding: FragmentRideDetailsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: RideDetailsViewModel by viewModels()
    private val args: RideDetailsFragmentArgs by navArgs()
    private val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRideDetailsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupClickListeners()
        observeViewModel()
        viewModel.loadRide(args.rideId)
        viewModel.startTracking(args.rideId)
    }

    private fun setupClickListeners() {
        binding.cancelButton.setOnClickListener {
            viewModel.cancelRide(args.rideId)
            findNavController().navigateUp()
        }

        binding.payButton.setOnClickListener {
            // TODO: Implement payment flow
            Toast.makeText(requireContext(), "Payment flow coming soon", Toast.LENGTH_SHORT).show()
        }
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.ride.collectLatest { ride ->
                ride?.let {
                    binding.apply {
                        rideIdText.text = "Ride ID: ${it.id}"
                        statusText.text = "Status: ${it.status}"
                        pickupText.text = it.pickupLocation
                        dropoffText.text = it.dropoffLocation
                        timeText.text = dateFormat.format(it.scheduledTime)
                        vehicleText.text = it.vehicleType
                        priceText.text = String.format("$%.2f", it.estimatedPrice)
                        notesText.text = it.notes ?: "No notes"
                    }
                }
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.driverLocation.collectLatest { location ->
                location?.let { (lat, lng) ->
                    binding.trackingStatus.text = "Driver at: $lat, $lng"
                }
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.isLoading.collectLatest { isLoading ->
                binding.trackingProgress.visibility = if (isLoading) View.VISIBLE else View.GONE
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        viewModel.stopTracking()
        _binding = null
    }
} 