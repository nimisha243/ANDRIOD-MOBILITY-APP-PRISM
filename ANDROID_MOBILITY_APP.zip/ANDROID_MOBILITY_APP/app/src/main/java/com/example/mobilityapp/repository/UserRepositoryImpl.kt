package com.example.mobilityapp.repository

import com.example.mobilityapp.auth.AuthManager
import com.example.mobilityapp.data.local.UserDao
import com.example.mobilityapp.data.local.UserEntity
import com.example.mobilityapp.data.remote.ApiService
import com.example.mobilityapp.model.User
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserRepositoryImpl @Inject constructor(
    private val apiService: ApiService,
    private val userDao: UserDao,
    private val authManager: AuthManager
) : UserRepository {

    override fun getUserProfile(): Flow<User> = flow {
        // First emit from local database
        userDao.getUserById(authManager.getToken() ?: throw IllegalStateException("User not logged in"))
            .map { it?.toUser() }
            .catch { e -> emit(null) }
            .collect { user ->
                emit(user)
            }

        // Then fetch from network and update local database
        try {
            val networkUser = apiService.getUserProfile()
            userDao.insertUser(UserEntity.fromUser(networkUser))
            emit(networkUser)
        } catch (e: Exception) {
            // If network fails, we already have local data
            // The error will be handled by the ViewModel
            throw e
        }
    }

    override suspend fun updateUserProfile(user: User): Result<User> {
        return try {
            // Update network first
            val updatedUser = apiService.updateUserProfile(user)
            
            // If network update succeeds, update local database
            userDao.insertUser(UserEntity.fromUser(updatedUser))
            
            Result.success(updatedUser)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun updateUserPreferences(preferences: Map<String, Any>): Result<Unit> {
        return try {
            apiService.updateUserPreferences(preferences)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun logout() {
        try {
            apiService.logout()
        } finally {
            // Clear local data and auth token regardless of network success
            userDao.deleteAllUsers()
            authManager.clearToken()
        }
    }
} 