package com.example.mobilityapp.ui.schedule

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mobilityapp.data.model.ScheduledRide
import com.example.mobilityapp.repository.RideRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.Date
import java.util.UUID
import javax.inject.Inject

@HiltViewModel
class ScheduleRideViewModel @Inject constructor(
    private val rideRepository: RideRepository
) : ViewModel() {

    private val _estimatedPrice = MutableStateFlow(0.0)
    val estimatedPrice: StateFlow<Double> = _estimatedPrice

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _scheduleResult = MutableStateFlow<Result<ScheduledRide>?>(null)
    val scheduleResult: StateFlow<Result<ScheduledRide>?> = _scheduleResult

    fun calculateEstimatedPrice(pickup: String, dropoff: String, vehicleType: String) {
        // Simple price calculation based on vehicle type
        val basePrice = when (vehicleType) {
            "STANDARD" -> 15.0
            "PREMIUM" -> 25.0
            "LUXURY" -> 40.0
            else -> 15.0
        }
        
        // Add some randomness to simulate real pricing
        val randomFactor = 0.8 + (Math.random() * 0.4)
        _estimatedPrice.value = basePrice * randomFactor
    }

    fun scheduleRide(
        userId: String,
        pickupLocation: String,
        dropoffLocation: String,
        scheduledTime: Date,
        vehicleType: String,
        notes: String?
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val ride = ScheduledRide(
                    id = UUID.randomUUID().toString(),
                    userId = userId,
                    pickupLocation = pickupLocation,
                    dropoffLocation = dropoffLocation,
                    scheduledTime = scheduledTime,
                    vehicleType = vehicleType,
                    estimatedPrice = _estimatedPrice.value,
                    notes = notes
                )
                
                val result = rideRepository.scheduleRide(ride)
                _scheduleResult.value = result
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun resetScheduleResult() {
        _scheduleResult.value = null
    }
} 