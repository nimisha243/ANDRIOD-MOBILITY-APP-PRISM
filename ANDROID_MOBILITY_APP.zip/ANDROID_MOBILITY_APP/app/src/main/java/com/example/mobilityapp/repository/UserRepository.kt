package com.example.mobilityapp.repository

import com.example.mobilityapp.model.User
import kotlinx.coroutines.flow.Flow

interface UserRepository {
    fun getUserProfile(): Flow<User>
    suspend fun updateUserProfile(user: User): Result<User>
    suspend fun updateUserPreferences(preferences: Map<String, Any>): Result<Unit>
    suspend fun logout()
} 