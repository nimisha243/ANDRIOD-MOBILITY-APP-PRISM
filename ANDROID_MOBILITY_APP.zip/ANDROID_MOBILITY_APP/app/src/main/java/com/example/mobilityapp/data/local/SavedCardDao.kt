package com.example.mobilityapp.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedCardDao {
    @Query("SELECT * FROM saved_cards WHERE userId = :userId")
    fun getSavedCardsByUserId(userId: String): Flow<List<SavedCardEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCard(card: SavedCardEntity)

    @Update
    suspend fun updateCard(card: SavedCardEntity)

    @Delete
    suspend fun deleteCard(card: SavedCardEntity)

    @Query("SELECT * FROM saved_cards WHERE id = :cardId")
    suspend fun getCardById(cardId: String): SavedCardEntity?

    @Query("UPDATE saved_cards SET isDefault = 0 WHERE userId = :userId")
    suspend fun clearDefaultCards(userId: String)

    @Query("UPDATE saved_cards SET isDefault = 1 WHERE id = :cardId AND userId = :userId")
    suspend fun setDefaultCard(cardId: String, userId: String)
} 