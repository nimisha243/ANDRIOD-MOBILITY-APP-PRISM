package com.example.mobilityapp.data.model

data class SavedCard(
    val id: String,
    val cardType: String,
    val lastFourDigits: String,
    val cardholderName: String,
    val expiryMonth: String,
    val expiryYear: String,
    val isDefault: Boolean = false
) 