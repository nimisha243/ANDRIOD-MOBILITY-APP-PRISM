package com.example.mobilityapp.network

import com.example.mobilityapp.data.model.ScheduledRide
import retrofit2.Response
import retrofit2.http.*

interface MobilityApiService {
    @GET("rides")
    suspend fun getScheduledRides(): Response<List<ScheduledRide>>

    @GET("rides/{rideId}")
    suspend fun getRideById(@Path("rideId") rideId: String): Response<ScheduledRide>

    @POST("rides")
    suspend fun scheduleRide(@Body ride: ScheduledRide): Response<ScheduledRide>

    @DELETE("rides/{rideId}")
    suspend fun cancelRide(@Path("rideId") rideId: String): Response<Unit>

    @PUT("rides/{rideId}/status")
    suspend fun updateRideStatus(
        @Path("rideId") rideId: String,
        @Body status: Map<String, String>
    ): Response<ScheduledRide>

    @GET("rides/{rideId}/tracking")
    suspend fun getDriverLocation(@Path("rideId") rideId: String): Response<Map<String, Double>>

    @POST("rides/{rideId}/payment")
    suspend fun processPayment(
        @Path("rideId") rideId: String,
        @Body paymentInfo: Map<String, Any>
    ): Response<Map<String, Any>>
} 