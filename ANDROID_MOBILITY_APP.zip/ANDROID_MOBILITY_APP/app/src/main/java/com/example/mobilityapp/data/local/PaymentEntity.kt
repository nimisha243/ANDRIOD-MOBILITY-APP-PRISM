package com.example.mobilityapp.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.mobilityapp.model.PaymentDetails
import com.example.mobilityapp.model.PaymentMethod
import com.example.mobilityapp.model.PaymentStatus
import java.util.Date

@Entity(tableName = "payments")
data class PaymentEntity(
    @PrimaryKey
    val id: String,
    val journeyId: String,
    val amount: Double,
    val currency: String,
    val status: PaymentStatus,
    val paymentMethod: PaymentMethod,
    val timestamp: Date,
    val cardLastFourDigits: String?,
    val transactionId: String?
) {
    fun toPaymentDetails() = PaymentDetails(
        id = id,
        journeyId = journeyId,
        amount = amount,
        currency = currency,
        status = status,
        paymentMethod = paymentMethod,
        timestamp = timestamp,
        cardLastFourDigits = cardLastFourDigits,
        transactionId = transactionId
    )

    companion object {
        fun fromPaymentDetails(paymentDetails: PaymentDetails) = PaymentEntity(
            id = paymentDetails.id,
            journeyId = paymentDetails.journeyId,
            amount = paymentDetails.amount,
            currency = paymentDetails.currency,
            status = paymentDetails.status,
            paymentMethod = paymentDetails.paymentMethod,
            timestamp = paymentDetails.timestamp,
            cardLastFourDigits = paymentDetails.cardLastFourDigits,
            transactionId = paymentDetails.transactionId
        )
    }
} 