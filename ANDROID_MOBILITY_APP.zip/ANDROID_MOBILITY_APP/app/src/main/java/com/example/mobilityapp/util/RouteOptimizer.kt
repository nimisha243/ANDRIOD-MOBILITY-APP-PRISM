package com.example.mobilityapp.util

import com.example.mobilityapp.data.model.LocationUpdate
import com.example.mobilityapp.data.model.Route
import com.google.android.gms.maps.model.LatLng
import com.google.maps.DirectionsApi
import com.google.maps.GeoApiContext
import com.google.maps.model.DirectionsResult
import com.google.maps.model.TravelMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RouteOptimizer @Inject constructor(
    private val geoApiContext: GeoApiContext
) {
    suspend fun optimizeRoute(
        start: LocationUpdate,
        end: LocationUpdate,
        waypoints: List<LocationUpdate> = emptyList()
    ): Route = withContext(Dispatchers.IO) {
        try {
            val origin = LatLng(start.latitude, start.longitude)
            val destination = LatLng(end.latitude, end.longitude)
            
            val waypointsList = waypoints.map { 
                com.google.maps.model.LatLng(it.latitude, it.longitude) 
            }.toTypedArray()

            val result = DirectionsApi.newRequest(geoApiContext)
                .origin(com.google.maps.model.LatLng(origin.latitude, origin.longitude))
                .destination(com.google.maps.model.LatLng(destination.latitude, destination.longitude))
                .waypoints(*waypointsList)
                .mode(TravelMode.DRIVING)
                .optimizeWaypoints(true)
                .await()

            createRouteFromDirectionsResult(result, start, end, waypoints)
        } catch (e: Exception) {
            throw RouteOptimizationException("Failed to optimize route: ${e.message}")
        }
    }

    private fun createRouteFromDirectionsResult(
        result: DirectionsResult,
        start: LocationUpdate,
        end: LocationUpdate,
        waypoints: List<LocationUpdate>
    ): Route {
        val route = result.routes[0]
        val leg = route.legs[0]

        return Route(
            id = java.util.UUID.randomUUID().toString(),
            startLocation = start,
            endLocation = end,
            waypoints = waypoints,
            distance = leg.distance.inMeters.toFloat(),
            duration = leg.duration.inSeconds * 1000L,
            polyline = route.overviewPolyline.encodedPath
        )
    }
}

class RouteOptimizationException(message: String) : Exception(message) 