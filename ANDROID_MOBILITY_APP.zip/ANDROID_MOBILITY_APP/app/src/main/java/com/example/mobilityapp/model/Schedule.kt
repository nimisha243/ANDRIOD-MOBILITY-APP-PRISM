package com.example.mobilityapp.model

import java.util.Date

data class Schedule(
    val id: String,
    val date: Date,
    val startLocation: String,
    val endLocation: String,
    val status: ScheduleStatus,
    val recurring: Boolean = false,
    val recurringDays: List<Int> = emptyList() // 1 = Monday, 7 = Sunday
)

enum class ScheduleStatus {
    PENDING,
    COMPLETED,
    CANCELLED
} 