package com.example.mobilityapp.di

import com.example.mobilityapp.data.repository.JourneyRepository
import com.example.mobilityapp.data.repository.MockJourneyRepository
import com.example.mobilityapp.data.repository.MockNotificationRepository
import com.example.mobilityapp.data.repository.MockScheduleRepository
import com.example.mobilityapp.data.repository.NotificationRepository
import com.example.mobilityapp.data.repository.ScheduleRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindJourneyRepository(
        mockJourneyRepository: MockJourneyRepository
    ): JourneyRepository

    @Binds
    @Singleton
    abstract fun bindNotificationRepository(
        mockNotificationRepository: MockNotificationRepository
    ): NotificationRepository

    @Binds
    @Singleton
    abstract fun bindScheduleRepository(
        mockScheduleRepository: MockScheduleRepository
    ): ScheduleRepository
} 