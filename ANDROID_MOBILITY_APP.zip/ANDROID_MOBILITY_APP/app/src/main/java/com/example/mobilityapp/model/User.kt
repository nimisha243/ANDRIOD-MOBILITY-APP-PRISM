package com.example.mobilityapp.model

data class User(
    val id: String,
    val name: String,
    val email: String,
    val phoneNumber: String,
    val profilePictureUrl: String? = null,
    val address: String? = null,
    val emergencyContact: String? = null,
    val preferredPaymentMethod: String? = null
) 