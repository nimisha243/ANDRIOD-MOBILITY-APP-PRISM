package com.example.mobilityapp.ui.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.mobilityapp.R
import com.example.mobilityapp.model.Notification
import java.text.SimpleDateFormat
import java.util.Locale

class NotificationAdapter : ListAdapter<Notification, NotificationAdapter.NotificationViewHolder>(NotificationDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotificationViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_notification, parent, false)
        return NotificationViewHolder(view)
    }

    override fun onBindViewHolder(holder: NotificationViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class NotificationViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val iconView: ImageView = itemView.findViewById(R.id.notification_icon)
        private val titleText: TextView = itemView.findViewById(R.id.notification_title)
        private val messageText: TextView = itemView.findViewById(R.id.notification_message)
        private val timeText: TextView = itemView.findViewById(R.id.notification_time)
        private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

        fun bind(notification: Notification) {
            titleText.text = notification.title
            messageText.text = notification.message
            timeText.text = timeFormat.format(notification.timestamp)
            
            // Set icon based on notification type
            val iconRes = when (notification.type) {
                NotificationType.JOURNEY -> R.drawable.ic_directions
                NotificationType.PAYMENT -> R.drawable.ic_credit_card
                NotificationType.SYSTEM -> R.drawable.ic_notifications
            }
            iconView.setImageResource(iconRes)
        }
    }

    private class NotificationDiffCallback : DiffUtil.ItemCallback<Notification>() {
        override fun areItemsTheSame(oldItem: Notification, newItem: Notification): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Notification, newItem: Notification): Boolean {
            return oldItem == newItem
        }
    }
} 