package com.example.mobilityapp.data.remote

import com.example.mobilityapp.model.User
import retrofit2.http.*

interface ApiService {
    @GET("users/profile")
    suspend fun getUserProfile(): User

    @PUT("users/profile")
    suspend fun updateUserProfile(@Body user: User): User

    @PUT("users/preferences")
    suspend fun updateUserPreferences(@Body preferences: Map<String, Any>)

    @POST("auth/logout")
    suspend fun logout()
} 