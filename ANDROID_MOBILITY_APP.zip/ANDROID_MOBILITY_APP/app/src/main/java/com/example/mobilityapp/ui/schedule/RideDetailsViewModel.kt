package com.example.mobilityapp.ui.schedule

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mobilityapp.data.model.ScheduledRide
import com.example.mobilityapp.repository.RideRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class RideDetailsViewModel @Inject constructor(
    private val rideRepository: RideRepository
) : ViewModel() {

    private val _ride = MutableStateFlow<ScheduledRide?>(null)
    val ride: StateFlow<ScheduledRide?> = _ride

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _driverLocation = MutableStateFlow<Pair<Double, Double>?>(null)
    val driverLocation: StateFlow<Pair<Double, Double>?> = _driverLocation

    fun loadRide(rideId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                // In a real app, this would be a single ride query
                rideRepository.getScheduledRides().collect { rides ->
                    _ride.value = rides.find { it.id == rideId }
                }
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun cancelRide(rideId: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                rideRepository.cancelScheduledRide(rideId)
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun startTracking(rideId: String) {
        viewModelScope.launch {
            // Simulate real-time tracking updates
            // In a real app, this would connect to a WebSocket or similar
            while (true) {
                kotlinx.coroutines.delay(5000)
                _driverLocation.value = Pair(
                    40.7128 + (Math.random() - 0.5) * 0.1,
                    -74.0060 + (Math.random() - 0.5) * 0.1
                )
            }
        }
    }

    fun stopTracking() {
        // Cancel any tracking coroutines
        viewModelScope.launch {
            _driverLocation.value = null
        }
    }
} 