package com.example.mobilityapp.model

import java.util.Date

data class SavedCard(
    val id: String,
    val userId: String,
    val cardNumber: String, // Last 4 digits only
    val cardType: CardType,
    val expiryMonth: Int,
    val expiryYear: Int,
    val cardholderName: String,
    val isDefault: Boolean = false,
    val addedDate: Date = Date()
)

enum class CardType {
    VISA,
    MASTERCARD,
    AMEX,
    DISCOVER,
    JCB,
    DINERS_CLUB,
    UNKNOWN
} 