package com.example.mobilityapp.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.mobilityapp.model.CardType
import com.example.mobilityapp.model.SavedCard
import java.util.Date

@Entity(tableName = "saved_cards")
data class SavedCardEntity(
    @PrimaryKey
    val id: String,
    val userId: String,
    val cardNumber: String,
    val cardType: CardType,
    val expiryMonth: Int,
    val expiryYear: Int,
    val cardholderName: String,
    val isDefault: Boolean,
    val addedDate: Date
) {
    fun toSavedCard() = SavedCard(
        id = id,
        userId = userId,
        cardNumber = cardNumber,
        cardType = cardType,
        expiryMonth = expiryMonth,
        expiryYear = expiryYear,
        cardholderName = cardholderName,
        isDefault = isDefault,
        addedDate = addedDate
    )

    companion object {
        fun fromSavedCard(savedCard: SavedCard) = SavedCardEntity(
            id = savedCard.id,
            userId = savedCard.userId,
            cardNumber = savedCard.cardNumber,
            cardType = savedCard.cardType,
            expiryMonth = savedCard.expiryMonth,
            expiryYear = savedCard.expiryYear,
            cardholderName = savedCard.cardholderName,
            isDefault = savedCard.isDefault,
            addedDate = savedCard.addedDate
        )
    }
} 