package com.example.mobilityapp.model

import java.util.Date

data class PaymentDetails(
    val id: String,
    val journeyId: String,
    val amount: Double,
    val currency: String = "USD",
    val status: PaymentStatus = PaymentStatus.PENDING,
    val paymentMethod: PaymentMethod = PaymentMethod.CREDIT_CARD,
    val timestamp: Date = Date(),
    val cardLastFourDigits: String? = null,
    val transactionId: String? = null
)

enum class PaymentStatus {
    PENDING,
    PROCESSING,
    COMPLETED,
    FAILED,
    REFUNDED
}

enum class PaymentMethod {
    CREDIT_CARD,
    SAMSUNG_PAY,
    GOOGLE_PAY,
    APPLE_PAY
} 