package com.example.mobilityapp.model

import java.util.Date

data class Notification(
    val id: String,
    val title: String,
    val message: String,
    val timestamp: Date,
    val type: NotificationType
)

enum class NotificationType {
    JOURNEY,
    PAYMENT,
    SYSTEM
} 