package com.example.mobilityapp.data.remote

import com.example.mobilityapp.model.PaymentDetails
import com.example.mobilityapp.model.SavedCard
import retrofit2.http.*

interface PaymentApiService {
    @GET("payments/{journeyId}")
    suspend fun getPaymentDetails(@Path("journeyId") journeyId: String): PaymentDetails

    @GET("cards")
    suspend fun getSavedCards(): List<SavedCard>

    @POST("cards")
    suspend fun saveCard(@Body card: SavedCard): SavedCard

    @DELETE("cards/{cardId}")
    suspend fun deleteCard(@Path("cardId") cardId: String)

    @POST("payments/credit-card")
    suspend fun processCreditCardPayment(
        @Body request: CreditCardPaymentRequest
    ): PaymentDetails

    @POST("payments/samsung-pay")
    suspend fun processSamsungPayPayment(
        @Body request: SamsungPayPaymentRequest
    ): PaymentDetails

    @GET("payments/samsung-pay/availability")
    suspend fun checkSamsungPayAvailability(): SamsungPayAvailabilityResponse
}

data class CreditCardPaymentRequest(
    val cardId: String,
    val amount: Double,
    val currency: String = "USD",
    val journeyId: String
)

data class SamsungPayPaymentRequest(
    val amount: Double,
    val currency: String = "USD",
    val journeyId: String
)

data class SamsungPayAvailabilityResponse(
    val isAvailable: Boolean,
    val reason: String? = null
) 