package com.example.mobilityapp.ui.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.mobilityapp.R
import com.example.mobilityapp.model.Journey
import java.text.SimpleDateFormat
import java.util.Locale

class JourneyAdapter : ListAdapter<Journey, JourneyAdapter.JourneyViewHolder>(JourneyDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JourneyViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_journey, parent, false)
        return JourneyViewHolder(view)
    }

    override fun onBindViewHolder(holder: JourneyViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class JourneyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val dateText: TextView = itemView.findViewById(R.id.journey_date)
        private val statusText: TextView = itemView.findViewById(R.id.journey_status)
        private val distanceText: TextView = itemView.findViewById(R.id.journey_distance)
        private val fareText: TextView = itemView.findViewById(R.id.journey_fare)
        private val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())

        fun bind(journey: Journey) {
            dateText.text = dateFormat.format(journey.date)
            statusText.text = journey.status.name
            distanceText.text = itemView.context.getString(R.string.journey_distance, journey.distance)
            fareText.text = itemView.context.getString(R.string.journey_fare, journey.fare)
        }
    }

    private class JourneyDiffCallback : DiffUtil.ItemCallback<Journey>() {
        override fun areItemsTheSame(oldItem: Journey, newItem: Journey): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Journey, newItem: Journey): Boolean {
            return oldItem == newItem
        }
    }
} 