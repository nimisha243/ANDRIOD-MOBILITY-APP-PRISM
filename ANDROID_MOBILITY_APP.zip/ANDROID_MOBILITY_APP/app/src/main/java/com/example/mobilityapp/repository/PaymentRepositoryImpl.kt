package com.example.mobilityapp.repository

import com.example.mobilityapp.auth.AuthManager
import com.example.mobilityapp.data.local.PaymentDao
import com.example.mobilityapp.data.local.PaymentEntity
import com.example.mobilityapp.data.local.SavedCardDao
import com.example.mobilityapp.data.local.SavedCardEntity
import com.example.mobilityapp.data.remote.CreditCardPaymentRequest
import com.example.mobilityapp.data.remote.PaymentApiService
import com.example.mobilityapp.data.remote.SamsungPayPaymentRequest
import com.example.mobilityapp.model.PaymentDetails
import com.example.mobilityapp.model.SavedCard
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PaymentRepositoryImpl @Inject constructor(
    private val paymentApiService: PaymentApiService,
    private val paymentDao: PaymentDao,
    private val savedCardDao: SavedCardDao,
    private val authManager: AuthManager
) : PaymentRepository {

    override fun getPaymentDetails(journeyId: String): Flow<PaymentDetails> {
        return paymentDao.getPaymentByJourneyId(journeyId)
            .map { it?.toPaymentDetails() }
            .catch { e -> emit(null) }
    }

    override fun getSavedCards(): Flow<List<SavedCard>> {
        val userId = authManager.getToken() ?: throw IllegalStateException("User not logged in")
        return savedCardDao.getSavedCardsByUserId(userId)
            .map { entities -> entities.map { it.toSavedCard() } }
    }

    override suspend fun saveCard(card: SavedCard): Result<SavedCard> {
        return try {
            // Save to network first
            val savedCard = paymentApiService.saveCard(card)
            
            // If network save succeeds, save to local database
            savedCardDao.insertCard(SavedCardEntity.fromSavedCard(savedCard))
            
            Result.success(savedCard)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteCard(card: SavedCard): Result<Unit> {
        return try {
            // Delete from network first
            paymentApiService.deleteCard(card.id)
            
            // If network delete succeeds, delete from local database
            savedCardDao.deleteCard(SavedCardEntity.fromSavedCard(card))
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun processCreditCardPayment(card: SavedCard, amount: Double): Result<PaymentDetails> {
        return try {
            val journeyId = "journey_${System.currentTimeMillis()}" // This should come from the journey service
            
            val request = CreditCardPaymentRequest(
                cardId = card.id,
                amount = amount,
                journeyId = journeyId
            )
            
            // Process payment through API
            val paymentDetails = paymentApiService.processCreditCardPayment(request)
            
            // Save payment details to local database
            paymentDao.insertPayment(PaymentEntity.fromPaymentDetails(paymentDetails))
            
            Result.success(paymentDetails)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun processSamsungPayPayment(amount: Double): Result<PaymentDetails> {
        return try {
            val journeyId = "journey_${System.currentTimeMillis()}" // This should come from the journey service
            
            val request = SamsungPayPaymentRequest(
                amount = amount,
                journeyId = journeyId
            )
            
            // Process payment through API
            val paymentDetails = paymentApiService.processSamsungPayPayment(request)
            
            // Save payment details to local database
            paymentDao.insertPayment(PaymentEntity.fromPaymentDetails(paymentDetails))
            
            Result.success(paymentDetails)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun isSamsungPayAvailable(): Boolean {
        return try {
            val response = paymentApiService.checkSamsungPayAvailability()
            response.isAvailable
        } catch (e: Exception) {
            false
        }
    }
} 