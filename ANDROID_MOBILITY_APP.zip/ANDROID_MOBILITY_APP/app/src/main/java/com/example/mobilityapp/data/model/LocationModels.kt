package com.example.mobilityapp.data.model

data class LocationUpdate(
    val latitude: Double,
    val longitude: Double,
    val accuracy: Float,
    val timestamp: Long,
    val speed: Float,
    val bearing: Float
)

data class Geofence(
    val id: String,
    val latitude: Double,
    val longitude: Double,
    val radius: Float,
    val name: String? = null,
    val description: String? = null
)

sealed class GeofencingEvent {
    data class Enter(val geofenceId: String) : GeofencingEvent()
    data class Exit(val geofenceId: String) : GeofencingEvent()
}

data class Route(
    val id: String,
    val startLocation: LocationUpdate,
    val endLocation: LocationUpdate,
    val waypoints: List<LocationUpdate> = emptyList(),
    val distance: Float,
    val duration: Long,
    val polyline: String
)

data class LocationHistory(
    val id: String,
    val locationUpdates: List<LocationUpdate>,
    val startTime: Long,
    val endTime: Long,
    val distance: Float,
    val averageSpeed: Float
) 