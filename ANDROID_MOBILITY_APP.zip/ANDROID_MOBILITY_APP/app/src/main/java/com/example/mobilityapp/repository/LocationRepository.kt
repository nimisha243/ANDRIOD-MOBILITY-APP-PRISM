package com.example.mobilityapp.repository

import com.example.mobilityapp.data.model.*
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

interface LocationRepository {
    suspend fun saveLocationUpdate(locationUpdate: LocationUpdate)
    fun getLocationUpdates(): Flow<List<LocationUpdate>>
    suspend fun saveGeofence(geofence: Geofence)
    suspend fun removeGeofence(geofenceId: String)
    fun getGeofences(): Flow<List<Geofence>>
    suspend fun saveRoute(route: Route)
    fun getRoutes(): Flow<List<Route>>
    suspend fun saveLocationHistory(locationHistory: LocationHistory)
    fun getLocationHistory(): Flow<List<LocationHistory>>
    suspend fun optimizeRoute(start: LocationUpdate, end: LocationUpdate): Route
}

@Singleton
class LocationRepositoryImpl @Inject constructor(
    private val locationDao: LocationDao,
    private val routeOptimizer: RouteOptimizer
) : LocationRepository {

    override suspend fun saveLocationUpdate(locationUpdate: LocationUpdate) {
        locationDao.insertLocationUpdate(locationUpdate)
    }

    override fun getLocationUpdates(): Flow<List<LocationUpdate>> {
        return locationDao.getLocationUpdates()
    }

    override suspend fun saveGeofence(geofence: Geofence) {
        locationDao.insertGeofence(geofence)
    }

    override suspend fun removeGeofence(geofenceId: String) {
        locationDao.deleteGeofence(geofenceId)
    }

    override fun getGeofences(): Flow<List<Geofence>> {
        return locationDao.getGeofences()
    }

    override suspend fun saveRoute(route: Route) {
        locationDao.insertRoute(route)
    }

    override fun getRoutes(): Flow<List<Route>> {
        return locationDao.getRoutes()
    }

    override suspend fun saveLocationHistory(locationHistory: LocationHistory) {
        locationDao.insertLocationHistory(locationHistory)
    }

    override fun getLocationHistory(): Flow<List<LocationHistory>> {
        return locationDao.getLocationHistory()
    }

    override suspend fun optimizeRoute(start: LocationUpdate, end: LocationUpdate): Route {
        return routeOptimizer.optimizeRoute(start, end)
    }
} 