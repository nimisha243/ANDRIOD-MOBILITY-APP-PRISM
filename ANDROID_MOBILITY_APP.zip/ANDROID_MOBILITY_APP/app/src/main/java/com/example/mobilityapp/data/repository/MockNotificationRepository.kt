package com.example.mobilityapp.data.repository

import com.example.mobilityapp.model.Notification
import com.example.mobilityapp.model.NotificationType
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.util.Date
import java.util.UUID
import javax.inject.Inject

class MockNotificationRepository @Inject constructor() : NotificationRepository {
    private val notifications = mutableListOf<Notification>()

    init {
        // Add some mock data
        notifications.addAll(listOf(
            Notification(
                id = UUID.randomUUID().toString(),
                title = "Journey Completed",
                message = "Your journey from Home to Work has been completed",
                timestamp = Date(),
                type = NotificationType.JOURNEY
            ),
            Notification(
                id = UUID.randomUUID().toString(),
                title = "Payment Successful",
                message = "Payment of $25.00 has been processed",
                timestamp = Date(),
                type = NotificationType.PAYMENT
            )
        ))
    }

    override fun getNotifications(): Flow<List<Notification>> = flow {
        while (true) {
            emit(notifications.sortedByDescending { it.timestamp })
            delay(1000) // Simulate network delay
        }
    }

    override suspend fun markAsRead(notificationId: String) {
        val index = notifications.indexOfFirst { it.id == notificationId }
        if (index != -1) {
            notifications.removeAt(index)
        }
    }

    override suspend fun clearAllNotifications() {
        notifications.clear()
    }
} 