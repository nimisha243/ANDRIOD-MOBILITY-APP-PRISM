package com.example.mobilityapp.ui.location

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import com.example.mobilityapp.R
import com.example.mobilityapp.databinding.FragmentLocationBinding
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.snackbar.Snackbar
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class LocationFragment : Fragment(), OnMapReadyCallback {

    private var _binding: FragmentLocationBinding? = null
    private val binding get() = _binding!!

    private val viewModel: LocationViewModel by viewModels()
    private var googleMap: GoogleMap? = null

    private val locationPermissionRequest = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        when {
            permissions.getOrDefault(Manifest.permission.ACCESS_FINE_LOCATION, false) ||
            permissions.getOrDefault(Manifest.permission.ACCESS_COARSE_LOCATION, false) -> {
                // Location permissions granted, start location updates
                setupLocationUpdates()
            }
            else -> {
                Snackbar.make(
                    binding.root,
                    "Location permission is required for this feature",
                    Snackbar.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLocationBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupMap()
        setupObservers()
        checkLocationPermission()
    }

    private fun setupMap() {
        val mapFragment = childFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    private fun setupObservers() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.locationState.collectLatest { state ->
                handleLocationState(state)
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.currentLocation.collectLatest { location ->
                location?.let { updateMapLocation(it) }
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.geofences.collectLatest { geofences ->
                updateGeofencesOnMap(geofences)
            }
        }
    }

    private fun checkLocationPermission() {
        when {
            ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED -> {
                setupLocationUpdates()
            }
            else -> {
                locationPermissionRequest.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
            }
        }
    }

    private fun setupLocationUpdates() {
        viewModel.startLocationTracking()
    }

    private fun handleLocationState(state: LocationState) {
        when (state) {
            is LocationState.Loading -> {
                binding.progressBar.visibility = View.VISIBLE
            }
            is LocationState.Error -> {
                binding.progressBar.visibility = View.GONE
                Snackbar.make(binding.root, state.message, Snackbar.LENGTH_LONG).show()
            }
            is LocationState.LocationUpdated -> {
                binding.progressBar.visibility = View.GONE
                updateLocationInfo(state.location)
            }
            is LocationState.GeofenceAdded -> {
                Snackbar.make(
                    binding.root,
                    "Geofence added successfully",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
            is LocationState.GeofenceRemoved -> {
                Snackbar.make(
                    binding.root,
                    "Geofence removed successfully",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
            is LocationState.RouteOptimized -> {
                displayRoute(state.route)
            }
            else -> {
                binding.progressBar.visibility = View.GONE
            }
        }
    }

    private fun updateLocationInfo(location: LocationUpdate) {
        binding.latitudeTextView.text = getString(R.string.latitude_format, location.latitude)
        binding.longitudeTextView.text = getString(R.string.longitude_format, location.longitude)
        binding.accuracyTextView.text = getString(R.string.accuracy_format, location.accuracy)
        binding.speedTextView.text = getString(R.string.speed_format, location.speed)
    }

    private fun updateMapLocation(location: LocationUpdate) {
        googleMap?.let { map ->
            val latLng = LatLng(location.latitude, location.longitude)
            map.clear()
            map.addMarker(
                MarkerOptions()
                    .position(latLng)
                    .title("Current Location")
            )
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15f))
        }
    }

    private fun updateGeofencesOnMap(geofences: List<Geofence>) {
        // Implement geofence visualization on the map
        // This would typically involve drawing circles or polygons
    }

    private fun displayRoute(route: Route) {
        // Implement route visualization on the map
        // This would typically involve drawing polylines
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map
        googleMap?.isMyLocationEnabled = true
        googleMap?.uiSettings?.apply {
            isZoomControlsEnabled = true
            isMyLocationButtonEnabled = true
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
        googleMap = null
    }
} 