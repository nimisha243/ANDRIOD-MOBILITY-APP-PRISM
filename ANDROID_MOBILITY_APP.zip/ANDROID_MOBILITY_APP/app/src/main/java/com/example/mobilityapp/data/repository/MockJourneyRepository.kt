package com.example.mobilityapp.data.repository

import com.example.mobilityapp.model.Journey
import com.example.mobilityapp.model.JourneyStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.util.Date
import java.util.UUID
import javax.inject.Inject

class MockJourneyRepository @Inject constructor() : JourneyRepository {
    private val journeys = mutableListOf<Journey>()

    init {
        // Add some mock data
        journeys.addAll(listOf(
            Journey(
                id = UUID.randomUUID().toString(),
                date = Date(),
                status = JourneyStatus.COMPLETED,
                distance = 5.2f,
                fare = 25.00,
                startLocation = "Home",
                endLocation = "Work"
            ),
            Journey(
                id = UUID.randomUUID().toString(),
                date = Date(),
                status = JourneyStatus.IN_PROGRESS,
                distance = 3.8f,
                fare = 18.50,
                startLocation = "Work",
                endLocation = "Gym"
            )
        ))
    }

    override fun getRecentJourneys(): Flow<List<Journey>> = flow {
        while (true) {
            emit(journeys.sortedByDescending { it.date })
            delay(1000) // Simulate network delay
        }
    }

    override fun getJourneyStatistics(): Flow<JourneyStatistics> = flow {
        while (true) {
            val totalJourneys = journeys.size
            val totalDistance = journeys.sumOf { it.distance.toDouble() }.toFloat()
            val averageSpeed = if (totalJourneys > 0) totalDistance / totalJourneys else 0f

            emit(JourneyStatistics(totalJourneys, totalDistance, averageSpeed))
            delay(1000) // Simulate network delay
        }
    }

    override suspend fun startJourney(startLocation: String, endLocation: String): Journey {
        val journey = Journey(
            id = UUID.randomUUID().toString(),
            date = Date(),
            status = JourneyStatus.IN_PROGRESS,
            distance = 0f,
            fare = 0.0,
            startLocation = startLocation,
            endLocation = endLocation
        )
        journeys.add(journey)
        return journey
    }

    override suspend fun completeJourney(journeyId: String) {
        val index = journeys.indexOfFirst { it.id == journeyId }
        if (index != -1) {
            val journey = journeys[index]
            journeys[index] = journey.copy(
                status = JourneyStatus.COMPLETED,
                distance = 5.2f,
                fare = 25.00
            )
        }
    }

    override suspend fun cancelJourney(journeyId: String) {
        val index = journeys.indexOfFirst { it.id == journeyId }
        if (index != -1) {
            val journey = journeys[index]
            journeys[index] = journey.copy(status = JourneyStatus.CANCELLED)
        }
    }
} 