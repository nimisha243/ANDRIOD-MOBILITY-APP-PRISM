package com.example.mobilityapp.repository

import com.example.mobilityapp.data.model.ScheduledRide
import kotlinx.coroutines.flow.Flow

interface RideRepository {
    fun getScheduledRides(): Flow<List<ScheduledRide>>
    suspend fun scheduleRide(ride: ScheduledRide): Result<ScheduledRide>
    suspend fun cancelScheduledRide(rideId: String): Result<Unit>
    suspend fun getRideHistory(): Flow<List<ScheduledRide>>
    suspend fun updateRideStatus(rideId: String, status: String): Result<Unit>
} 