package com.example.mobilityapp.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.mobilityapp.model.User

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val email: String,
    val phoneNumber: String,
    val profilePictureUrl: String?,
    val address: String?,
    val emergencyContact: String?,
    val preferredPaymentMethod: String?,
    val lastUpdated: Long = System.currentTimeMillis()
) {
    fun toUser() = User(
        id = id,
        name = name,
        email = email,
        phoneNumber = phoneNumber,
        profilePictureUrl = profilePictureUrl,
        address = address,
        emergencyContact = emergencyContact,
        preferredPaymentMethod = preferredPaymentMethod
    )

    companion object {
        fun fromUser(user: User) = UserEntity(
            id = user.id,
            name = user.name,
            email = user.email,
            phoneNumber = user.phoneNumber,
            profilePictureUrl = user.profilePictureUrl,
            address = user.address,
            emergencyContact = user.emergencyContact,
            preferredPaymentMethod = user.preferredPaymentMethod
        )
    }
} 