package com.example.mobilityapp.repository

import com.example.mobilityapp.model.PaymentDetails
import com.example.mobilityapp.model.SavedCard
import kotlinx.coroutines.flow.Flow

interface PaymentRepository {
    fun getPaymentDetails(journeyId: String): Flow<PaymentDetails>
    fun getSavedCards(): Flow<List<SavedCard>>
    suspend fun saveCard(card: SavedCard): Result<SavedCard>
    suspend fun deleteCard(card: SavedCard): Result<Unit>
    suspend fun processCreditCardPayment(card: SavedCard, amount: Double): Result<PaymentDetails>
    suspend fun processSamsungPayPayment(amount: Double): Result<PaymentDetails>
    suspend fun isSamsungPayAvailable(): Boolean
} 