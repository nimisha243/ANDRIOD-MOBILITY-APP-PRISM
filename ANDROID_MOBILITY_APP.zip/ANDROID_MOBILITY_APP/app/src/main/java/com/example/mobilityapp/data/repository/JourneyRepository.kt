package com.example.mobilityapp.data.repository

import com.example.mobilityapp.model.Journey
import kotlinx.coroutines.flow.Flow

interface JourneyRepository {
    fun getRecentJourneys(): Flow<List<Journey>>
    fun getJourneyStatistics(): Flow<JourneyStatistics>
    suspend fun startJourney(startLocation: String, endLocation: String): Journey
    suspend fun completeJourney(journeyId: String)
    suspend fun cancelJourney(journeyId: String)
}

data class JourneyStatistics(
    val totalJourneys: Int,
    val totalDistance: Float,
    val averageSpeed: Float
) 