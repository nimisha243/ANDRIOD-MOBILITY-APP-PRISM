package com.example.mobilityapp.model

import java.util.Date

data class Journey(
    val id: String,
    val date: Date,
    val status: JourneyStatus,
    val distance: Float,
    val fare: Double,
    val startLocation: String,
    val endLocation: String
)

enum class JourneyStatus {
    COMPLETED,
    CANCELLED,
    IN_PROGRESS
} 