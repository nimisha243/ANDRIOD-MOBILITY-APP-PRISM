package com.example.mobilityapp.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mobilityapp.R
import com.google.android.material.button.MaterialButton
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class HomeFragment : Fragment() {

    private val viewModel: HomeViewModel by viewModels()
    private lateinit var journeyAdapter: JourneyAdapter
    private lateinit var notificationAdapter: NotificationAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)
        setupViews(view)
        setupRecyclerViews(view)
        observeViewModel()
        return view
    }

    private fun setupViews(view: View) {
        // Setup start journey button
        view.findViewById<MaterialButton>(R.id.start_journey_button).setOnClickListener {
            findNavController().navigate(R.id.action_main_to_journey)
        }
    }

    private fun setupRecyclerViews(view: View) {
        // Setup recent journeys recycler view
        journeyAdapter = JourneyAdapter()
        view.findViewById<RecyclerView>(R.id.recent_journeys_recycler).apply {
            layoutManager = LinearLayoutManager(context)
            adapter = journeyAdapter
        }

        // Setup notifications recycler view
        notificationAdapter = NotificationAdapter()
        view.findViewById<RecyclerView>(R.id.notifications_recycler).apply {
            layoutManager = LinearLayoutManager(context)
            adapter = notificationAdapter
        }
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiState.collect { state ->
                    updateUI(state)
                }
            }
        }
    }

    private fun updateUI(state: HomeUiState) {
        // Update statistics
        view?.apply {
            findViewById<TextView>(R.id.total_journeys_text).text = 
                getString(R.string.total_journeys, state.statistics.totalJourneys)
            findViewById<TextView>(R.id.total_distance_text).text = 
                getString(R.string.total_distance, state.statistics.totalDistance)
            findViewById<TextView>(R.id.average_speed_text).text = 
                getString(R.string.average_speed, state.statistics.averageSpeed)
        }

        // Update lists
        journeyAdapter.submitList(state.recentJourneys)
        notificationAdapter.submitList(state.notifications)
    }
} 