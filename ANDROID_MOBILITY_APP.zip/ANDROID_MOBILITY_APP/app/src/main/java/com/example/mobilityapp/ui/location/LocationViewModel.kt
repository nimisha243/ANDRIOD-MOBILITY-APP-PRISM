package com.example.mobilityapp.ui.location

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mobilityapp.data.model.*
import com.example.mobilityapp.repository.LocationRepository
import com.example.mobilityapp.service.LocationService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LocationViewModel @Inject constructor(
    private val locationRepository: LocationRepository,
    private val locationService: LocationService
) : ViewModel() {

    private val _locationState = MutableStateFlow<LocationState>(LocationState.Idle)
    val locationState: StateFlow<LocationState> = _locationState.asStateFlow()

    private val _currentLocation = MutableStateFlow<LocationUpdate?>(null)
    val currentLocation: StateFlow<LocationUpdate?> = _currentLocation.asStateFlow()

    private val _geofences = MutableStateFlow<List<Geofence>>(emptyList())
    val geofences: StateFlow<List<Geofence>> = _geofences.asStateFlow()

    private val _locationHistory = MutableStateFlow<List<LocationHistory>>(emptyList())
    val locationHistory: StateFlow<List<LocationHistory>> = _locationHistory.asStateFlow()

    init {
        viewModelScope.launch {
            locationService.locationUpdates.collect { locationUpdate ->
                locationUpdate?.let {
                    _currentLocation.value = it
                    _locationState.value = LocationState.LocationUpdated(it)
                }
            }
        }

        viewModelScope.launch {
            locationRepository.getGeofences().collect { geofences ->
                _geofences.value = geofences
            }
        }

        viewModelScope.launch {
            locationRepository.getLocationHistory().collect { history ->
                _locationHistory.value = history
            }
        }
    }

    fun addGeofence(geofence: Geofence) {
        viewModelScope.launch {
            try {
                locationRepository.saveGeofence(geofence)
                locationService.addGeofence(geofence)
                _locationState.value = LocationState.GeofenceAdded(geofence)
            } catch (e: Exception) {
                _locationState.value = LocationState.Error(e.message ?: "Failed to add geofence")
            }
        }
    }

    fun removeGeofence(geofenceId: String) {
        viewModelScope.launch {
            try {
                locationRepository.removeGeofence(geofenceId)
                locationService.removeGeofence(geofenceId)
                _locationState.value = LocationState.GeofenceRemoved(geofenceId)
            } catch (e: Exception) {
                _locationState.value = LocationState.Error(e.message ?: "Failed to remove geofence")
            }
        }
    }

    fun optimizeRoute(start: LocationUpdate, end: LocationUpdate) {
        viewModelScope.launch {
            try {
                _locationState.value = LocationState.Loading
                val route = locationRepository.optimizeRoute(start, end)
                _locationState.value = LocationState.RouteOptimized(route)
            } catch (e: Exception) {
                _locationState.value = LocationState.Error(e.message ?: "Failed to optimize route")
            }
        }
    }

    fun startLocationTracking() {
        _locationState.value = LocationState.TrackingStarted
    }

    fun stopLocationTracking() {
        _locationState.value = LocationState.TrackingStopped
    }
}

sealed class LocationState {
    object Idle : LocationState()
    object Loading : LocationState()
    object TrackingStarted : LocationState()
    object TrackingStopped : LocationState()
    data class LocationUpdated(val location: LocationUpdate) : LocationState()
    data class GeofenceAdded(val geofence: Geofence) : LocationState()
    data class GeofenceRemoved(val geofenceId: String) : LocationState()
    data class RouteOptimized(val route: Route) : LocationState()
    data class Error(val message: String) : LocationState()
} 