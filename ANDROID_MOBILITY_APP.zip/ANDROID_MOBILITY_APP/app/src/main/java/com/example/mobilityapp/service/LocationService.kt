package com.example.mobilityapp.service

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.example.mobilityapp.R
import com.example.mobilityapp.data.model.LocationUpdate
import com.example.mobilityapp.data.model.Geofence
import com.google.android.gms.location.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

class LocationService : Service() {
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var geofencingClient: GeofencingClient
    private var locationCallback: LocationCallback? = null
    private var geofenceCallback: GeofencingEventCallback? = null

    private val _locationUpdates = MutableStateFlow<LocationUpdate?>(null)
    val locationUpdates: StateFlow<LocationUpdate?> = _locationUpdates

    private val _geofenceEvents = MutableStateFlow<GeofencingEvent?>(null)
    val geofenceEvents: StateFlow<GeofencingEvent?> = _geofenceEvents

    @Inject
    lateinit var locationRepository: LocationRepository

    companion object {
        private const val NOTIFICATION_ID = 12345
        private const val CHANNEL_ID = "location_service_channel"
        private const val LOCATION_UPDATE_INTERVAL = 10000L // 10 seconds
        private const val LOCATION_UPDATE_FASTEST_INTERVAL = 5000L // 5 seconds
    }

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        geofencingClient = LocationServices.getGeofencingClient(this)
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification())
    }

    @SuppressLint("MissingPermission")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startLocationUpdates()
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Location Service Channel",
                NotificationManager.IMPORTANCE_LOW
            )
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotification() = NotificationCompat.Builder(this, CHANNEL_ID)
        .setContentTitle("Location Tracking Active")
        .setContentText("Tracking your location in the background")
        .setSmallIcon(R.drawable.ic_location)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .build()

    @SuppressLint("MissingPermission")
    private fun startLocationUpdates() {
        val locationRequest = LocationRequest.create().apply {
            interval = LOCATION_UPDATE_INTERVAL
            fastestInterval = LOCATION_UPDATE_FASTEST_INTERVAL
            priority = Priority.PRIORITY_HIGH_ACCURACY
        }

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                locationResult.lastLocation?.let { location ->
                    handleLocationUpdate(location)
                }
            }
        }

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback!!,
                Looper.getMainLooper()
            )
        }
    }

    private fun handleLocationUpdate(location: Location) {
        val locationUpdate = LocationUpdate(
            latitude = location.latitude,
            longitude = location.longitude,
            accuracy = location.accuracy,
            timestamp = System.currentTimeMillis(),
            speed = location.speed,
            bearing = location.bearing
        )
        _locationUpdates.value = locationUpdate
        locationRepository.saveLocationUpdate(locationUpdate)
    }

    @SuppressLint("MissingPermission")
    fun addGeofence(geofence: Geofence) {
        val geofencingRequest = GeofencingRequest.Builder().apply {
            setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            addGeofence(com.google.android.gms.location.Geofence.Builder()
                .setRequestId(geofence.id)
                .setCircularRegion(
                    geofence.latitude,
                    geofence.longitude,
                    geofence.radius
                )
                .setExpirationDuration(Geofence.NEVER_EXPIRE)
                .setTransitionTypes(
                    Geofence.GEOFENCE_TRANSITION_ENTER or
                            Geofence.GEOFENCE_TRANSITION_EXIT
                )
                .build()
            )
        }.build()

        geofenceCallback = object : GeofencingEventCallback() {
            override fun onGeofenceStatusChanged(status: Int, location: Location?) {
                super.onGeofenceStatusChanged(status, location)
                // Handle geofence status changes
            }

            override fun onGeofenceEnter(geofence: com.google.android.gms.location.Geofence) {
                _geofenceEvents.value = GeofencingEvent.Enter(geofence.requestId)
            }

            override fun onGeofenceExit(geofence: com.google.android.gms.location.Geofence) {
                _geofenceEvents.value = GeofencingEvent.Exit(geofence.requestId)
            }
        }

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            geofencingClient.addGeofences(geofencingRequest, geofenceCallback!!)
        }
    }

    fun removeGeofence(geofenceId: String) {
        geofencingClient.removeGeofences(listOf(geofenceId))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        locationCallback?.let {
            fusedLocationClient.removeLocationUpdates(it)
        }
        geofenceCallback?.let {
            geofencingClient.removeGeofences(listOf())
        }
    }
} 