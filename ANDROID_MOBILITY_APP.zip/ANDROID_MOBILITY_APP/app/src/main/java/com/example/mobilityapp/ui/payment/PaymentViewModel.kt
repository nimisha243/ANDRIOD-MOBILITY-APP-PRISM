package com.example.mobilityapp.ui.payment

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mobilityapp.model.PaymentDetails
import com.example.mobilityapp.model.PaymentMethod
import com.example.mobilityapp.model.PaymentStatus
import com.example.mobilityapp.model.SavedCard
import com.example.mobilityapp.repository.PaymentRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PaymentViewModel @Inject constructor(
    private val paymentRepository: PaymentRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(PaymentUiState())
    val uiState: StateFlow<PaymentUiState> = _uiState

    private var selectedCard: SavedCard? = null
    private var selectedPaymentMethod = PaymentMethod.CREDIT_CARD

    init {
        loadSavedCards()
        checkSamsungPayAvailability()
    }

    fun loadPaymentDetails(journeyId: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            paymentRepository.getPaymentDetails(journeyId)
                .catch { e ->
                    _uiState.update { 
                        it.copy(
                            isLoading = false,
                            error = e.message ?: "Failed to load payment details"
                        )
                    }
                }
                .collect { paymentDetails ->
                    _uiState.update {
                        it.copy(
                            paymentDetails = paymentDetails,
                            isLoading = false,
                            error = null
                        )
                    }
                }
        }
    }

    private fun loadSavedCards() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            paymentRepository.getSavedCards()
                .catch { e ->
                    _uiState.update { 
                        it.copy(
                            isLoading = false,
                            error = e.message ?: "Failed to load saved cards"
                        )
                    }
                }
                .collect { cards ->
                    _uiState.update {
                        it.copy(
                            savedCards = cards,
                            isLoading = false,
                            error = null
                        )
                    }
                }
        }
    }

    private fun checkSamsungPayAvailability() {
        viewModelScope.launch {
            val isAvailable = paymentRepository.isSamsungPayAvailable()
            _uiState.update { it.copy(isSamsungPayAvailable = isAvailable) }
        }
    }

    fun selectCard(card: SavedCard) {
        selectedCard = card
        selectedPaymentMethod = PaymentMethod.CREDIT_CARD
        _uiState.update { 
            it.copy(
                selectedCardId = card.id,
                selectedPaymentMethod = PaymentMethod.CREDIT_CARD
            )
        }
    }

    fun selectPaymentMethod(method: PaymentMethod) {
        selectedPaymentMethod = method
        _uiState.update { it.copy(selectedPaymentMethod = method) }
    }

    fun processPayment(amount: Double) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }

            val result = when (selectedPaymentMethod) {
                PaymentMethod.CREDIT_CARD -> {
                    val card = selectedCard
                    if (card == null) {
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                error = "No card selected"
                            )
                        }
                        return@launch
                    }
                    paymentRepository.processCreditCardPayment(card, amount)
                }
                PaymentMethod.SAMSUNG_PAY -> {
                    paymentRepository.processSamsungPayPayment(amount)
                }
                else -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            error = "Payment method not supported"
                        )
                    }
                    return@launch
                }
            }

            result.fold(
                onSuccess = { paymentDetails ->
                    _uiState.update {
                        it.copy(
                            paymentDetails = paymentDetails,
                            isLoading = false,
                            error = null,
                            isPaymentSuccessful = true
                        )
                    }
                },
                onFailure = { e ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            error = e.message ?: "Payment failed",
                            isPaymentSuccessful = false
                        )
                    }
                }
            )
        }
    }

    fun saveCard(card: SavedCard) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            
            paymentRepository.saveCard(card)
                .fold(
                    onSuccess = {
                        loadSavedCards() // Reload cards after successful save
                        _uiState.update { 
                            it.copy(
                                isLoading = false,
                                error = null
                            )
                        }
                    },
                    onFailure = { e ->
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                error = e.message ?: "Failed to save card"
                            )
                        }
                    }
                )
        }
    }

    fun deleteCard(card: SavedCard) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            
            paymentRepository.deleteCard(card)
                .fold(
                    onSuccess = {
                        if (card.id == selectedCard?.id) {
                            selectedCard = null
                        }
                        loadSavedCards() // Reload cards after successful deletion
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                error = null,
                                selectedCardId = if (card.id == it.selectedCardId) null else it.selectedCardId
                            )
                        }
                    },
                    onFailure = { e ->
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                error = e.message ?: "Failed to delete card"
                            )
                        }
                    }
                )
        }
    }

    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }

    fun resetPaymentStatus() {
        _uiState.update { 
            it.copy(
                isPaymentSuccessful = false,
                error = null
            )
        }
    }
}

data class PaymentUiState(
    val paymentDetails: PaymentDetails? = null,
    val savedCards: List<SavedCard> = emptyList(),
    val selectedCardId: String? = null,
    val selectedPaymentMethod: PaymentMethod = PaymentMethod.CREDIT_CARD,
    val isSamsungPayAvailable: Boolean = false,
    val isLoading: Boolean = false,
    val error: String? = null,
    val isPaymentSuccessful: Boolean = false
) 