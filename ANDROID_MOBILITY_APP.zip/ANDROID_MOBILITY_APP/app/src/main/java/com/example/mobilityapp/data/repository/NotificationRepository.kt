package com.example.mobilityapp.data.repository

import com.example.mobilityapp.model.Notification
import kotlinx.coroutines.flow.Flow

interface NotificationRepository {
    fun getNotifications(): Flow<List<Notification>>
    suspend fun markAsRead(notificationId: String)
    suspend fun clearAllNotifications()
} 