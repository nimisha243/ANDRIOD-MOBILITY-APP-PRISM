package com.example.mobilityapp.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mobilityapp.data.repository.JourneyRepository
import com.example.mobilityapp.data.repository.NotificationRepository
import com.example.mobilityapp.model.Journey
import com.example.mobilityapp.model.Notification
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val journeyRepository: JourneyRepository,
    private val notificationRepository: NotificationRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                journeyRepository.getRecentJourneys(),
                journeyRepository.getJourneyStatistics(),
                notificationRepository.getNotifications()
            ) { journeys, statistics, notifications ->
                HomeUiState(
                    recentJourneys = journeys,
                    statistics = statistics,
                    notifications = notifications
                )
            }.collect { state ->
                _uiState.value = state
            }
        }
    }

    fun startJourney(startLocation: String, endLocation: String) {
        viewModelScope.launch {
            journeyRepository.startJourney(startLocation, endLocation)
        }
    }

    fun markNotificationAsRead(notificationId: String) {
        viewModelScope.launch {
            notificationRepository.markAsRead(notificationId)
        }
    }

    fun clearAllNotifications() {
        viewModelScope.launch {
            notificationRepository.clearAllNotifications()
        }
    }
}

data class HomeUiState(
    val recentJourneys: List<Journey> = emptyList(),
    val statistics: JourneyStatistics = JourneyStatistics(0, 0f, 0f),
    val notifications: List<Notification> = emptyList()
) 