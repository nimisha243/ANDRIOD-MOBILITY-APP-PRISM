package com.example.mobilityapp.data.dao

import androidx.room.*
import com.example.mobilityapp.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface LocationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLocationUpdate(locationUpdate: LocationUpdate)

    @Query("SELECT * FROM location_updates ORDER BY timestamp DESC")
    fun getLocationUpdates(): Flow<List<LocationUpdate>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGeofence(geofence: Geofence)

    @Query("DELETE FROM geofences WHERE id = :geofenceId")
    suspend fun deleteGeofence(geofenceId: String)

    @Query("SELECT * FROM geofences")
    fun getGeofences(): Flow<List<Geofence>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoute(route: Route)

    @Query("SELECT * FROM routes ORDER BY id DESC")
    fun getRoutes(): Flow<List<Route>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLocationHistory(locationHistory: LocationHistory)

    @Query("SELECT * FROM location_history ORDER BY startTime DESC")
    fun getLocationHistory(): Flow<List<LocationHistory>>

    @Query("DELETE FROM location_updates WHERE timestamp < :timestamp")
    suspend fun deleteOldLocationUpdates(timestamp: Long)

    @Query("DELETE FROM location_history WHERE endTime < :timestamp")
    suspend fun deleteOldLocationHistory(timestamp: Long)
} 