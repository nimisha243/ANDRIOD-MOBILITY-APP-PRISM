package com.example.mobilityapp.ui.schedule

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mobilityapp.data.model.ScheduledRide
import com.example.mobilityapp.repository.RideRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ScheduleViewModel @Inject constructor(
    private val rideRepository: RideRepository
) : ViewModel() {

    private val _scheduledRides = MutableStateFlow<List<ScheduledRide>>(emptyList())
    val scheduledRides: StateFlow<List<ScheduledRide>> = _scheduledRides

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    init {
        loadScheduledRides()
    }

    private fun loadScheduledRides() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                rideRepository.getScheduledRides().collect { rides ->
                    _scheduledRides.value = rides
                }
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun addScheduledRide(ride: ScheduledRide) {
        viewModelScope.launch {
            rideRepository.scheduleRide(ride)
        }
    }

    fun cancelScheduledRide(rideId: String) {
        viewModelScope.launch {
            rideRepository.cancelScheduledRide(rideId)
        }
    }
} 