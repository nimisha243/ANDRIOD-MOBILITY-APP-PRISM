package com.example.mobilityapp.ui.schedule

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.mobilityapp.data.model.ScheduledRide
import com.example.mobilityapp.databinding.ItemScheduledRideBinding
import java.text.SimpleDateFormat
import java.util.Locale

class ScheduledRidesAdapter(
    private val onItemClick: (ScheduledRide) -> Unit,
    private val onCancelClick: (ScheduledRide) -> Unit
) : ListAdapter<ScheduledRide, ScheduledRidesAdapter.ViewHolder>(ScheduledRideDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemScheduledRideBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(
        private val binding: ItemScheduledRideBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        private val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())

        fun bind(ride: ScheduledRide) {
            binding.apply {
                pickupLocationText.text = root.context.getString(
                    com.example.mobilityapp.R.string.pickup_location,
                    ride.pickupLocation
                )
                dropoffLocationText.text = root.context.getString(
                    com.example.mobilityapp.R.string.dropoff_location,
                    ride.dropoffLocation
                )
                scheduledTimeText.text = root.context.getString(
                    com.example.mobilityapp.R.string.scheduled_time,
                    dateFormat.format(ride.scheduledTime)
                )
                statusText.text = root.context.getString(
                    com.example.mobilityapp.R.string.ride_status,
                    ride.status
                )
                estimatedPriceText.text = root.context.getString(
                    com.example.mobilityapp.R.string.estimated_price,
                    ride.estimatedPrice
                )

                root.setOnClickListener { onItemClick(ride) }
                cancelButton.setOnClickListener { onCancelClick(ride) }
            }
        }
    }

    private class ScheduledRideDiffCallback : DiffUtil.ItemCallback<ScheduledRide>() {
        override fun areItemsTheSame(oldItem: ScheduledRide, newItem: ScheduledRide): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: ScheduledRide, newItem: ScheduledRide): Boolean {
            return oldItem == newItem
        }
    }
} 