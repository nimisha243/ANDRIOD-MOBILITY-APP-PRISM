package com.example.mobilityapp.ui.schedule

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.mobilityapp.R
import com.example.mobilityapp.databinding.FragmentScheduleRideBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@AndroidEntryPoint
class ScheduleRideFragment : Fragment() {

    private var _binding: FragmentScheduleRideBinding? = null
    private val binding get() = _binding!!

    private val viewModel: ScheduleRideViewModel by viewModels()
    private val calendar = Calendar.getInstance()
    private val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
    private var selectedDate: Date? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentScheduleRideBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupVehicleTypeDropdown()
        setupDateTimePicker()
        setupClickListeners()
        observeViewModel()
    }

    private fun setupVehicleTypeDropdown() {
        val vehicleTypes = arrayOf("STANDARD", "PREMIUM", "LUXURY")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, vehicleTypes)
        binding.vehicleTypeInput.setAdapter(adapter)
    }

    private fun setupDateTimePicker() {
        binding.scheduledTimeInput.setOnClickListener {
            showDatePicker()
        }
    }

    private fun showDatePicker() {
        DatePickerDialog(
            requireContext(),
            { _, year, month, dayOfMonth ->
                calendar.set(Calendar.YEAR, year)
                calendar.set(Calendar.MONTH, month)
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                showTimePicker()
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun showTimePicker() {
        TimePickerDialog(
            requireContext(),
            { _, hourOfDay, minute ->
                calendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
                calendar.set(Calendar.MINUTE, minute)
                selectedDate = calendar.time
                binding.scheduledTimeInput.setText(dateFormat.format(selectedDate))
                updateEstimatedPrice()
            },
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            true
        ).show()
    }

    private fun setupClickListeners() {
        binding.scheduleButton.setOnClickListener {
            scheduleRide()
        }

        binding.vehicleTypeInput.setOnItemClickListener { _, _, _, _ ->
            updateEstimatedPrice()
        }
    }

    private fun updateEstimatedPrice() {
        val pickup = binding.pickupLocationInput.text.toString()
        val dropoff = binding.dropoffLocationInput.text.toString()
        val vehicleType = binding.vehicleTypeInput.text.toString()

        if (pickup.isNotEmpty() && dropoff.isNotEmpty() && vehicleType.isNotEmpty()) {
            viewModel.calculateEstimatedPrice(pickup, dropoff, vehicleType)
        }
    }

    private fun scheduleRide() {
        val pickup = binding.pickupLocationInput.text.toString()
        val dropoff = binding.dropoffLocationInput.text.toString()
        val vehicleType = binding.vehicleTypeInput.text.toString()
        val notes = binding.notesInput.text.toString().takeIf { it.isNotEmpty() }

        if (pickup.isEmpty() || dropoff.isEmpty() || vehicleType.isEmpty() || selectedDate == null) {
            Toast.makeText(requireContext(), "Please fill all required fields", Toast.LENGTH_SHORT).show()
            return
        }

        // In a real app, you would get the user ID from a session manager
        val userId = "current-user-id"
        
        viewModel.scheduleRide(
            userId = userId,
            pickupLocation = pickup,
            dropoffLocation = dropoff,
            scheduledTime = selectedDate!!,
            vehicleType = vehicleType,
            notes = notes
        )
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.estimatedPrice.collectLatest { price ->
                binding.estimatedPriceText.text = getString(R.string.estimated_price, price)
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.scheduleResult.collectLatest { result ->
                result?.let {
                    it.onSuccess { ride ->
                        Toast.makeText(requireContext(), "Ride scheduled successfully", Toast.LENGTH_SHORT).show()
                        findNavController().navigateUp()
                    }.onFailure { exception ->
                        Toast.makeText(requireContext(), "Failed to schedule ride: ${exception.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 