package com.example.mobilityapp.data.repository

import com.example.mobilityapp.model.Schedule
import com.example.mobilityapp.model.ScheduleStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.util.Calendar
import java.util.Date
import java.util.UUID
import javax.inject.Inject

class MockScheduleRepository @Inject constructor() : ScheduleRepository {
    private val schedules = mutableListOf<Schedule>()

    init {
        // Add some mock data
        val calendar = Calendar.getInstance()
        schedules.addAll(listOf(
            Schedule(
                id = UUID.randomUUID().toString(),
                date = calendar.time,
                startLocation = "Home",
                endLocation = "Work",
                status = ScheduleStatus.PENDING,
                recurring = true,
                recurringDays = listOf(2, 3, 4, 5, 6) // Tuesday to Saturday
            ),
            Schedule(
                id = UUID.randomUUID().toString(),
                date = calendar.apply { add(Calendar.DAY_OF_MONTH, 1) }.time,
                startLocation = "Work",
                endLocation = "Gym",
                status = ScheduleStatus.PENDING
            )
        ))
    }

    override fun getSchedules(): Flow<List<Schedule>> = flow {
        while (true) {
            emit(schedules.sortedBy { it.date })
            delay(1000) // Simulate network delay
        }
    }

    override fun getSchedulesForDate(date: Date): Flow<List<Schedule>> = flow {
        while (true) {
            val calendar = Calendar.getInstance()
            calendar.time = date
            val dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK)
            
            val filteredSchedules = schedules.filter { schedule ->
                val scheduleCalendar = Calendar.getInstance()
                scheduleCalendar.time = schedule.date
                
                schedule.date == date || 
                (schedule.recurring && schedule.recurringDays.contains(dayOfWeek))
            }
            
            emit(filteredSchedules.sortedBy { it.date })
            delay(1000) // Simulate network delay
        }
    }

    override suspend fun addSchedule(schedule: Schedule) {
        schedules.add(schedule)
    }

    override suspend fun updateSchedule(schedule: Schedule) {
        val index = schedules.indexOfFirst { it.id == schedule.id }
        if (index != -1) {
            schedules[index] = schedule
        }
    }

    override suspend fun deleteSchedule(scheduleId: String) {
        schedules.removeIf { it.id == scheduleId }
    }

    override suspend fun completeSchedule(scheduleId: String) {
        val index = schedules.indexOfFirst { it.id == scheduleId }
        if (index != -1) {
            val schedule = schedules[index]
            schedules[index] = schedule.copy(status = ScheduleStatus.COMPLETED)
        }
    }

    override suspend fun cancelSchedule(scheduleId: String) {
        val index = schedules.indexOfFirst { it.id == scheduleId }
        if (index != -1) {
            val schedule = schedules[index]
            schedules[index] = schedule.copy(status = ScheduleStatus.CANCELLED)
        }
    }
} 