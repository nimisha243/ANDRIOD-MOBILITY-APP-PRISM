package com.example.mobilityapp.data.repository

import com.example.mobilityapp.model.Schedule
import kotlinx.coroutines.flow.Flow
import java.util.Date

interface ScheduleRepository {
    fun getSchedules(): Flow<List<Schedule>>
    fun getSchedulesForDate(date: Date): Flow<List<Schedule>>
    suspend fun addSchedule(schedule: Schedule)
    suspend fun updateSchedule(schedule: Schedule)
    suspend fun deleteSchedule(scheduleId: String)
    suspend fun completeSchedule(scheduleId: String)
    suspend fun cancelSchedule(scheduleId: String)
} 