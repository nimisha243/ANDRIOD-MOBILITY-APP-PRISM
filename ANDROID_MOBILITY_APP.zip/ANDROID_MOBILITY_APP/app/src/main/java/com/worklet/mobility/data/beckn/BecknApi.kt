package com.worklet.mobility.data.beckn

import com.worklet.mobility.data.beckn.model.*
import retrofit2.http.*

interface BecknApi {
    @POST("search")
    suspend fun search(@Body request: SearchRequest): SearchResponse

    @POST("confirm")
    suspend fun confirm(@Body request: ConfirmRequest): ConfirmResponse

    @POST("cancel")
    suspend fun cancel(@Body request: CancelRequest): CancelResponse

    @POST("track")
    suspend fun track(@Body request: TrackRequest): TrackResponse

    @POST("rate")
    suspend fun rate(@Body request: RateRequest): RateResponse

    @POST("history")
    suspend fun getHistory(@Body request: HistoryRequest): HistoryResponse
} 