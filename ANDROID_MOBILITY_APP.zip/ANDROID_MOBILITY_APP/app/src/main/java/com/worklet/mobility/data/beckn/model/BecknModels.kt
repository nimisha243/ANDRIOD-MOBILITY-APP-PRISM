package com.worklet.mobility.data.beckn.model

import com.google.android.gms.maps.model.LatLng
import java.util.Date

data class SearchRequest(
    val context: Context,
    val message: SearchMessage
)

data class SearchMessage(
    val intent: Intent,
    val catalog: Catalog
)

data class Intent(
    val fulfillment: Fulfillment,
    val payment: Payment,
    val category: Category
)

data class Fulfillment(
    val start: Location,
    val end: Location,
    val type: String = "DELIVERY"
)

data class Location(
    val address: Address,
    val gps: Gps
)

data class Address(
    val areaCode: String,
    val city: String,
    val state: String,
    val country: String,
    val door: String? = null
)

data class Gps(
    val latitude: Double,
    val longitude: Double
) {
    fun toLatLng(): LatLng = LatLng(latitude, longitude)
}

data class Payment(
    val type: String = "PRE-FULFILLMENT",
    val status: String = "NOT-PAID"
)

data class Category(
    val id: String = "mobility"
)

data class Catalog(
    val bppDescriptor: BppDescriptor,
    val bppCategories: List<BppCategory>,
    val bppProviders: List<BppProvider>
)

data class BppDescriptor(
    val name: String,
    val symbol: String,
    val shortDesc: String,
    val longDesc: String,
    val images: List<String>
)

data class BppCategory(
    val id: String,
    val parentCategoryId: String,
    val descriptor: BppDescriptor
)

data class BppProvider(
    val id: String,
    val descriptor: BppDescriptor,
    val locations: List<Location>,
    val items: List<Item>,
    val offers: List<Offer>
)

data class Item(
    val id: String,
    val descriptor: BppDescriptor,
    val price: Price,
    val categoryId: String,
    val fulfillmentId: String
)

data class Price(
    val currency: String,
    val value: String
)

data class Offer(
    val id: String,
    val descriptor: BppDescriptor,
    val itemIds: List<String>,
    val price: Price
)

data class SearchResponse(
    val context: Context,
    val message: SearchResponseMessage
)

data class SearchResponseMessage(
    val catalog: Catalog
)

data class Context(
    val domain: String,
    val action: String,
    val country: String,
    val city: String,
    val timestamp: Date,
    val transactionId: String,
    val messageId: String,
    val ttl: String
)

data class ConfirmRequest(
    val context: Context,
    val message: ConfirmMessage
)

data class ConfirmMessage(
    val order: Order
)

data class Order(
    val id: String,
    val state: String,
    val provider: BppProvider,
    val items: List<Item>,
    val fulfillment: Fulfillment,
    val payment: Payment,
    val quote: Quote
)

data class Quote(
    val price: Price,
    val breakup: List<Breakup>
)

data class Breakup(
    val title: String,
    val price: Price
)

data class ConfirmResponse(
    val context: Context,
    val message: ConfirmResponseMessage
)

data class ConfirmResponseMessage(
    val order: Order
)

data class CancelRequest(
    val context: Context,
    val message: CancelMessage
)

data class CancelMessage(
    val orderId: String,
    val cancellationReason: String
)

data class CancelResponse(
    val context: Context,
    val message: CancelResponseMessage
)

data class CancelResponseMessage(
    val order: Order
)

data class TrackRequest(
    val context: Context,
    val message: TrackMessage
)

data class TrackMessage(
    val orderId: String
)

data class TrackResponse(
    val context: Context,
    val message: TrackResponseMessage
)

data class TrackResponseMessage(
    val tracking: Tracking
)

data class Tracking(
    val status: String,
    val location: Location?,
    val estimatedTime: Date?
)

data class RateRequest(
    val context: Context,
    val message: RateMessage
)

data class RateMessage(
    val orderId: String,
    val rating: Int,
    val feedback: String
)

data class RateResponse(
    val context: Context,
    val message: RateResponseMessage
)

data class RateResponseMessage(
    val order: Order
)

data class HistoryRequest(
    val context: Context,
    val message: HistoryMessage
)

data class HistoryMessage(
    val userId: String,
    val startDate: Date?,
    val endDate: Date?
)

data class HistoryResponse(
    val context: Context,
    val message: HistoryResponseMessage
)

data class HistoryResponseMessage(
    val orders: List<Order>
) 