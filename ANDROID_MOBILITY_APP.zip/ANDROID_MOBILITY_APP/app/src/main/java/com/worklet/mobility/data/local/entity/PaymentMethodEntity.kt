package com.worklet.mobility.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "payment_methods")
data class PaymentMethodEntity(
    @PrimaryKey
    val id: String,
    val userId: String,
    val type: String,
    val lastFourDigits: String,
    val expiryMonth: Int,
    val expiryYear: Int,
    val isDefault: Boolean,
    val createdAt: Date,
    val updatedAt: Date
) 