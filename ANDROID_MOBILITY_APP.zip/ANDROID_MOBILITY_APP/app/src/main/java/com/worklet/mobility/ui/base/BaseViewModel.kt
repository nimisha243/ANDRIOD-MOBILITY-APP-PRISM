package com.worklet.mobility.ui.base

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

abstract class BaseViewModel<State, Event> : ViewModel() {
    private val _uiState = MutableStateFlow<State?>(null)
    val uiState: StateFlow<State?> = _uiState.asStateFlow()

    private val _uiEvent = MutableStateFlow<Event?>(null)
    val uiEvent: StateFlow<Event?> = _uiEvent.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading
    
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error
    
    protected fun showLoading() {
        _loading.value = true
    }
    
    protected fun hideLoading() {
        _loading.value = false
    }
    
    protected fun showError(message: String) {
        _error.value = message
    }
    
    protected fun clearError() {
        _error.value = null
    }
    
    protected fun launchWithLoading(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                showLoading()
                block()
            } catch (e: Exception) {
                showError(e.message ?: "An error occurred")
            } finally {
                hideLoading()
            }
        }
    }

    protected fun setState(state: State) {
        viewModelScope.launch {
            _uiState.value = state
        }
    }

    protected fun setEvent(event: Event) {
        viewModelScope.launch {
            _uiEvent.value = event
            _uiEvent.value = null // Reset event after consumption
        }
    }
} 