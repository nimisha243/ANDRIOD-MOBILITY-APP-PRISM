package com.worklet.mobility.ui.user

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.viewModels
import com.worklet.mobility.databinding.DialogForgotPasswordBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ForgotPasswordDialogFragment : DialogFragment() {

    private var _binding: DialogForgotPasswordBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ForgotPasswordViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = DialogForgotPasswordBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupClickListeners()
        observeViewModel()
    }

    private fun setupClickListeners() {
        binding.cancelButton.setOnClickListener {
            dismiss()
        }

        binding.sendResetLinkButton.setOnClickListener {
            val email = binding.emailInput.text?.toString()?.trim() ?: ""
            if (email.isNotEmpty()) {
                viewModel.sendPasswordResetEmail(email)
            } else {
                binding.emailLayout.error = "Please enter your email"
            }
        }
    }

    private fun observeViewModel() {
        viewModel.resetState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is ForgotPasswordState.Loading -> {
                    binding.sendResetLinkButton.isEnabled = false
                }
                is ForgotPasswordState.Success -> {
                    Toast.makeText(
                        requireContext(),
                        "Password reset email sent. Please check your inbox.",
                        Toast.LENGTH_LONG
                    ).show()
                    dismiss()
                }
                is ForgotPasswordState.Error -> {
                    binding.sendResetLinkButton.isEnabled = true
                    Toast.makeText(
                        requireContext(),
                        state.message,
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        const val TAG = "ForgotPasswordDialog"
    }
} 