package com.worklet.mobility.di

import com.worklet.mobility.ui.auth.LoginActivity
import com.worklet.mobility.ui.auth.RegisterActivity
import com.worklet.mobility.ui.main.MainActivity
import com.worklet.mobility.ui.map.MapActivity
import com.worklet.mobility.ui.payment.PaymentActivity
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class ActivityModule {
    
    @ContributesAndroidInjector
    abstract fun contributeLoginActivity(): LoginActivity
    
    @ContributesAndroidInjector
    abstract fun contributeRegisterActivity(): RegisterActivity
    
    @ContributesAndroidInjector
    abstract fun contributeMainActivity(): MainActivity
    
    @ContributesAndroidInjector
    abstract fun contributeMapActivity(): MapActivity
    
    @ContributesAndroidInjector
    abstract fun contributePaymentActivity(): PaymentActivity
} 