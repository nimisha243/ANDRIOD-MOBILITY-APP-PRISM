package com.worklet.mobility.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.android.gms.maps.model.LatLng
import java.util.Date

@Entity(tableName = "journeys")
data class Journey(
    @PrimaryKey
    val id: String = java.util.UUID.randomUUID().toString(),
    val userId: String,
    val startLocation: Location,
    val endLocation: Location,
    val distance: Double,
    val estimatedFare: Double,
    val status: JourneyStatus = JourneyStatus.PENDING,
    val createdAt: Date = Date(),
    val updatedAt: Date = Date(),
    val needsSync: Boolean = false
)

data class Location(
    val latLng: LatLng,
    val address: String
)

enum class JourneyStatus {
    PENDING,
    CONFIRMED,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}

enum class PaymentStatus {
    PENDING,
    PROCESSING,
    COMPLETED,
    FAILED,
    REFUNDED
} 