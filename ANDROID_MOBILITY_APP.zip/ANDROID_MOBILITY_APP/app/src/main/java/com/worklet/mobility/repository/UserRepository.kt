package com.worklet.mobility.repository

import com.worklet.mobility.model.User
import com.worklet.mobility.model.UserSettings
import kotlinx.coroutines.flow.Flow

interface UserRepository {
    fun getUser(userId: String): Flow<User>
    suspend fun updateUser(user: User)
    suspend fun updateUserSettings(settings: UserSettings)
    suspend fun getUserSettings(): UserSettings
    suspend fun deleteUser(userId: String)
    suspend fun updateProfilePicture(userId: String, imageUrl: String)
    
    // Settings specific methods
    suspend fun updateNotificationPreference(enabled: Boolean)
    suspend fun updateDarkModePreference(enabled: Boolean)
    suspend fun logout()
} 