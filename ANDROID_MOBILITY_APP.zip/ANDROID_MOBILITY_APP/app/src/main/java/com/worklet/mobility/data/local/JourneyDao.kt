package com.worklet.mobility.data.local

import androidx.room.*
import com.worklet.mobility.data.model.Journey
import kotlinx.coroutines.flow.Flow

@Dao
interface JourneyDao {
    @Query("SELECT * FROM journeys WHERE userId = :userId ORDER BY createdAt DESC")
    fun getJourneysByUserId(userId: String): Flow<List<Journey>>

    @Query("SELECT * FROM journeys WHERE id = :journeyId")
    fun getJourneyById(journeyId: String): Flow<Journey>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJourney(journey: Journey)

    @Update
    suspend fun updateJourney(journey: Journey)

    @Query("DELETE FROM journeys WHERE id = :journeyId")
    suspend fun deleteJourney(journeyId: String)

    @Query("SELECT * FROM journeys WHERE needsSync = 1")
    suspend fun getJourneysForSync(): List<Journey>

    @Query("UPDATE journeys SET needsSync = 1 WHERE id = :journeyId")
    suspend fun markJourneyForSync(journeyId: String)

    @Query("UPDATE journeys SET needsSync = 0 WHERE id = :journeyId")
    suspend fun unmarkJourneyForSync(journeyId: String)
} 