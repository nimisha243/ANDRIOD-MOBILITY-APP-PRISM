package com.worklet.mobility.model.mapper

import com.worklet.mobility.data.local.entity.JourneyEntity
import com.worklet.mobility.model.Journey
import com.worklet.mobility.model.JourneyStatus

fun JourneyEntity.toJourney(): Journey {
    return Journey(
        id = id,
        userId = userId,
        startLocation = startLocation,
        endLocation = endLocation,
        distance = distance,
        duration = duration,
        fare = fare,
        status = JourneyStatus.valueOf(status),
        startTime = startTime,
        endTime = endTime,
        routePoints = routePoints,
        createdAt = createdAt,
        updatedAt = updatedAt
    )
}

fun Journey.toEntity(): JourneyEntity {
    return JourneyEntity(
        id = id,
        userId = userId,
        startLocation = startLocation,
        endLocation = endLocation,
        distance = distance,
        duration = duration,
        fare = fare,
        status = status.name,
        startTime = startTime,
        endTime = endTime,
        routePoints = routePoints,
        createdAt = createdAt,
        updatedAt = updatedAt
    )
} 