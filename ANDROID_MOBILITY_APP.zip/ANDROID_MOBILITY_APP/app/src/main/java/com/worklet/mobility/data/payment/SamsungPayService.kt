package com.worklet.mobility.data.payment

import android.app.Activity
import android.content.Context
import com.samsung.android.sdk.samsungpay.v2.*
import com.samsung.android.sdk.samsungpay.v2.card.Card
import com.samsung.android.sdk.samsungpay.v2.payment.CardInfo
import com.samsung.android.sdk.samsungpay.v2.payment.PaymentInfo
import com.samsung.android.sdk.samsungpay.v2.payment.PaymentManager
import com.samsung.android.sdk.samsungpay.v2.payment.PaymentStatusListener
import com.samsung.android.sdk.samsungpay.v2.payment.SheetInfo
import com.samsung.android.sdk.samsungpay.v2.payment.SheetListener
import com.samsung.android.sdk.samsungpay.v2.payment.SheetResult
import kotlinx.coroutines.suspendCancellableCoroutine
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

@Singleton
class SamsungPayService @Inject constructor(
    private val context: Context
) {
    private var paymentManager: PaymentManager? = null
    private var spay: SpaySdk? = null

    init {
        initializeSamsungPay()
    }

    private fun initializeSamsungPay() {
        try {
            spay = SpaySdk.getInstance()
            paymentManager = PaymentManager.getInstance()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun isSamsungPayAvailable(): Boolean {
        return try {
            spay?.isSamsungPayAvailable == true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun startPayment(
        activity: Activity,
        amount: Double,
        currency: String,
        orderId: String
    ): PaymentResult = suspendCancellableCoroutine { continuation ->
        try {
            val paymentInfo = PaymentInfo.Builder()
                .setAmount(amount)
                .setCurrency(currency)
                .setOrderId(orderId)
                .build()

            val sheetInfo = SheetInfo.Builder()
                .setSheetMode(SheetInfo.SheetMode.PAYMENT_MODE)
                .setPaymentInfo(paymentInfo)
                .build()

            paymentManager?.startSheet(
                activity,
                sheetInfo,
                object : SheetListener {
                    override fun onSuccess(sheetResult: SheetResult) {
                        val cardInfo = sheetResult.cardInfo
                        continuation.resume(
                            PaymentResult.Success(
                                cardInfo.cardId,
                                cardInfo.cardNumber,
                                cardInfo.cardType
                            )
                        )
                    }

                    override fun onFailure(error: SpaySdkError) {
                        continuation.resumeWithException(
                            PaymentException(error.message ?: "Payment failed")
                        )
                    }
                }
            )
        } catch (e: Exception) {
            continuation.resumeWithException(e)
        }
    }

    suspend fun getCards(): List<Card> = suspendCancellableCoroutine { continuation ->
        try {
            paymentManager?.getCards(object : PaymentStatusListener<List<Card>> {
                override fun onSuccess(cards: List<Card>) {
                    continuation.resume(cards)
                }

                override fun onFailure(error: SpaySdkError) {
                    continuation.resumeWithException(
                        PaymentException(error.message ?: "Failed to get cards")
                    )
                }
            })
        } catch (e: Exception) {
            continuation.resumeWithException(e)
        }
    }

    sealed class PaymentResult {
        data class Success(
            val cardId: String,
            val cardNumber: String,
            val cardType: String
        ) : PaymentResult()
    }

    class PaymentException(message: String) : Exception(message)
} 