package com.worklet.mobility.data.repository

import com.worklet.mobility.model.Journey
import kotlinx.coroutines.flow.Flow

interface JourneyRepository {
    fun getJourneys(): Flow<List<Journey>>
    fun getJourneyById(journeyId: String): Flow<Journey?>
    
    suspend fun createJourney(journey: Journey): Result<Journey>
    suspend fun updateJourney(journey: Journey): Result<Journey>
    suspend fun cancelJourney(journeyId: String): Result<Journey>
    suspend fun deleteJourney(journeyId: String): Result<Unit>
    
    suspend fun syncJourneys(): Result<Unit>
} 