package com.worklet.mobility.ui.user

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.bumptech.glide.Glide
import com.google.android.material.snackbar.Snackbar
import com.worklet.mobility.R
import com.worklet.mobility.databinding.ActivityUserBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class UserActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUserBinding
    private val viewModel: UserViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupClickListeners()
        observeViewModel()
        
        // Get user ID from intent or shared preferences
        val userId = intent.getStringExtra(EXTRA_USER_ID) ?: return
        viewModel.getUser(userId)
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
    }

    private fun setupClickListeners() {
        binding.saveButton.setOnClickListener {
            val name = binding.nameInput.text.toString()
            val email = binding.emailInput.text.toString()
            val phone = binding.phoneInput.text.toString()
            
            // Create updated user object
            val currentUser = viewModel.uiState.value?.let { state ->
                if (state is UserState.Success) {
                    state.user.copy(
                        name = name,
                        email = email,
                        phoneNumber = phone
                    )
                } else null
            } ?: return@setOnClickListener

            viewModel.updateUser(currentUser)
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiState.collect { state ->
                    when (state) {
                        is UserState.Loading -> showLoading(true)
                        is UserState.Success -> {
                            showLoading(false)
                            updateUI(state.user)
                        }
                        is UserState.Error -> {
                            showLoading(false)
                            showError(state.message)
                        }
                        null -> Unit
                    }
                }
            }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiEvent.collect { event ->
                    when (event) {
                        is UserEvent.ShowError -> showError(event.message)
                        is UserEvent.NavigateToProfile -> {
                            // Handle navigation if needed
                        }
                        null -> Unit
                    }
                }
            }
        }
    }

    private fun updateUI(user: com.worklet.mobility.data.model.User) {
        binding.nameInput.setText(user.name)
        binding.emailInput.setText(user.email)
        binding.phoneInput.setText(user.phoneNumber)
        
        user.profileImageUrl?.let { url ->
            Glide.with(this)
                .load(url)
                .placeholder(R.drawable.ic_profile_placeholder)
                .error(R.drawable.ic_profile_placeholder)
                .into(binding.profileImage)
        }
    }

    private fun showLoading(show: Boolean) {
        binding.progressIndicator.visibility = if (show) View.VISIBLE else View.GONE
        binding.saveButton.isEnabled = !show
    }

    private fun showError(message: String) {
        Snackbar.make(binding.root, message, Snackbar.LENGTH_LONG).show()
    }

    companion object {
        const val EXTRA_USER_ID = "extra_user_id"
    }
} 