package com.worklet.mobility.data.remote

import com.worklet.mobility.model.*
import retrofit2.http.*

interface ApiService {
    // User endpoints
    @POST("auth/login")
    suspend fun login(@Body request: LoginRequest): LoginResponse

    @POST("auth/register")
    suspend fun register(@Body request: RegisterRequest): RegisterResponse

    @POST("auth/forgot-password")
    suspend fun forgotPassword(@Body request: ForgotPasswordRequest): ForgotPasswordResponse

    @GET("user/profile")
    suspend fun getUserProfile(): UserProfile

    @PUT("user/profile")
    suspend fun updateUserProfile(@Body profile: UserProfile): UserProfile

    // Journey endpoints
    @GET("journeys")
    suspend fun getJourneys(): List<Journey>

    @GET("journeys/{id}")
    suspend fun getJourneyById(@Path("id") id: String): Journey

    @POST("journeys")
    suspend fun createJourney(@Body journey: Journey): Journey

    @PUT("journeys/{id}")
    suspend fun updateJourney(@Path("id") id: String, @Body journey: Journey): Journey

    @DELETE("journeys/{id}")
    suspend fun deleteJourney(@Path("id") id: String)

    @POST("journeys/{id}/location")
    suspend fun updateJourneyLocation(
        @Path("id") id: String,
        @Body location: LocationUpdate
    ): Journey

    @POST("journeys/{id}/end")
    suspend fun endJourney(@Path("id") id: String): Journey

    // Payment endpoints
    @GET("payments/cards")
    suspend fun getSavedCards(): List<SavedCard>

    @POST("payments/cards")
    suspend fun saveCard(@Body card: SavedCard): SavedCard

    @DELETE("payments/cards/{id}")
    suspend fun deleteCard(@Path("id") id: String)

    @POST("payments/process")
    suspend fun processPayment(@Body payment: PaymentRequest): PaymentResponse

    @GET("payments/history")
    suspend fun getPaymentHistory(): List<PaymentHistory>

    // Sync endpoints
    @POST("sync/journeys")
    suspend fun syncJourneys(@Body journeys: List<Journey>): SyncResponse

    @POST("sync/user")
    suspend fun syncUserData(@Body userData: UserSyncData): SyncResponse
} 