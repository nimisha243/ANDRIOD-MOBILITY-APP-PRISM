package com.worklet.mobility.repository

import com.worklet.mobility.data.local.dao.UserDao
import com.worklet.mobility.data.remote.UserApi
import com.worklet.mobility.model.User
import com.worklet.mobility.model.UserSettings
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class UserRepositoryImpl @Inject constructor(
    private val userApi: UserApi,
    private val userDao: UserDao
) : UserRepository {

    override fun getUser(userId: String): Flow<User> {
        return userDao.getUser(userId)
    }

    override suspend fun updateUser(user: User) {
        userDao.updateUser(user)
        userApi.updateUser(user)
    }

    override suspend fun updateUserSettings(settings: UserSettings) {
        userDao.updateUserSettings(settings)
        userApi.updateUserSettings(settings)
    }

    override suspend fun getUserSettings(): UserSettings {
        return userDao.getUserSettings()
    }

    override suspend fun deleteUser(userId: String) {
        userDao.deleteUser(userId)
        userApi.deleteUser(userId)
    }

    override suspend fun updateProfilePicture(userId: String, imageUrl: String) {
        userDao.updateProfilePicture(userId, imageUrl)
        userApi.updateProfilePicture(userId, imageUrl)
    }

    override suspend fun updateNotificationPreference(enabled: Boolean) {
        val currentSettings = getUserSettings()
        val updatedSettings = currentSettings.copy(notificationsEnabled = enabled)
        updateUserSettings(updatedSettings)
    }

    override suspend fun updateDarkModePreference(enabled: Boolean) {
        val currentSettings = getUserSettings()
        val updatedSettings = currentSettings.copy(darkModeEnabled = enabled)
        updateUserSettings(updatedSettings)
    }

    override suspend fun logout() {
        userApi.logout()
        userDao.deleteAllUsers()
    }
} 