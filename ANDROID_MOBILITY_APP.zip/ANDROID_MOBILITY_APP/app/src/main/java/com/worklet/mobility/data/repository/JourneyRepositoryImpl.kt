package com.worklet.mobility.data.repository

import com.worklet.mobility.data.local.dao.JourneyDao
import com.worklet.mobility.data.local.entity.JourneyEntity
import com.worklet.mobility.model.Journey
import com.worklet.mobility.network.api.ApiService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class JourneyRepositoryImpl @Inject constructor(
    private val journeyDao: JourneyDao,
    private val apiService: ApiService
) : JourneyRepository {

    override fun getJourneys(): Flow<List<Journey>> {
        return journeyDao.getJourneysByUserId(getCurrentUserId()).map { entities ->
            entities.map { it.toJourney() }
        }
    }

    override fun getJourneyById(journeyId: String): Flow<Journey?> {
        return journeyDao.getJourneyById(journeyId).map { it?.toJourney() }
    }

    override suspend fun createJourney(journey: Journey): Result<Journey> {
        return try {
            val response = apiService.createJourney(journey)
            if (response.isSuccessful) {
                response.body()?.let { createdJourney ->
                    journeyDao.insertJourney(createdJourney.toEntity())
                    Result.success(createdJourney)
                } ?: Result.failure(Exception("Create journey response body is null"))
            } else {
                Result.failure(Exception("Create journey failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun updateJourney(journey: Journey): Result<Journey> {
        return try {
            val response = apiService.updateJourney(journey.id, journey)
            if (response.isSuccessful) {
                response.body()?.let { updatedJourney ->
                    journeyDao.updateJourney(updatedJourney.toEntity())
                    Result.success(updatedJourney)
                } ?: Result.failure(Exception("Update journey response body is null"))
            } else {
                Result.failure(Exception("Update journey failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun cancelJourney(journeyId: String): Result<Journey> {
        return try {
            val response = apiService.cancelJourney(journeyId)
            if (response.isSuccessful) {
                response.body()?.let { cancelledJourney ->
                    journeyDao.updateJourney(cancelledJourney.toEntity())
                    Result.success(cancelledJourney)
                } ?: Result.failure(Exception("Cancel journey response body is null"))
            } else {
                Result.failure(Exception("Cancel journey failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteJourney(journeyId: String): Result<Unit> {
        return try {
            val journey = journeyDao.getJourneyById(journeyId).value
            journey?.let {
                journeyDao.deleteJourney(it)
                Result.success(Unit)
            } ?: Result.failure(Exception("Journey not found"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun syncJourneys(): Result<Unit> {
        return try {
            val response = apiService.getJourneys()
            if (response.isSuccessful) {
                response.body()?.let { journeys ->
                    // Delete all local journeys
                    journeyDao.deleteAllJourneysForUser(getCurrentUserId())
                    // Insert new journeys
                    journeys.forEach { journey ->
                        journeyDao.insertJourney(journey.toEntity())
                    }
                    Result.success(Unit)
                } ?: Result.failure(Exception("Sync journeys response body is null"))
            } else {
                Result.failure(Exception("Sync journeys failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun getCurrentUserId(): String {
        // In a real app, you would get this from a UserRepository or similar
        return "current_user_id"
    }
} 