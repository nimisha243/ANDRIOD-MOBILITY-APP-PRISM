package com.worklet.mobility.data.repository

import com.worklet.mobility.data.local.UserDao
import com.worklet.mobility.data.model.User
import com.worklet.mobility.data.remote.*
import com.worklet.mobility.model.UserSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

interface UserRepository {
    suspend fun login(email: String, password: String): Result<User>
    suspend fun register(name: String, email: String, password: String, phone: String): Result<User>
    suspend fun forgotPassword(email: String): Result<Unit>
    suspend fun logout()
    
    fun getCurrentUser(): Flow<User?>
    suspend fun updateUserProfile(user: User): Result<User>
    suspend fun getUserSettings(): Result<UserSettings>
    suspend fun updateNotificationPreference(enabled: Boolean): Result<Unit>
    suspend fun updateDarkModePreference(enabled: Boolean): Result<Unit>
    
    fun getAuthToken(): String?
    suspend fun saveAuthToken(token: String)
    suspend fun clearAuthToken()
}

@Singleton
class UserRepositoryImpl @Inject constructor(
    private val userDao: UserDao,
    private val userApi: UserApi
) : UserRepository {
    
    // In-memory session (replace with DataStore/EncryptedSharedPreferences for production)
    private var authToken: String? = null
    private var currentUser: User? = null

    override fun getUser(userId: String): Flow<User> = flow {
        try {
            // First emit the local data
            userDao.getUser(userId).collect { localUser ->
                emit(localUser)
            }
            
            // Then try to fetch from network and update local database
            try {
                val remoteUser = userApi.getUser(userId)
                userDao.insertUser(remoteUser)
            } catch (e: IOException) {
                // Network error, keep using local data
                // Could add error handling or retry logic here
            }
        } catch (e: Exception) {
            // Handle any other errors
            throw e
        }
    }

    override suspend fun updateUser(user: User) {
        try {
            // Update local database first
            userDao.updateUser(user)
            
            // Then try to update remote
            try {
                userApi.updateUser(user.id, user)
            } catch (e: IOException) {
                // Network error, could add retry logic or queue for later sync
            }
        } catch (e: Exception) {
            // Handle any other errors
            throw e
        }
    }

    override suspend fun createUser(user: User) {
        try {
            // Create in local database first
            userDao.insertUser(user)
            
            // Then try to create remote
            try {
                userApi.createUser(user)
            } catch (e: IOException) {
                // Network error, could add retry logic or queue for later sync
            }
        } catch (e: Exception) {
            // Handle any other errors
            throw e
        }
    }

    override suspend fun deleteUser(userId: String) {
        try {
            // Delete from local database first
            userDao.deleteUser(userId)
            
            // Then try to delete remote
            try {
                userApi.deleteUser(userId)
            } catch (e: IOException) {
                // Network error, could add retry logic or queue for later sync
            }
        } catch (e: Exception) {
            // Handle any other errors
            throw e
        }
    }

    suspend fun register(name: String, email: String, password: String): Result<User> = try {
        val response = userApi.register(RegisterRequest(name, email, password))
        authToken = response.token
        currentUser = response.user
        Result.success(response.user)
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun registerWithGoogle(token: String): Result<User> = try {
        val response = userApi.registerWithGoogle(SocialAuthRequest(token))
        authToken = response.token
        currentUser = response.user
        Result.success(response.user)
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun registerWithFacebook(token: String): Result<User> = try {
        val response = userApi.registerWithFacebook(SocialAuthRequest(token))
        authToken = response.token
        currentUser = response.user
        Result.success(response.user)
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun verifyEmail(token: String): Result<Boolean> = try {
        val response = userApi.verifyEmail(token)
        Result.success(response.success)
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun resendVerificationEmail(): Result<Boolean> = try {
        val response = userApi.resendVerificationEmail()
        Result.success(response.success)
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun login(email: String, password: String): Result<User> = try {
        val response = userApi.login(LoginRequest(email, password))
        authToken = response.token
        currentUser = response.user
        Result.success(response.user)
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun getProfile(): Result<User> = try {
        val user = currentUser ?: return Result.failure(Exception("Not logged in"))
        val updatedUser = userApi.getUser(user.id)
        currentUser = updatedUser
        Result.success(updatedUser)
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun updateProfile(name: String, email: String): Result<User> = try {
        val user = currentUser ?: return Result.failure(Exception("Not logged in"))
        val updatedUser = userApi.updateUser(user.id, UpdateProfileRequest(name, email))
        currentUser = updatedUser
        Result.success(updatedUser)
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun resetPassword(email: String): Result<Boolean> = try {
        val response = userApi.resetPassword(email)
        Result.success(response.success)
    } catch (e: Exception) {
        Result.failure(e)
    }

    fun logout() {
        authToken = null
        currentUser = null
    }

    fun isLoggedIn(): Boolean = authToken != null
    fun getAuthToken(): String? = authToken
    fun getCurrentUser(): Flow<User?> = flow {
        emit(currentUser)
    }

    suspend fun updateUserProfile(user: User): Result<User> = try {
        val updatedUser = userApi.updateUser(user.id, UpdateProfileRequest(user.name, user.email))
        currentUser = updatedUser
        Result.success(updatedUser)
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun getUserSettings(): Result<UserSettings> = try {
        val settings = userApi.getUserSettings()
        Result.success(settings)
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun updateNotificationPreference(enabled: Boolean): Result<Unit> = try {
        val response = userApi.updateNotificationPreference(enabled)
        Result.success(Unit)
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun updateDarkModePreference(enabled: Boolean): Result<Unit> = try {
        val response = userApi.updateDarkModePreference(enabled)
        Result.success(Unit)
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun saveAuthToken(token: String) {
        authToken = token
    }

    suspend fun clearAuthToken() {
        authToken = null
    }
} 