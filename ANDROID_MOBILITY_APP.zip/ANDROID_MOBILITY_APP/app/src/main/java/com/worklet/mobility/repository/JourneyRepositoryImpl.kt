package com.worklet.mobility.repository

import com.worklet.mobility.data.local.dao.JourneyDao
import com.worklet.mobility.model.Journey
import com.worklet.mobility.model.JourneyStatus
import com.worklet.mobility.model.mapper.toEntity
import com.worklet.mobility.model.mapper.toJourney
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class JourneyRepositoryImpl @Inject constructor(
    private val journeyDao: JourneyDao
) : JourneyRepository {

    override suspend fun getJourneyHistory(): List<Journey> {
        return journeyDao.getAllJourneys().map { it.toJourney() }
    }

    override suspend fun getJourneyById(id: String): Journey? {
        return journeyDao.getJourneyById(id)?.toJourney()
    }

    override suspend fun saveJourney(journey: Journey) {
        journeyDao.insertJourney(journey.toEntity())
    }

    override suspend fun updateJourney(journey: Journey) {
        journeyDao.updateJourney(journey.toEntity())
    }

    override suspend fun deleteJourney(journey: Journey) {
        journeyDao.deleteJourney(journey.toEntity())
    }

    override fun observeJourneyHistory(): Flow<List<Journey>> {
        return journeyDao.observeAllJourneys().map { entities ->
            entities.map { it.toJourney() }
        }
    }

    override fun observeJourneyById(id: String): Flow<Journey?> {
        return journeyDao.observeJourneyById(id).map { entity ->
            entity?.toJourney()
        }
    }

    override suspend fun updateJourneyStatus(id: String, status: JourneyStatus) {
        journeyDao.updateJourneyStatus(id, status)
    }

    override suspend fun getJourneyStatistics(): JourneyStatistics {
        val journeys = journeyDao.getAllJourneys().map { it.toJourney() }
        return JourneyStatistics(
            totalJourneys = journeys.size,
            completedJourneys = journeys.count { it.status == JourneyStatus.COMPLETED },
            cancelledJourneys = journeys.count { it.status == JourneyStatus.CANCELLED },
            totalDistance = journeys.sumOf { it.distance },
            totalDuration = journeys.sumOf { it.duration },
            averageSpeed = journeys.map { it.averageSpeed }.average()
        )
    }
} 