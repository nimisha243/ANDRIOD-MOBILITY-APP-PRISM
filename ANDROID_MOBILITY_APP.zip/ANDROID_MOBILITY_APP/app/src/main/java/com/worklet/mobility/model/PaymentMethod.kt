package com.worklet.mobility.model

import java.util.Date

data class PaymentMethod(
    val id: String,
    val userId: String,
    val type: PaymentType,
    val lastFourDigits: String,
    val expiryMonth: Int,
    val expiryYear: Int,
    val isDefault: Boolean,
    val createdAt: Date,
    val updatedAt: Date
)

enum class PaymentType {
    CREDIT_CARD,
    DEBIT_CARD,
    SAMSUNG_PAY
} 