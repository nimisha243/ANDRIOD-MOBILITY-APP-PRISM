package com.worklet.mobility.data.local.dao

import androidx.room.*
import com.worklet.mobility.data.local.entity.PaymentMethodEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentMethodDao {
    @Query("SELECT * FROM payment_methods WHERE userId = :userId ORDER BY isDefault DESC, createdAt DESC")
    fun getPaymentMethodsByUserId(userId: String): Flow<List<PaymentMethodEntity>>

    @Query("SELECT * FROM payment_methods WHERE id = :paymentMethodId")
    fun getPaymentMethodById(paymentMethodId: String): Flow<PaymentMethodEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPaymentMethod(paymentMethod: PaymentMethodEntity)

    @Update
    suspend fun updatePaymentMethod(paymentMethod: PaymentMethodEntity)

    @Delete
    suspend fun deletePaymentMethod(paymentMethod: PaymentMethodEntity)

    @Query("DELETE FROM payment_methods WHERE userId = :userId")
    suspend fun deleteAllPaymentMethodsForUser(userId: String)

    @Query("UPDATE payment_methods SET isDefault = 0 WHERE userId = :userId AND id != :defaultPaymentMethodId")
    suspend fun updateDefaultPaymentMethod(userId: String, defaultPaymentMethodId: String)
} 