package com.worklet.mobility.model

data class UserSettings(
    val notificationsEnabled: Boolean = true,
    val darkModeEnabled: Boolean = false,
    val language: String = "English"
) 