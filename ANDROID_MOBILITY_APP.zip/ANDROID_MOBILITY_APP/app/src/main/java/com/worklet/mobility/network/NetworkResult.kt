package com.worklet.mobility.network

sealed class NetworkResult<out T> {
    data class Success<out T>(val data: T) : NetworkResult<T>()
    data class Error(val exception: Exception) : NetworkResult<Nothing>()
    object Loading : NetworkResult<Nothing>()

    companion object {
        fun <T> success(data: T) = Success(data)
        fun error(exception: Exception) = Error(exception)
        fun loading() = Loading
    }
}

suspend fun <T> safeApiCall(
    apiCall: suspend () -> T
): NetworkResult<T> {
    return try {
        NetworkResult.success(apiCall.invoke())
    } catch (throwable: Throwable) {
        when (throwable) {
            is Exception -> NetworkResult.error(throwable)
            else -> NetworkResult.error(Exception("An unexpected error occurred"))
        }
    }
} 