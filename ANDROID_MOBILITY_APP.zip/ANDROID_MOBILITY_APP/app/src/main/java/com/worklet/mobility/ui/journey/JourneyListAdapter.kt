package com.worklet.mobility.ui.journey

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.worklet.mobility.data.model.Journey
import com.worklet.mobility.databinding.ItemJourneyBinding

class JourneyListAdapter : ListAdapter<Journey, JourneyListAdapter.JourneyViewHolder>(JourneyDiffCallback()) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JourneyViewHolder {
        val binding = ItemJourneyBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return JourneyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: JourneyViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class JourneyViewHolder(private val binding: ItemJourneyBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(journey: Journey) {
            binding.startLocationText.text = journey.startLocation.address
            binding.endLocationText.text = journey.endLocation.address
            binding.distanceText.text = String.format("%.2f km", journey.distance)
            binding.fareText.text = String.format("$%.2f", journey.estimatedFare)
        }
    }
}

class JourneyDiffCallback : DiffUtil.ItemCallback<Journey>() {
    override fun areItemsTheSame(oldItem: Journey, newItem: Journey): Boolean = oldItem.id == newItem.id
    override fun areContentsTheSame(oldItem: Journey, newItem: Journey): Boolean = oldItem == newItem
} 