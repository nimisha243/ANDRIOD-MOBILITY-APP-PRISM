package com.worklet.mobility.service

import android.content.Context
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.PolylineOptions
import com.google.maps.android.PolyUtil
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MapsService @Inject constructor(
    @ApplicationContext private val context: Context
) {
    fun drawRoute(map: GoogleMap, points: List<LatLng>, color: Int) {
        val polylineOptions = PolylineOptions()
            .addAll(points)
            .color(color)
            .width(12f)
            .geodesic(true)

        map.addPolyline(polylineOptions)
    }

    fun fitBounds(map: GoogleMap, points: List<LatLng>) {
        if (points.isEmpty()) return

        val builder = LatLngBounds.builder()
        points.forEach { builder.include(it) }

        map.animateCamera(
            com.google.android.gms.maps.CameraUpdateFactory.newLatLngBounds(
                builder.build(),
                100
            )
        )
    }

    fun decodePolyline(encoded: String): List<LatLng> {
        return PolyUtil.decode(encoded).map { LatLng(it.lat, it.lng) }
    }

    fun encodePolyline(points: List<LatLng>): String {
        return PolyUtil.encode(points.map { com.google.android.gms.maps.model.LatLng(it.latitude, it.longitude) })
    }
} 