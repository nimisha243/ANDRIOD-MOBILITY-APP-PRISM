package com.worklet.mobility.ui.journey

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.worklet.mobility.data.model.Journey
import com.worklet.mobility.data.model.JourneyStatus
import com.worklet.mobility.databinding.ItemJourneyBinding
import java.text.SimpleDateFormat
import java.util.Locale

class JourneyAdapter(
    private val onJourneyClick: (Journey) -> Unit,
    private val onJourneyCancel: (Journey) -> Unit
) : ListAdapter<Journey, JourneyAdapter.JourneyViewHolder>(JourneyDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JourneyViewHolder {
        val binding = ItemJourneyBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return JourneyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: JourneyViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class JourneyViewHolder(
        private val binding: ItemJourneyBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        private val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())

        fun bind(journey: Journey) {
            binding.apply {
                startLocationText.text = journey.startLocation.address
                endLocationText.text = journey.endLocation.address
                distanceText.text = root.context.getString(
                    com.worklet.mobility.R.string.distance,
                    String.format("%.1f km", journey.distance)
                )
                fareText.text = root.context.getString(
                    com.worklet.mobility.R.string.estimated_fare,
                    String.format("$%.2f", journey.estimatedFare)
                )
                dateText.text = dateFormat.format(journey.createdAt)
                statusText.text = journey.status.name

                // Set status color
                val statusColor = when (journey.status) {
                    JourneyStatus.PENDING -> com.worklet.mobility.R.color.status_pending
                    JourneyStatus.CONFIRMED -> com.worklet.mobility.R.color.status_confirmed
                    JourneyStatus.IN_PROGRESS -> com.worklet.mobility.R.color.status_in_progress
                    JourneyStatus.COMPLETED -> com.worklet.mobility.R.color.status_completed
                    JourneyStatus.CANCELLED -> com.worklet.mobility.R.color.status_cancelled
                }
                statusText.setTextColor(root.context.getColor(statusColor))

                // Show/hide cancel button based on journey status
                cancelButton.visibility = when (journey.status) {
                    JourneyStatus.PENDING, JourneyStatus.CONFIRMED -> android.view.View.VISIBLE
                    else -> android.view.View.GONE
                }

                root.setOnClickListener {
                    onJourneyClick(journey)
                }

                cancelButton.setOnClickListener {
                    onJourneyCancel(journey)
                }
            }
        }
    }

    private class JourneyDiffCallback : DiffUtil.ItemCallback<Journey>() {
        override fun areItemsTheSame(oldItem: Journey, newItem: Journey): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Journey, newItem: Journey): Boolean {
            return oldItem == newItem
        }
    }
} 