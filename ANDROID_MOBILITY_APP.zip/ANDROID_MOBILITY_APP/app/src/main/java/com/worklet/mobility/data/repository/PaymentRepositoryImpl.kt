package com.worklet.mobility.data.repository

import com.worklet.mobility.data.local.dao.PaymentMethodDao
import com.worklet.mobility.data.local.entity.PaymentMethodEntity
import com.worklet.mobility.model.PaymentMethod
import com.worklet.mobility.network.api.ApiService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PaymentRepositoryImpl @Inject constructor(
    private val paymentMethodDao: PaymentMethodDao,
    private val apiService: ApiService
) : PaymentRepository {

    override fun getPaymentMethods(): Flow<List<PaymentMethod>> {
        return paymentMethodDao.getPaymentMethodsByUserId(getCurrentUserId()).map { entities ->
            entities.map { it.toPaymentMethod() }
        }
    }

    override fun getPaymentMethodById(paymentMethodId: String): Flow<PaymentMethod?> {
        return paymentMethodDao.getPaymentMethodById(paymentMethodId).map { it?.toPaymentMethod() }
    }

    override suspend fun addPaymentMethod(paymentMethod: PaymentMethod): Result<PaymentMethod> {
        return try {
            val response = apiService.addPaymentMethod(paymentMethod)
            if (response.isSuccessful) {
                response.body()?.let { addedPaymentMethod ->
                    paymentMethodDao.insertPaymentMethod(addedPaymentMethod.toEntity())
                    Result.success(addedPaymentMethod)
                } ?: Result.failure(Exception("Add payment method response body is null"))
            } else {
                Result.failure(Exception("Add payment method failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun updatePaymentMethod(paymentMethod: PaymentMethod): Result<PaymentMethod> {
        return try {
            val response = apiService.updatePaymentMethod(paymentMethod.id, paymentMethod)
            if (response.isSuccessful) {
                response.body()?.let { updatedPaymentMethod ->
                    paymentMethodDao.updatePaymentMethod(updatedPaymentMethod.toEntity())
                    Result.success(updatedPaymentMethod)
                } ?: Result.failure(Exception("Update payment method response body is null"))
            } else {
                Result.failure(Exception("Update payment method failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deletePaymentMethod(paymentMethodId: String): Result<Unit> {
        return try {
            val response = apiService.deletePaymentMethod(paymentMethodId)
            if (response.isSuccessful) {
                val paymentMethod = paymentMethodDao.getPaymentMethodById(paymentMethodId).value
                paymentMethod?.let {
                    paymentMethodDao.deletePaymentMethod(it)
                    Result.success(Unit)
                } ?: Result.failure(Exception("Payment method not found"))
            } else {
                Result.failure(Exception("Delete payment method failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun setDefaultPaymentMethod(paymentMethodId: String): Result<Unit> {
        return try {
            val response = apiService.setDefaultPaymentMethod(paymentMethodId)
            if (response.isSuccessful) {
                paymentMethodDao.updateDefaultPaymentMethod(getCurrentUserId(), paymentMethodId)
                Result.success(Unit)
            } else {
                Result.failure(Exception("Set default payment method failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun processPayment(
        journeyId: String,
        amount: Double,
        paymentMethodId: String
    ): Result<Unit> {
        return try {
            val response = apiService.processPayment(journeyId, amount, paymentMethodId)
            if (response.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Process payment failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun getCurrentUserId(): String {
        // In a real app, you would get this from a UserRepository or similar
        return "current_user_id"
    }
} 