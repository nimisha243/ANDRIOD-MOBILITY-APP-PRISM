package com.worklet.mobility.data.beckn.model

data class SearchRequest(
    val context: Context,
    val message: Message
) {
    data class Context(
        val domain: String = "mobility",
        val country: String,
        val city: String,
        val action: String = "search",
        val core_version: String = "1.1.0",
        val bap_id: String,
        val bap_uri: String,
        val transaction_id: String,
        val message_id: String,
        val timestamp: String
    )
    data class Message(
        val intent: Intent
    )
    data class Intent(
        val fulfillment: Fulfillment
    )
    data class Fulfillment(
        val start: Location,
        val end: Location
    )
    data class Location(
        val gps: String,
        val address: String? = null
    )
} 