package com.worklet.mobility.ui.payment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import com.worklet.mobility.R
import com.worklet.mobility.databinding.FragmentPaymentBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class PaymentFragment : Fragment() {

    private var _binding: FragmentPaymentBinding? = null
    private val binding get() = _binding!!
    private val viewModel: PaymentViewModel by viewModels()
    private val args: PaymentFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPaymentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        observeViewModel()
        viewModel.loadPaymentDetails(args.journeyId)
    }

    private fun setupUI() {
        binding.apply {
            // Setup payment method selection
            paymentMethodGroup.setOnCheckedChangeListener { _, checkedId ->
                when (checkedId) {
                    R.id.creditCardRadio -> viewModel.setPaymentMethod(PaymentMethod.CREDIT_CARD)
                    R.id.samsungPayRadio -> viewModel.setPaymentMethod(PaymentMethod.SAMSUNG_PAY)
                }
            }

            // Setup saved cards spinner
            savedCardsSpinner.setOnItemSelectedListener { position ->
                viewModel.selectSavedCard(position)
            }

            // Setup payment button
            payButton.setOnClickListener {
                val amount = amountInput.text.toString().toDoubleOrNull()
                if (amount != null) {
                    viewModel.processPayment(amount)
                } else {
                    Toast.makeText(requireContext(), R.string.please_enter_amount, Toast.LENGTH_SHORT).show()
                }
            }

            // Setup delete card button
            deleteCardButton.setOnClickListener {
                viewModel.deleteSelectedCard()
            }
        }
    }

    private fun observeViewModel() {
        viewModel.paymentState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is PaymentState.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                    binding.payButton.isEnabled = false
                }
                is PaymentState.Success -> {
                    binding.progressBar.visibility = View.GONE
                    binding.payButton.isEnabled = true
                    Toast.makeText(requireContext(), R.string.payment_successful, Toast.LENGTH_SHORT).show()
                    // Navigate back to journey details
                    requireActivity().onBackPressed()
                }
                is PaymentState.Error -> {
                    binding.progressBar.visibility = View.GONE
                    binding.payButton.isEnabled = true
                    Toast.makeText(requireContext(), state.message, Toast.LENGTH_SHORT).show()
                }
            }
        }

        viewModel.savedCards.observe(viewLifecycleOwner) { cards ->
            binding.savedCardsSpinner.setItems(cards.map { it.lastFourDigits })
        }

        viewModel.paymentDetails.observe(viewLifecycleOwner) { details ->
            binding.apply {
                journeyIdText.text = details.journeyId
                amountInput.setText(details.amount.toString())
                amountInput.isEnabled = false
            }
        }

        viewModel.samsungPayAvailable.observe(viewLifecycleOwner) { isAvailable ->
            binding.samsungPayRadio.isEnabled = isAvailable
            if (!isAvailable) {
                binding.samsungPayNotAvailableText.visibility = View.VISIBLE
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 