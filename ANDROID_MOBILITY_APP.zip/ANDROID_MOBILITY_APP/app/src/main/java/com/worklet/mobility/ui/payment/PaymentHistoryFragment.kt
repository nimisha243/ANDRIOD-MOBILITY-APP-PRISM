package com.worklet.mobility.ui.payment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.worklet.mobility.R
import com.worklet.mobility.databinding.FragmentPaymentHistoryBinding
import com.worklet.mobility.model.PaymentStatus
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class PaymentHistoryFragment : Fragment() {

    private var _binding: FragmentPaymentHistoryBinding? = null
    private val binding get() = _binding!!
    private val viewModel: PaymentHistoryViewModel by viewModels()
    private lateinit var paymentAdapter: PaymentHistoryAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPaymentHistoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        observeViewModel()
        viewModel.loadPaymentHistory()
    }

    private fun setupUI() {
        binding.apply {
            // Setup toolbar
            toolbar.setNavigationOnClickListener {
                findNavController().navigateUp()
            }

            // Setup recycler view
            paymentAdapter = PaymentHistoryAdapter { payment ->
                findNavController().navigate(
                    PaymentHistoryFragmentDirections.actionPaymentHistoryToDetails(payment.journeyId)
                )
            }
            rvPaymentHistory.apply {
                layoutManager = LinearLayoutManager(requireContext())
                adapter = paymentAdapter
                setHasFixedSize(true)
            }

            // Setup filter buttons
            filterAllButton.setOnClickListener {
                viewModel.setFilter(PaymentFilter.ALL)
            }
            filterCompletedButton.setOnClickListener {
                viewModel.setFilter(PaymentFilter.COMPLETED)
            }
            filterFailedButton.setOnClickListener {
                viewModel.setFilter(PaymentFilter.FAILED)
            }

            // Setup sort button
            sortButton.setOnClickListener {
                viewModel.toggleSortOrder()
            }

            // Setup pull to refresh
            swipeRefreshLayout.setOnRefreshListener {
                viewModel.loadPaymentHistory()
            }
        }
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.state.collectLatest { state ->
                // Update payment list
                paymentAdapter.submitList(state.payments)
                updateEmptyState(state.payments.isEmpty())

                // Update loading state
                binding.progressBar.visibility = if (state.isLoading) View.VISIBLE else View.GONE
                binding.swipeRefreshLayout.isRefreshing = state.isLoading

                // Update filter buttons
                binding.apply {
                    filterAllButton.isSelected = state.currentFilter == PaymentFilter.ALL
                    filterCompletedButton.isSelected = state.currentFilter == PaymentFilter.COMPLETED
                    filterFailedButton.isSelected = state.currentFilter == PaymentFilter.FAILED
                }

                // Update sort button
                binding.sortButton.setIconResource(
                    if (state.sortOrder) R.drawable.ic_sort_ascending else R.drawable.ic_sort_descending
                )

                // Show error if any
                state.error?.let { error ->
                    Snackbar.make(binding.root, error, Snackbar.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun updateEmptyState(isEmpty: Boolean) {
        binding.tvEmptyState.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.rvPaymentHistory.visibility = if (isEmpty) View.GONE else View.VISIBLE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 