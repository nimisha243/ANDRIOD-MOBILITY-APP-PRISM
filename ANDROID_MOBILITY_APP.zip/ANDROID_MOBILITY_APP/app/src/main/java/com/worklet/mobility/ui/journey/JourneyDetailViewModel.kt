package com.worklet.mobility.ui.journey

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.worklet.mobility.data.model.Journey
import com.worklet.mobility.data.repository.JourneyRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class JourneyDetailViewModel @Inject constructor(
    private val journeyRepository: JourneyRepository
) : ViewModel() {
    private val _journey = MutableLiveData<Journey>()
    val journey: LiveData<Journey> = _journey

    fun loadJourney(journeyId: String) {
        viewModelScope.launch {
            journeyRepository.getJourney(journeyId).collect {
                _journey.value = it
            }
        }
    }
} 