package com.worklet.mobility.di

import com.worklet.mobility.data.repository.JourneyRepository
import com.worklet.mobility.data.repository.JourneyRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindJourneyRepository(
        journeyRepositoryImpl: JourneyRepositoryImpl
    ): JourneyRepository
} 