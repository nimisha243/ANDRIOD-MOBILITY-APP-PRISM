package com.worklet.mobility.service

import android.content.Context
import com.google.firebase.analytics.FirebaseAnalytics
import com.worklet.mobility.model.Journey
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AnalyticsService @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val analytics = FirebaseAnalytics.getInstance(context)

    fun trackJourneyStarted(journey: Journey) {
        val bundle = Bundle().apply {
            putString(FirebaseAnalytics.Param.ITEM_ID, journey.id)
            putString(FirebaseAnalytics.Param.ITEM_NAME, "Journey")
            putDouble(FirebaseAnalytics.Param.VALUE, journey.distance)
        }
        analytics.logEvent(FirebaseAnalytics.Event.BEGIN_CHECKOUT, bundle)
    }

    fun trackJourneyCompleted(journey: Journey) {
        val bundle = Bundle().apply {
            putString(FirebaseAnalytics.Param.ITEM_ID, journey.id)
            putString(FirebaseAnalytics.Param.ITEM_NAME, "Journey")
            putDouble(FirebaseAnalytics.Param.VALUE, journey.distance)
            putLong(FirebaseAnalytics.Param.QUANTITY, journey.duration)
        }
        analytics.logEvent(FirebaseAnalytics.Event.PURCHASE, bundle)
    }

    fun trackPaymentCompleted(amount: Double, method: String) {
        val bundle = Bundle().apply {
            putDouble(FirebaseAnalytics.Param.VALUE, amount)
            putString(FirebaseAnalytics.Param.PAYMENT_TYPE, method)
        }
        analytics.logEvent(FirebaseAnalytics.Event.PURCHASE, bundle)
    }

    fun trackUserAction(action: String, params: Map<String, Any> = emptyMap()) {
        val bundle = Bundle().apply {
            params.forEach { (key, value) ->
                when (value) {
                    is String -> putString(key, value)
                    is Int -> putInt(key, value)
                    is Long -> putLong(key, value)
                    is Double -> putDouble(key, value)
                    is Float -> putFloat(key, value)
                    is Boolean -> putBoolean(key, value)
                }
            }
        }
        analytics.logEvent(action, bundle)
    }

    fun setUserProperties(userId: String, properties: Map<String, String>) {
        analytics.setUserId(userId)
        properties.forEach { (key, value) ->
            analytics.setUserProperty(key, value)
        }
    }
} 