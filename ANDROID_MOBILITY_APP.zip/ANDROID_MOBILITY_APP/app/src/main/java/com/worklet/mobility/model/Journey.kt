package com.worklet.mobility.model

import java.util.Date

data class Journey(
    val id: String,
    val userId: String,
    val startLocation: String,
    val endLocation: String,
    val distance: Double,
    val duration: Long,
    val fare: Double,
    val status: JourneyStatus,
    val startTime: Date,
    val endTime: Date?,
    val routePoints: List<String>,
    val createdAt: Date,
    val updatedAt: Date
)

enum class JourneyStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
} 