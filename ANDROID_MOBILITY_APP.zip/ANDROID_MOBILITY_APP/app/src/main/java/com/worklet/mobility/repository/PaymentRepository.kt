package com.worklet.mobility.repository

import com.worklet.mobility.model.PaymentDetails
import com.worklet.mobility.model.PaymentStatus
import com.worklet.mobility.model.SavedCard

interface PaymentRepository {
    suspend fun getPaymentDetails(journeyId: String): PaymentDetails
    suspend fun getSavedCards(): List<SavedCard>
    suspend fun isSamsungPayAvailable(): Boolean
    suspend fun processCreditCardPayment(card: SavedCard, amount: Double)
    suspend fun processSamsungPayPayment(amount: Double)
    suspend fun deleteCard(card: SavedCard)
    suspend fun saveCard(card: SavedCard)
    suspend fun getAllPayments(): List<PaymentDetails>
    suspend fun getPaymentsByStatus(status: PaymentStatus): List<PaymentDetails>
} 