package com.worklet.mobility.data.beckn

import com.worklet.mobility.data.beckn.model.*
import retrofit2.Call
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BecknService @Inject constructor(
    private val becknApi: BecknApi
) {
    fun searchRides(request: SearchRequest): Call<SearchResponse> {
        return becknApi.searchRides(request)
    }

    fun confirmRide(request: ConfirmRequest): Call<ConfirmResponse> {
        return becknApi.confirmRide(request)
    }
} 