package com.worklet.mobility.ui.user

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.worklet.mobility.data.model.User
import com.worklet.mobility.data.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val userRepository: UserRepository
) : ViewModel() {
    private val _profileState = MutableStateFlow<ProfileState>(ProfileState.Idle)
    val profileState: StateFlow<ProfileState> = _profileState

    fun loadProfile() {
        _profileState.value = ProfileState.Loading
        viewModelScope.launch {
            val result = userRepository.getProfile()
            _profileState.value = result.fold(
                onSuccess = { ProfileState.Success(it) },
                onFailure = { ProfileState.Error(it.message ?: "Failed to load profile") }
            )
        }
    }

    fun updateProfile(name: String, email: String) {
        _profileState.value = ProfileState.Loading
        viewModelScope.launch {
            val result = userRepository.updateProfile(name, email)
            _profileState.value = result.fold(
                onSuccess = { ProfileState.Success(it) },
                onFailure = { ProfileState.Error(it.message ?: "Failed to update profile") }
            )
        }
    }

    fun logout() {
        userRepository.logout()
        _profileState.value = ProfileState.Idle
    }

    sealed class ProfileState {
        object Idle : ProfileState()
        object Loading : ProfileState()
        data class Success(val user: User) : ProfileState()
        data class Error(val message: String) : ProfileState()
    }
} 