package com.worklet.mobility.ui.settings

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.worklet.mobility.data.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val userRepository: UserRepository
) : ViewModel() {

    private val _settingsState = MutableLiveData<SettingsState>()
    val settingsState: LiveData<SettingsState> = _settingsState

    init {
        loadSettings()
    }

    private fun loadSettings() {
        viewModelScope.launch {
            _settingsState.value = SettingsState.Loading
            try {
                val settings = userRepository.getUserSettings()
                _settingsState.value = SettingsState.Success(
                    notificationsEnabled = settings.notificationsEnabled,
                    darkModeEnabled = settings.darkModeEnabled
                )
            } catch (e: Exception) {
                _settingsState.value = SettingsState.Error(e.message ?: "Failed to load settings")
            }
        }
    }

    fun updateNotificationPreference(enabled: Boolean) {
        viewModelScope.launch {
            try {
                userRepository.updateNotificationPreference(enabled)
                loadSettings()
            } catch (e: Exception) {
                _settingsState.value = SettingsState.Error(e.message ?: "Failed to update notification settings")
            }
        }
    }

    fun updateDarkModePreference(enabled: Boolean) {
        viewModelScope.launch {
            try {
                userRepository.updateDarkModePreference(enabled)
                loadSettings()
            } catch (e: Exception) {
                _settingsState.value = SettingsState.Error(e.message ?: "Failed to update dark mode settings")
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            try {
                userRepository.logout()
            } catch (e: Exception) {
                _settingsState.value = SettingsState.Error(e.message ?: "Failed to logout")
            }
        }
    }
}

sealed class SettingsState {
    object Loading : SettingsState()
    data class Success(
        val notificationsEnabled: Boolean,
        val darkModeEnabled: Boolean
    ) : SettingsState()
    data class Error(val message: String) : SettingsState()
} 