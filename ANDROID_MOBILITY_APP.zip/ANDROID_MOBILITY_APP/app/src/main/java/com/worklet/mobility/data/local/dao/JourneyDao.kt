package com.worklet.mobility.data.local.dao

import androidx.room.*
import com.worklet.mobility.data.local.entity.JourneyEntity
import com.worklet.mobility.model.JourneyStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface JourneyDao {
    @Query("SELECT * FROM journeys ORDER BY startTime DESC")
    suspend fun getAllJourneys(): List<JourneyEntity>

    @Query("SELECT * FROM journeys ORDER BY startTime DESC")
    fun observeAllJourneys(): Flow<List<JourneyEntity>>

    @Query("SELECT * FROM journeys WHERE id = :id")
    suspend fun getJourneyById(id: String): JourneyEntity?

    @Query("SELECT * FROM journeys WHERE id = :id")
    fun observeJourneyById(id: String): Flow<JourneyEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJourney(journey: JourneyEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(journeys: List<JourneyEntity>)

    @Update
    suspend fun updateJourney(journey: JourneyEntity)

    @Delete
    suspend fun deleteJourney(journey: JourneyEntity)

    @Query("UPDATE journeys SET status = :status WHERE id = :id")
    suspend fun updateJourneyStatus(id: String, status: JourneyStatus)

    @Query("DELETE FROM journeys WHERE id = :id")
    suspend fun deleteJourneyById(id: String)
} 