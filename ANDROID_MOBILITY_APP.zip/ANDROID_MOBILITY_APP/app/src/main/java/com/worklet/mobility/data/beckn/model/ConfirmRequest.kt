package com.worklet.mobility.data.beckn.model

data class ConfirmRequest(
    val context: SearchRequest.Context,
    val message: Message
) {
    data class Message(
        val order: Order
    )
    data class Order(
        val provider: Provider,
        val items: List<Item>,
        val billing: Billing,
        val fulfillment: Fulfillment
    )
    data class Provider(
        val id: String
    )
    data class Item(
        val id: String
    )
    data class Billing(
        val name: String,
        val phone: String,
        val email: String
    )
    data class Fulfillment(
        val start: SearchRequest.Location,
        val end: SearchRequest.Location
    )
} 