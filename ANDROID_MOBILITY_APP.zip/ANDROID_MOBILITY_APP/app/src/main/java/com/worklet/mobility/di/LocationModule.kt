package com.worklet.mobility.di

import android.content.Context
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.worklet.mobility.repository.LocationRepository
import com.worklet.mobility.repository.LocationRepositoryImpl
import com.worklet.mobility.service.LocationService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object LocationModule {

    @Provides
    @Singleton
    fun provideFusedLocationClient(
        @ApplicationContext context: Context
    ): FusedLocationProviderClient {
        return LocationServices.getFusedLocationProviderClient(context)
    }

    @Provides
    @Singleton
    fun provideLocationRequest(): LocationRequest {
        return LocationRequest.Builder(10000) // 10 seconds
            .setMinUpdateIntervalMillis(5000) // 5 seconds
            .setMaxUpdateDelayMillis(15000) // 15 seconds
            .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
            .build()
    }

    @Provides
    @Singleton
    fun provideLocationService(
        @ApplicationContext context: Context,
        fusedLocationClient: FusedLocationProviderClient,
        locationRequest: LocationRequest
    ): LocationService {
        return LocationService(context, fusedLocationClient, locationRequest)
    }

    @Provides
    @Singleton
    fun provideLocationRepository(
        @ApplicationContext context: Context,
        locationService: LocationService
    ): LocationRepository {
        return LocationRepositoryImpl(context, locationService)
    }
} 