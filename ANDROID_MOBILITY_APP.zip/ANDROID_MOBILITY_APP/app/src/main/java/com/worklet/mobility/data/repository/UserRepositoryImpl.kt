package com.worklet.mobility.data.repository

import com.worklet.mobility.data.local.dao.UserDao
import com.worklet.mobility.data.local.entity.UserEntity
import com.worklet.mobility.model.User
import com.worklet.mobility.model.UserSettings
import com.worklet.mobility.network.api.ApiService
import com.worklet.mobility.network.api.LoginRequest
import com.worklet.mobility.network.api.RegisterRequest
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserRepositoryImpl @Inject constructor(
    private val userDao: UserDao,
    private val apiService: ApiService
) : UserRepository {

    private var authToken: String? = null

    override suspend fun login(email: String, password: String): Result<User> {
        return try {
            val response = apiService.login(LoginRequest(email, password))
            if (response.isSuccessful) {
                response.body()?.let { loginResponse ->
                    authToken = loginResponse.token
                    val user = loginResponse.user
                    userDao.insertUser(user.toEntity())
                    Result.success(user)
                } ?: Result.failure(Exception("Login response body is null"))
            } else {
                Result.failure(Exception("Login failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun register(
        name: String,
        email: String,
        password: String,
        phone: String
    ): Result<User> {
        return try {
            val response = apiService.register(RegisterRequest(name, email, password, phone))
            if (response.isSuccessful) {
                response.body()?.let { registerResponse ->
                    authToken = registerResponse.token
                    val user = registerResponse.user
                    userDao.insertUser(user.toEntity())
                    Result.success(user)
                } ?: Result.failure(Exception("Register response body is null"))
            } else {
                Result.failure(Exception("Registration failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun forgotPassword(email: String): Result<Unit> {
        return try {
            val response = apiService.forgotPassword(ForgotPasswordRequest(email))
            if (response.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Password reset request failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun logout() {
        authToken = null
        userDao.deleteAllUsers()
    }

    override fun getCurrentUser(): Flow<User?> {
        return userDao.getUserById(getCurrentUserId() ?: "").map { it?.toUser() }
    }

    override suspend fun updateUserProfile(user: User): Result<User> {
        return try {
            val response = apiService.updateUserProfile(user)
            if (response.isSuccessful) {
                response.body()?.let { updatedUser ->
                    userDao.updateUser(updatedUser.toEntity())
                    Result.success(updatedUser)
                } ?: Result.failure(Exception("Update profile response body is null"))
            } else {
                Result.failure(Exception("Update profile failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getUserSettings(): Result<UserSettings> {
        return try {
            val response = apiService.getUserSettings()
            if (response.isSuccessful) {
                response.body()?.let { Result.success(it) }
                    ?: Result.failure(Exception("Get settings response body is null"))
            } else {
                Result.failure(Exception("Get settings failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun updateNotificationPreference(enabled: Boolean): Result<Unit> {
        return try {
            val response = apiService.updateNotificationPreference(enabled)
            if (response.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Update notification preference failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun updateDarkModePreference(enabled: Boolean): Result<Unit> {
        return try {
            val response = apiService.updateDarkModePreference(enabled)
            if (response.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("Update dark mode preference failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override fun getAuthToken(): String? = authToken

    override suspend fun saveAuthToken(token: String) {
        authToken = token
    }

    override suspend fun clearAuthToken() {
        authToken = null
    }

    private fun getCurrentUserId(): String? {
        // In a real app, you might want to store this in a more persistent way
        return userDao.getUserById("current")?.id
    }
} 