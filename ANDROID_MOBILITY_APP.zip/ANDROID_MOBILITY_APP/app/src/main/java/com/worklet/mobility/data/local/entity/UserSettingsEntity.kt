package com.worklet.mobility.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.worklet.mobility.model.UserSettings

@Entity(tableName = "user_settings")
data class UserSettingsEntity(
    @PrimaryKey
    val userId: String,
    val notificationsEnabled: Boolean,
    val darkModeEnabled: Boolean,
    val language: String
) {
    fun toUserSettings(): UserSettings {
        return UserSettings(
            notificationsEnabled = notificationsEnabled,
            darkModeEnabled = darkModeEnabled,
            language = language
        )
    }

    companion object {
        fun fromUserSettings(userId: String, settings: UserSettings): UserSettingsEntity {
            return UserSettingsEntity(
                userId = userId,
                notificationsEnabled = settings.notificationsEnabled,
                darkModeEnabled = settings.darkModeEnabled,
                language = settings.language
            )
        }
    }
} 