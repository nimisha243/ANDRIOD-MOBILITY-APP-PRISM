package com.worklet.mobility.data.remote

import com.worklet.mobility.model.PaymentDetails
import com.worklet.mobility.model.SavedCard
import retrofit2.http.*

interface PaymentApi {
    @GET("payments/{journeyId}")
    suspend fun getPaymentDetails(@Path("journeyId") journeyId: String): PaymentDetails

    @GET("payments/samsung-pay/availability")
    suspend fun isSamsungPayAvailable(): Boolean

    @POST("payments/credit-card")
    suspend fun processCreditCardPayment(
        @Body card: SavedCard,
        @Query("amount") amount: Double
    ): PaymentResponse

    @POST("payments/samsung-pay")
    suspend fun processSamsungPayPayment(
        @Query("amount") amount: Double
    ): PaymentResponse
}

data class PaymentResponse(
    val isSuccessful: Boolean,
    val errorMessage: String? = null
) 