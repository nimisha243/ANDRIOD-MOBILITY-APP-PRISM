package com.worklet.mobility.ui.journey

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.maps.model.LatLng
import com.worklet.mobility.data.model.Journey
import com.worklet.mobility.data.model.JourneyStatus
import com.worklet.mobility.data.model.Location
import com.worklet.mobility.data.repository.JourneyRepository
import com.worklet.mobility.data.beckn.BecknRepository
import com.worklet.mobility.data.beckn.model.SearchRequest
import com.worklet.mobility.data.beckn.model.SearchResponse
import com.worklet.mobility.data.beckn.model.ConfirmRequest
import com.worklet.mobility.data.beckn.model.ConfirmResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.Date
import javax.inject.Inject

@HiltViewModel
class JourneyViewModel @Inject constructor(
    private val journeyRepository: JourneyRepository,
    private val becknRepository: BecknRepository
) : ViewModel() {

    private val _journeyState = MutableStateFlow<JourneyState>(JourneyState.Idle)
    val journeyState: StateFlow<JourneyState> = _journeyState

    private val _currentJourney = MutableStateFlow<Journey?>(null)
    val currentJourney: StateFlow<Journey?> = _currentJourney

    private val _journeys = MutableStateFlow<List<Journey>>(emptyList())
    val journeys: StateFlow<List<Journey>> = _journeys

    private val _startLocation = MutableStateFlow<Location?>(null)
    val startLocation: StateFlow<Location?> = _startLocation

    private val _endLocation = MutableStateFlow<Location?>(null)
    val endLocation: StateFlow<Location?> = _endLocation

    private val _distance = MutableStateFlow<Double?>(null)
    val distance: StateFlow<Double?> = _distance

    private val _estimatedFare = MutableStateFlow<Double?>(null)
    val estimatedFare: StateFlow<Double?> = _estimatedFare

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    private val _becknSearchState = MutableStateFlow<BecknSearchState>(BecknSearchState.Idle)
    val becknSearchState: StateFlow<BecknSearchState> = _becknSearchState

    private val _becknConfirmState = MutableStateFlow<BecknConfirmState>(BecknConfirmState.Idle)
    val becknConfirmState: StateFlow<BecknConfirmState> = _becknConfirmState

    fun loadJourneys(userId: String) {
        viewModelScope.launch {
            try {
                _journeyState.value = JourneyState.Loading
                journeyRepository.getJourneys(userId).collect { journeyList ->
                    _journeys.value = journeyList
                    _journeyState.value = JourneyState.Success
                }
            } catch (e: Exception) {
                _journeyState.value = JourneyState.Error(e.message ?: "Failed to load journeys")
            }
        }
    }

    fun startJourney(
        userId: String,
        startLocation: LatLng,
        endLocation: LatLng,
        startAddress: String,
        endAddress: String,
        distance: Double,
        estimatedFare: Double
    ) {
        viewModelScope.launch {
            try {
                _journeyState.value = JourneyState.Loading
                
                val journey = Journey(
                    userId = userId,
                    startLocation = Location(startLocation, startAddress),
                    endLocation = Location(endLocation, endAddress),
                    distance = distance,
                    estimatedFare = estimatedFare,
                    status = JourneyStatus.PENDING
                )

                journeyRepository.insertJourney(journey)
                _currentJourney.value = journey
                _journeyState.value = JourneyState.Success
            } catch (e: Exception) {
                _journeyState.value = JourneyState.Error(e.message ?: "Failed to start journey")
            }
        }
    }

    fun updateJourneyStatus(journeyId: String, status: JourneyStatus) {
        viewModelScope.launch {
            try {
                _journeyState.value = JourneyState.Loading
                val journey = _currentJourney.value ?: return@launch
                
                val updatedJourney = journey.copy(
                    status = status,
                    updatedAt = Date()
                )
                
                journeyRepository.updateJourney(updatedJourney)
                _currentJourney.value = updatedJourney
                _journeyState.value = JourneyState.Success
            } catch (e: Exception) {
                _journeyState.value = JourneyState.Error(e.message ?: "Failed to update journey status")
            }
        }
    }

    fun cancelJourney(journeyId: String) {
        viewModelScope.launch {
            try {
                _journeyState.value = JourneyState.Loading
                journeyRepository.deleteJourney(journeyId)
                _currentJourney.value = null
                _journeyState.value = JourneyState.Success
            } catch (e: Exception) {
                _journeyState.value = JourneyState.Error(e.message ?: "Failed to cancel journey")
            }
        }
    }

    fun getJourneyDetails(journeyId: String) {
        viewModelScope.launch {
            try {
                _journeyState.value = JourneyState.Loading
                journeyRepository.getJourney(journeyId).collect { journey ->
                    _currentJourney.value = journey
                    _journeyState.value = JourneyState.Success
                }
            } catch (e: Exception) {
                _journeyState.value = JourneyState.Error(e.message ?: "Failed to get journey details")
            }
        }
    }

    fun setStartLocation(latLng: LatLng, address: String) {
        _startLocation.value = Location(latLng, address)
        calculateDistanceAndFare()
    }

    fun setEndLocation(latLng: LatLng, address: String) {
        _endLocation.value = Location(latLng, address)
        calculateDistanceAndFare()
    }

    private fun calculateDistanceAndFare() {
        val start = _startLocation.value
        val end = _endLocation.value

        if (start != null && end != null) {
            // Calculate distance using Haversine formula
            val distance = calculateHaversineDistance(start.latLng, end.latLng)
            _distance.value = distance

            // Calculate estimated fare (example: $2 per kilometer)
            val fare = distance * 2.0
            _estimatedFare.value = fare
        }
    }

    private fun calculateHaversineDistance(start: LatLng, end: LatLng): Double {
        val R = 6371 // Earth's radius in kilometers
        val dLat = Math.toRadians(end.latitude - start.latitude)
        val dLon = Math.toRadians(end.longitude - start.longitude)
        val lat1 = Math.toRadians(start.latitude)
        val lat2 = Math.toRadians(end.latitude)

        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        return R * c
    }

    fun confirmJourney(userId: String) {
        val start = _startLocation.value
        val end = _endLocation.value
        val distance = _distance.value
        val fare = _estimatedFare.value

        if (start == null || end == null || distance == null || fare == null) {
            _error.value = "Please select both start and end locations"
            return
        }

        viewModelScope.launch {
            try {
                val journey = Journey(
                    userId = userId,
                    startLocation = start,
                    endLocation = end,
                    distance = distance,
                    estimatedFare = fare
                )
                journeyRepository.insertJourney(journey)
                _error.value = null
            } catch (e: Exception) {
                _error.value = "Failed to save journey: ${e.message}"
            }
        }
    }

    fun clearError() {
        _error.value = null
    }

    fun searchRides(request: SearchRequest) {
        _becknSearchState.value = BecknSearchState.Loading
        viewModelScope.launch {
            val result = becknRepository.searchRides(request)
            _becknSearchState.value = result.fold(
                onSuccess = { BecknSearchState.Success(it) },
                onFailure = { BecknSearchState.Error(it.message ?: "Unknown error") }
            )
        }
    }

    fun confirmRide(request: ConfirmRequest) {
        _becknConfirmState.value = BecknConfirmState.Loading
        viewModelScope.launch {
            val result = becknRepository.confirmRide(request)
            _becknConfirmState.value = result.fold(
                onSuccess = { BecknConfirmState.Success(it) },
                onFailure = { BecknConfirmState.Error(it.message ?: "Unknown error") }
            )
        }
    }

    sealed class JourneyState {
        object Idle : JourneyState()
        object Loading : JourneyState()
        object Success : JourneyState()
        data class Error(val message: String) : JourneyState()
    }

    sealed class BecknSearchState {
        object Idle : BecknSearchState()
        object Loading : BecknSearchState()
        data class Success(val response: SearchResponse) : BecknSearchState()
        data class Error(val message: String) : BecknSearchState()
    }

    sealed class BecknConfirmState {
        object Idle : BecknConfirmState()
        object Loading : BecknConfirmState()
        data class Success(val response: ConfirmResponse) : BecknConfirmState()
        data class Error(val message: String) : BecknConfirmState()
    }
} 