package com.worklet.mobility.data.repository

import com.worklet.mobility.model.PaymentMethod
import kotlinx.coroutines.flow.Flow

interface PaymentRepository {
    fun getPaymentMethods(): Flow<List<PaymentMethod>>
    fun getPaymentMethodById(paymentMethodId: String): Flow<PaymentMethod?>
    
    suspend fun addPaymentMethod(paymentMethod: PaymentMethod): Result<PaymentMethod>
    suspend fun updatePaymentMethod(paymentMethod: PaymentMethod): Result<PaymentMethod>
    suspend fun deletePaymentMethod(paymentMethodId: String): Result<Unit>
    suspend fun setDefaultPaymentMethod(paymentMethodId: String): Result<Unit>
    
    suspend fun processPayment(journeyId: String, amount: Double, paymentMethodId: String): Result<Unit>
} 