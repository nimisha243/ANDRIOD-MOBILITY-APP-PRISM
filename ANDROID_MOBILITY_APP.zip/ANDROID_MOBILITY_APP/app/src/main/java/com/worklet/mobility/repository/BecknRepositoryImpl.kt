package com.worklet.mobility.repository

import com.worklet.mobility.data.beckn.BecknApi
import com.worklet.mobility.data.beckn.model.*
import javax.inject.Inject

class BecknRepositoryImpl @Inject constructor(
    private val becknApi: BecknApi
) : BecknRepository {

    override suspend fun searchRides(request: SearchRequest): Result<SearchResponse> {
        return try {
            Result.success(becknApi.search(request))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun confirmRide(request: ConfirmRequest): Result<ConfirmResponse> {
        return try {
            Result.success(becknApi.confirm(request))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun cancelRide(request: CancelRequest): Result<CancelResponse> {
        return try {
            Result.success(becknApi.cancel(request))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun trackRide(request: TrackRequest): Result<TrackResponse> {
        return try {
            Result.success(becknApi.track(request))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun rateRide(request: RateRequest): Result<RateResponse> {
        return try {
            Result.success(becknApi.rate(request))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getRideHistory(request: HistoryRequest): Result<HistoryResponse> {
        return try {
            Result.success(becknApi.getHistory(request))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
} 