package com.worklet.mobility.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_cards")
data class SavedCard(
    @PrimaryKey
    val id: String,
    val cardNumber: String,
    val cardType: String,
    val expiryMonth: Int,
    val expiryYear: Int,
    val cardholderName: String,
    val isDefault: Boolean = false,
    val lastFourDigits: String = cardNumber.takeLast(4)
) 