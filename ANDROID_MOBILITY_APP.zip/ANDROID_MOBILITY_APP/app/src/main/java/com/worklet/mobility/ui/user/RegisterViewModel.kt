package com.worklet.mobility.ui.user

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.worklet.mobility.data.model.User
import com.worklet.mobility.data.repository.UserRepository
import com.worklet.mobility.util.PasswordStrength
import com.worklet.mobility.util.ValidationUtils
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class RegisterViewModel @Inject constructor(
    private val userRepository: UserRepository
) : ViewModel() {
    private val _registerState = MutableStateFlow<RegisterState>(RegisterState.Idle)
    val registerState: StateFlow<RegisterState> = _registerState

    private val _validationState = MutableStateFlow<ValidationState>(ValidationState())
    val validationState: StateFlow<ValidationState> = _validationState

    private val _verificationState = MutableStateFlow<VerificationState>(VerificationState.Idle)
    val verificationState: StateFlow<VerificationState> = _verificationState

    fun validateInput(name: String, email: String, password: String, confirmPassword: String) {
        val nameValid = ValidationUtils.isValidName(name)
        val emailValid = ValidationUtils.isValidEmail(email)
        val passwordStrength = ValidationUtils.isValidPassword(password)
        val passwordsMatch = ValidationUtils.passwordsMatch(password, confirmPassword)

        _validationState.value = ValidationState(
            nameValid = nameValid,
            emailValid = emailValid,
            passwordStrength = passwordStrength,
            passwordsMatch = passwordsMatch
        )
    }

    fun register(name: String, email: String, password: String) {
        if (!isInputValid()) {
            _registerState.value = RegisterState.Error("Please fix the validation errors")
            return
        }

        _registerState.value = RegisterState.Loading
        viewModelScope.launch {
            val result = userRepository.register(name, email, password)
            _registerState.value = result.fold(
                onSuccess = { RegisterState.Success(it) },
                onFailure = { RegisterState.Error(it.message ?: "Registration failed") }
            )
        }
    }

    fun registerWithGoogle(token: String) {
        _registerState.value = RegisterState.Loading
        viewModelScope.launch {
            val result = userRepository.registerWithGoogle(token)
            _registerState.value = result.fold(
                onSuccess = { RegisterState.Success(it) },
                onFailure = { RegisterState.Error(it.message ?: "Google registration failed") }
            )
        }
    }

    fun registerWithFacebook(token: String) {
        _registerState.value = RegisterState.Loading
        viewModelScope.launch {
            val result = userRepository.registerWithFacebook(token)
            _registerState.value = result.fold(
                onSuccess = { RegisterState.Success(it) },
                onFailure = { RegisterState.Error(it.message ?: "Facebook registration failed") }
            )
        }
    }

    fun resendVerificationEmail() {
        _verificationState.value = VerificationState.Loading
        viewModelScope.launch {
            val result = userRepository.resendVerificationEmail()
            _verificationState.value = result.fold(
                onSuccess = { VerificationState.Success },
                onFailure = { VerificationState.Error(it.message ?: "Failed to resend verification email") }
            )
        }
    }

    private fun isInputValid(): Boolean {
        val state = _validationState.value
        return state.nameValid && state.emailValid && 
               state.passwordStrength != PasswordStrength.WEAK && state.passwordsMatch
    }

    sealed class RegisterState {
        object Idle : RegisterState()
        object Loading : RegisterState()
        data class Success(val user: User) : RegisterState()
        data class Error(val message: String) : RegisterState()
    }

    data class ValidationState(
        val nameValid: Boolean = false,
        val emailValid: Boolean = false,
        val passwordStrength: PasswordStrength = PasswordStrength.WEAK,
        val passwordsMatch: Boolean = false
    )

    sealed class VerificationState {
        object Idle : VerificationState()
        object Loading : VerificationState()
        object Success : VerificationState()
        data class Error(val message: String) : VerificationState()
    }
} 