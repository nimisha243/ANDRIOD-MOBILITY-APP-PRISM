package com.worklet.mobility.model.mapper

import com.worklet.mobility.data.local.entity.PaymentEntity
import com.worklet.mobility.model.PaymentDetails
import com.worklet.mobility.model.PaymentStatus

fun PaymentEntity.toPaymentDetails(): PaymentDetails {
    return PaymentDetails(
        journeyId = journeyId,
        amount = amount,
        currency = currency,
        status = PaymentStatus.valueOf(status),
        timestamp = timestamp
    )
}

fun PaymentDetails.toEntity(): PaymentEntity {
    return PaymentEntity(
        journeyId = journeyId,
        amount = amount,
        currency = currency,
        status = status.name,
        timestamp = timestamp
    )
} 