package com.worklet.mobility.ui.user

import com.worklet.mobility.data.model.User
import com.worklet.mobility.data.repository.UserRepository
import com.worklet.mobility.ui.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

sealed class UserState {
    data object Loading : UserState()
    data class Success(val user: User) : UserState()
    data class Error(val message: String) : UserState()
}

sealed class UserEvent {
    data class ShowError(val message: String) : UserEvent()
    data class NavigateToProfile(val userId: String) : UserEvent()
}

@HiltViewModel
class UserViewModel @Inject constructor(
    private val userRepository: UserRepository
) : BaseViewModel<UserState, UserEvent>() {

    fun getUser(userId: String) {
        viewModelScope.launch {
            setState(UserState.Loading)
            userRepository.getUser(userId)
                .catch { e ->
                    Timber.e(e, "Error fetching user")
                    setState(UserState.Error("Failed to load user"))
                    setEvent(UserEvent.ShowError("Failed to load user"))
                }
                .collect { user ->
                    setState(UserState.Success(user))
                }
        }
    }

    fun updateUser(user: User) {
        viewModelScope.launch {
            try {
                userRepository.updateUser(user)
                setState(UserState.Success(user))
            } catch (e: Exception) {
                Timber.e(e, "Error updating user")
                setState(UserState.Error("Failed to update user"))
                setEvent(UserEvent.ShowError("Failed to update user"))
            }
        }
    }
} 