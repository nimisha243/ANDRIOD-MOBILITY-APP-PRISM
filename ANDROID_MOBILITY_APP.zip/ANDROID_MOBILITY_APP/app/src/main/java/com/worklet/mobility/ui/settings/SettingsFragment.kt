package com.worklet.mobility.ui.settings

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.worklet.mobility.R
import com.worklet.mobility.databinding.FragmentSettingsBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupToolbar()
        setupClickListeners()
        observeViewModel()
    }

    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }

    private fun setupClickListeners() {
        with(binding) {
            // Preferences
            switchNotifications.setOnCheckedChangeListener { _, isChecked ->
                viewModel.updateNotificationPreference(isChecked)
            }
            switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
                viewModel.updateDarkModePreference(isChecked)
            }
            buttonLanguage.setOnClickListener {
                // TODO: Implement language selection
            }

            // Account
            buttonProfile.setOnClickListener {
                findNavController().navigate(R.id.action_settingsFragment_to_profileFragment)
            }
            buttonPaymentSettings.setOnClickListener {
                findNavController().navigate(R.id.action_settingsFragment_to_paymentSettingsFragment)
            }

            // Support
            buttonPrivacyPolicy.setOnClickListener {
                // TODO: Open privacy policy
            }
            buttonHelpAndSupport.setOnClickListener {
                // TODO: Open help and support
            }
            buttonAbout.setOnClickListener {
                // TODO: Show about dialog
            }

            // Logout
            buttonLogout.setOnClickListener {
                showLogoutConfirmationDialog()
            }
        }
    }

    private fun observeViewModel() {
        viewModel.settingsState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is SettingsState.Loading -> {
                    // Show loading state if needed
                }
                is SettingsState.Success -> {
                    updateUI(state)
                }
                is SettingsState.Error -> {
                    // Show error state if needed
                }
            }
        }
    }

    private fun updateUI(state: SettingsState.Success) {
        with(binding) {
            switchNotifications.isChecked = state.notificationsEnabled
            switchDarkMode.isChecked = state.darkModeEnabled
        }
    }

    private fun showLogoutConfirmationDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.logout)
            .setMessage(R.string.logout_confirmation)
            .setNegativeButton(R.string.cancel) { dialog, _ ->
                dialog.dismiss()
            }
            .setPositiveButton(R.string.confirm) { _, _ ->
                viewModel.logout()
                findNavController().navigate(R.id.action_settingsFragment_to_loginFragment)
            }
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 