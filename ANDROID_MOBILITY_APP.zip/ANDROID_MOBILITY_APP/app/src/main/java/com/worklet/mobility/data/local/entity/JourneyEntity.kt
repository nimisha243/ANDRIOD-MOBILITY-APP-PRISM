package com.worklet.mobility.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.worklet.mobility.model.JourneyStatus
import java.util.Date

@Entity(tableName = "journeys")
data class JourneyEntity(
    @PrimaryKey
    val id: String,
    val userId: String,
    val startTime: Date,
    val endTime: Date?,
    val startLocation: String,
    val endLocation: String,
    val distance: Double,
    val duration: Long,
    val averageSpeed: Double,
    val status: JourneyStatus,
    val caloriesBurned: Double,
    val cost: Double,
    val paymentMethod: String?,
    val notes: String?
) 