package com.worklet.mobility.data.remote

sealed class NetworkResult<out T> {
    data class Success<out T>(val data: T) : NetworkResult<T>()
    data class Error(val exception: Exception) : NetworkResult<Nothing>()
    object Loading : NetworkResult<Nothing>()

    val isSuccess: Boolean
        get() = this is Success

    val isError: Boolean
        get() = this is Error

    val isLoading: Boolean
        get() = this is Loading

    fun getOrNull(): T? = when (this) {
        is Success -> data
        else -> null
    }

    fun exceptionOrNull(): Exception? = when (this) {
        is Error -> exception
        else -> null
    }

    companion object {
        fun <T> success(data: T): NetworkResult<T> = Success(data)
        fun error(exception: Exception): NetworkResult<Nothing> = Error(exception)
        fun loading(): NetworkResult<Nothing> = Loading
    }
} 