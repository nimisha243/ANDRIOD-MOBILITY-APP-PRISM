package com.worklet.mobility.model

import java.util.Date

data class User(
    val id: String,
    val name: String,
    val email: String,
    val phone: String,
    val profilePictureUrl: String?,
    val createdAt: Date,
    val updatedAt: Date
) 