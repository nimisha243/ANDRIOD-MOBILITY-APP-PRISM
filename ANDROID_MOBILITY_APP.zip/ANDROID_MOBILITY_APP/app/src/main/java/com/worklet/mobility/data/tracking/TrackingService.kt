package com.worklet.mobility.data.tracking

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TrackingService @Inject constructor() {
    fun startTracking(journeyId: String) {
        // TODO: Integrate real-time tracking logic (e.g., Firebase, WebSocket, etc.)
    }
    fun stopTracking(journeyId: String) {
        // TODO: Integrate real-time tracking logic
    }
} 