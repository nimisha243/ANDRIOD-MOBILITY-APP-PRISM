package com.worklet.mobility.ui.journey

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.worklet.mobility.databinding.FragmentJourneyListBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class JourneyListFragment : Fragment() {
    private var _binding: FragmentJourneyListBinding? = null
    private val binding get() = _binding!!
    private val viewModel: JourneyListViewModel by viewModels()
    private lateinit var adapter: JourneyListAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentJourneyListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = JourneyListAdapter()
        binding.journeyRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.journeyRecyclerView.adapter = adapter
        observeViewModel()
    }

    private fun observeViewModel() {
        viewModel.journeys.observe(viewLifecycleOwner) { journeys ->
            adapter.submitList(journeys)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 