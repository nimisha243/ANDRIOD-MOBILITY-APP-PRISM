package com.worklet.mobility.databinding

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.viewbinding.ViewBinding
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.worklet.mobility.R

class DialogForgotPasswordBinding private constructor(
    private val rootView: LinearLayout,
    val emailLayout: TextInputLayout,
    val emailInput: TextInputEditText,
    val cancelButton: Button,
    val sendResetLinkButton: Button
) : ViewBinding {

    override fun getRoot(): View = rootView

    companion object {
        fun bind(view: View): DialogForgotPasswordBinding {
            return DialogForgotPasswordBinding(
                rootView = view as LinearLayout,
                emailLayout = view.findViewById(R.id.emailLayout),
                emailInput = view.findViewById(R.id.emailInput),
                cancelButton = view.findViewById(R.id.cancelButton),
                sendResetLinkButton = view.findViewById(R.id.sendResetLinkButton)
            )
        }

        fun inflate(layoutInflater: LayoutInflater, parent: ViewGroup?, attachToParent: Boolean): DialogForgotPasswordBinding {
            val view = layoutInflater.inflate(R.layout.dialog_forgot_password, parent, attachToParent)
            return bind(view)
        }
    }
} 