package com.worklet.mobility.ui.journey

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.worklet.mobility.data.model.Journey
import com.worklet.mobility.data.repository.JourneyRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class JourneyListViewModel @Inject constructor(
    private val journeyRepository: JourneyRepository
) : ViewModel() {
    private val _journeys = MutableLiveData<List<Journey>>()
    val journeys: LiveData<List<Journey>> = _journeys

    init {
        loadJourneys()
    }

    private fun loadJourneys() {
        viewModelScope.launch {
            // TODO: Replace with actual userId from auth
            journeyRepository.getJourneys("current_user_id").collect {
                _journeys.value = it
            }
        }
    }
} 