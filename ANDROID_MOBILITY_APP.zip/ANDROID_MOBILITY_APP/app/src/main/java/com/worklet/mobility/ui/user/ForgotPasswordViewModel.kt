package com.worklet.mobility.ui.user

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

sealed class ForgotPasswordState {
    object Loading : ForgotPasswordState()
    object Success : ForgotPasswordState()
    data class Error(val message: String) : ForgotPasswordState()
}

class ForgotPasswordViewModel : ViewModel() {

    private val auth = FirebaseAuth.getInstance()
    private val _resetState = MutableLiveData<ForgotPasswordState>()
    val resetState: LiveData<ForgotPasswordState> = _resetState

    fun sendPasswordResetEmail(email: String) {
        viewModelScope.launch {
            try {
                _resetState.value = ForgotPasswordState.Loading
                auth.sendPasswordResetEmail(email).await()
                _resetState.value = ForgotPasswordState.Success
            } catch (e: Exception) {
                _resetState.value = ForgotPasswordState.Error(
                    e.message ?: "Failed to send password reset email"
                )
            }
        }
    }
} 