package com.worklet.mobility.service

import android.app.Notification
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.worklet.mobility.R
import com.worklet.mobility.repository.JourneyRepository
import com.worklet.mobility.repository.LocationRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class JourneyTrackingService : Service() {

    @Inject
    lateinit var locationRepository: LocationRepository

    @Inject
    lateinit var journeyRepository: JourneyRepository

    @Inject
    lateinit var notificationService: NotificationService

    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())
    private var currentJourneyId: String? = null

    override fun onCreate() {
        super.onCreate()
        startForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_JOURNEY -> {
                val journeyId = intent.getStringExtra(EXTRA_JOURNEY_ID)
                startJourneyTracking(journeyId)
            }
            ACTION_STOP_JOURNEY -> {
                stopJourneyTracking()
            }
        }
        return START_STICKY
    }

    private fun startJourneyTracking(journeyId: String?) {
        if (journeyId == null) return
        currentJourneyId = journeyId

        serviceScope.launch {
            locationRepository.getLocationUpdates()
                .collect { location ->
                    // Update journey with new location
                    journeyRepository.updateJourneyLocation(journeyId, location)
                }
        }
    }

    private fun stopJourneyTracking() {
        currentJourneyId?.let { journeyId ->
            serviceScope.launch {
                journeyRepository.endJourney(journeyId)
            }
        }
        stopForeground(true)
        stopSelf()
    }

    private fun startForeground() {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Journey in Progress")
            .setContentText("Tracking your journey...")
            .setSmallIcon(R.drawable.ic_notification)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "journey_tracking"
        private const val NOTIFICATION_ID = 1
        const val ACTION_START_JOURNEY = "ACTION_START_JOURNEY"
        const val ACTION_STOP_JOURNEY = "ACTION_STOP_JOURNEY"
        const val EXTRA_JOURNEY_ID = "EXTRA_JOURNEY_ID"
    }
} 