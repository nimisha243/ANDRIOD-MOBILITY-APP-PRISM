package com.worklet.mobility.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.worklet.mobility.data.local.dao.JourneyDao
import com.worklet.mobility.data.local.dao.PaymentMethodDao
import com.worklet.mobility.data.local.dao.UserDao
import com.worklet.mobility.data.local.entity.JourneyEntity
import com.worklet.mobility.data.local.entity.PaymentMethodEntity
import com.worklet.mobility.data.local.entity.UserEntity

@Database(
    entities = [
        UserEntity::class,
        JourneyEntity::class,
        PaymentMethodEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun journeyDao(): JourneyDao
    abstract fun paymentMethodDao(): PaymentMethodDao
} 