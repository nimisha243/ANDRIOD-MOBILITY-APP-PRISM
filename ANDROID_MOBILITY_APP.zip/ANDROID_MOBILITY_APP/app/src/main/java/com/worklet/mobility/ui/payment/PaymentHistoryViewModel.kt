package com.worklet.mobility.ui.payment

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.worklet.mobility.model.Payment
import com.worklet.mobility.repository.PaymentRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PaymentHistoryViewModel @Inject constructor(
    private val paymentRepository: PaymentRepository
) : ViewModel() {

    private val _payments = MutableStateFlow<List<Payment>>(emptyList())
    val payments: StateFlow<List<Payment>> = _payments

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    init {
        loadPaymentHistory()
    }

    private fun loadPaymentHistory() {
        viewModelScope.launch {
            _isLoading.value = true
            paymentRepository.getPaymentHistory()
                .catch { e ->
                    _error.value = e.message
                    _isLoading.value = false
                }
                .collect { paymentList ->
                    _payments.value = paymentList
                    _isLoading.value = false
                }
        }
    }

    fun refreshPaymentHistory() {
        loadPaymentHistory()
    }
} 