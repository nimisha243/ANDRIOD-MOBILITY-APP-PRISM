package com.worklet.mobility.service

import android.content.Context
import androidx.work.*
import com.worklet.mobility.repository.JourneyRepository
import com.worklet.mobility.repository.UserRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SyncService @Inject constructor(
    @ApplicationContext private val context: Context,
    private val journeyRepository: JourneyRepository,
    private val userRepository: UserRepository
) {
    fun scheduleSync() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val syncRequest = PeriodicWorkRequestBuilder<SyncWorker>(
            15, TimeUnit.MINUTES,
            5, TimeUnit.MINUTES
        )
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(
                SYNC_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                syncRequest
            )
    }

    fun cancelSync() {
        WorkManager.getInstance(context)
            .cancelUniqueWork(SYNC_WORK_NAME)
    }

    companion object {
        private const val SYNC_WORK_NAME = "sync_work"
    }
}

class SyncWorker(
    context: Context,
    params: WorkerParameters,
    private val journeyRepository: JourneyRepository,
    private val userRepository: UserRepository
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            // Sync journeys
            journeyRepository.syncJourneys()

            // Sync user data
            userRepository.syncUserData()

            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
} 