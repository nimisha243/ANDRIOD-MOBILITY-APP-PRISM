package com.worklet.mobility.ui.history

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.worklet.mobility.databinding.ItemJourneyHistoryBinding
import com.worklet.mobility.model.Journey
import java.text.SimpleDateFormat
import java.util.*

class JourneyHistoryAdapter(
    private val onJourneyClick: (Journey) -> Unit
) : ListAdapter<Journey, JourneyHistoryAdapter.JourneyViewHolder>(JourneyDiffCallback()) {

    private val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JourneyViewHolder {
        val binding = ItemJourneyHistoryBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return JourneyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: JourneyViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class JourneyViewHolder(
        private val binding: ItemJourneyHistoryBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                val position = bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onJourneyClick(getItem(position))
                }
            }
        }

        fun bind(journey: Journey) {
            binding.apply {
                journeyDate.text = dateFormat.format(journey.startTime)
                journeyStatus.text = journey.status
                journeyDistance.text = String.format("%.1f km", journey.distance)
                journeyFare.text = String.format("$%.2f", journey.fare)
                journeyRoute.text = "${journey.startLocation} → ${journey.endLocation}"
            }
        }
    }

    private class JourneyDiffCallback : DiffUtil.ItemCallback<Journey>() {
        override fun areItemsTheSame(oldItem: Journey, newItem: Journey): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Journey, newItem: Journey): Boolean {
            return oldItem == newItem
        }
    }
} 