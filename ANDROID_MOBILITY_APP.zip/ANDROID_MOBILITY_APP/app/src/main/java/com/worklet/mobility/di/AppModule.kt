package com.worklet.mobility.di

import android.app.Application
import android.content.Context
import com.worklet.mobility.data.api.ApiService
import com.worklet.mobility.data.repository.JourneyRepository
import com.worklet.mobility.data.repository.UserRepository
import com.worklet.mobility.utils.PreferencesManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    
    @Provides
    @Singleton
    fun provideContext(application: Application): Context = application.applicationContext
    
    @Provides
    @Singleton
    fun providePreferencesManager(@ApplicationContext context: Context): PreferencesManager {
        return PreferencesManager(context)
    }
    
    @Provides
    @Singleton
    fun provideApiService(): ApiService {
        return ApiService.create()
    }
    
    @Provides
    @Singleton
    fun provideJourneyRepository(apiService: ApiService): JourneyRepository {
        return JourneyRepository(apiService)
    }
    
    @Provides
    @Singleton
    fun provideUserRepository(apiService: ApiService): UserRepository {
        return UserRepository(apiService)
    }
} 