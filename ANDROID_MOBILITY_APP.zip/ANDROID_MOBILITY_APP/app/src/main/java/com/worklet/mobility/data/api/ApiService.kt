package com.worklet.mobility.data.api

import com.worklet.mobility.data.model.Journey
import retrofit2.http.*

interface ApiService {
    @GET("journeys")
    suspend fun getJourneys(): List<Journey>

    @GET("journeys/{id}")
    suspend fun getJourney(@Path("id") id: String): Journey

    @POST("journeys")
    suspend fun createJourney(@Body journey: Journey): Journey

    @PUT("journeys/{id}")
    suspend fun updateJourney(@Path("id") id: String, @Body journey: Journey): Journey

    @DELETE("journeys/{id}")
    suspend fun deleteJourney(@Path("id") id: String)

    companion object {
        fun create(): ApiService {
            return retrofit2.Retrofit.Builder()
                .baseUrl(BuildConfig.API_BASE_URL)
                .addConverterFactory(retrofit2.converter.gson.GsonConverterFactory.create())
                .build()
                .create(ApiService::class.java)
        }
    }
} 