package com.worklet.mobility.ui.journey

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.maps.model.LatLng
import com.worklet.mobility.model.Journey
import com.worklet.mobility.repository.JourneyRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class ShareState {
    object Initial : ShareState()
    object Success : ShareState()
    data class Error(val message: String) : ShareState()
}

@HiltViewModel
class JourneyDetailsViewModel @Inject constructor(
    private val journeyRepository: JourneyRepository
) : ViewModel() {

    private val _journey = MutableLiveData<Journey>()
    val journey: LiveData<Journey> = _journey

    private val _shareState = MutableLiveData<ShareState>(ShareState.Initial)
    val shareState: LiveData<ShareState> = _shareState

    fun loadJourney(journeyId: String) {
        viewModelScope.launch {
            try {
                val journey = journeyRepository.getJourneyById(journeyId)
                _journey.value = journey
            } catch (e: Exception) {
                // Handle error
            }
        }
    }

    fun shareJourney() {
        viewModelScope.launch {
            try {
                _journey.value?.let { journey ->
                    // Here you would typically implement the sharing logic
                    // For now, we'll just simulate success
                    _shareState.value = ShareState.Success
                }
            } catch (e: Exception) {
                _shareState.value = ShareState.Error(e.message ?: "Failed to share journey")
            }
        }
    }
} 