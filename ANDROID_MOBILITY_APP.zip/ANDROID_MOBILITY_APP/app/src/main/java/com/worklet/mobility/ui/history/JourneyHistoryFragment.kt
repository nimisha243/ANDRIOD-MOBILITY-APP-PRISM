package com.worklet.mobility.ui.history

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.worklet.mobility.R
import com.worklet.mobility.databinding.FragmentJourneyHistoryBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class JourneyHistoryFragment : Fragment() {

    private var _binding: FragmentJourneyHistoryBinding? = null
    private val binding get() = _binding!!
    private val viewModel: JourneyHistoryViewModel by viewModels()
    private lateinit var journeyAdapter: JourneyHistoryAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentJourneyHistoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        observeViewModel()
    }

    private fun setupUI() {
        binding.apply {
            // Setup toolbar
            toolbar.setNavigationOnClickListener {
                findNavController().navigateUp()
            }

            // Setup search
            searchInput.doAfterTextChanged { text ->
                viewModel.setSearchQuery(text?.toString() ?: "")
            }
            searchInput.setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    searchInput.clearFocus()
                    true
                } else {
                    false
                }
            }

            // Setup recycler view
            journeyAdapter = JourneyHistoryAdapter { journey ->
                findNavController().navigate(
                    JourneyHistoryFragmentDirections.actionJourneyHistoryToDetails(journey.id)
                )
            }
            journeyRecyclerView.apply {
                layoutManager = LinearLayoutManager(requireContext())
                adapter = journeyAdapter
                setHasFixedSize(true)
            }

            // Setup filter buttons
            filterAllButton.setOnClickListener {
                viewModel.setFilter(JourneyFilter.ALL)
            }
            filterCompletedButton.setOnClickListener {
                viewModel.setFilter(JourneyFilter.COMPLETED)
            }
            filterCancelledButton.setOnClickListener {
                viewModel.setFilter(JourneyFilter.CANCELLED)
            }

            // Setup sort button
            sortButton.setOnClickListener {
                viewModel.toggleSortOrder()
            }

            // Setup pull to refresh
            swipeRefreshLayout.setOnRefreshListener {
                viewModel.loadJourneyHistory()
            }
        }
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.state.collectLatest { state ->
                // Update journey list
                journeyAdapter.submitList(state.journeys)
                binding.emptyStateView.visibility = if (state.journeys.isEmpty()) View.VISIBLE else View.GONE

                // Update loading state
                binding.progressBar.visibility = if (state.isLoading) View.VISIBLE else View.GONE
                binding.swipeRefreshLayout.isRefreshing = state.isLoading

                // Update filter buttons
                binding.apply {
                    filterAllButton.isSelected = state.currentFilter == JourneyFilter.ALL
                    filterCompletedButton.isSelected = state.currentFilter == JourneyFilter.COMPLETED
                    filterCancelledButton.isSelected = state.currentFilter == JourneyFilter.CANCELLED
                }

                // Update sort button
                binding.sortButton.setIconResource(
                    if (state.sortOrder) R.drawable.ic_sort_ascending else R.drawable.ic_sort_descending
                )

                // Update statistics
                state.statistics?.let { stats ->
                    binding.statisticsCard.visibility = View.VISIBLE
                    binding.apply {
                        totalJourneysText.text = getString(R.string.total_journeys, stats.totalJourneys)
                        completedJourneysText.text = getString(R.string.completed_journeys, stats.completedJourneys)
                        totalDistanceText.text = getString(R.string.total_distance, stats.totalDistance)
                        averageSpeedText.text = getString(R.string.average_speed, stats.averageSpeed)
                    }
                } ?: run {
                    binding.statisticsCard.visibility = View.GONE
                }

                // Show error if any
                state.error?.let { error ->
                    Snackbar.make(binding.root, error, Snackbar.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 