package com.worklet.mobility.ui.journey

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.snackbar.Snackbar
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.widget.Autocomplete
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import com.worklet.mobility.R
import com.worklet.mobility.databinding.FragmentJourneyBinding
import dagger.hilt.android.AndroidEntryPoint
import androidx.lifecycle.lifecycleScope
import com.worklet.mobility.data.beckn.model.SearchRequest
import com.worklet.mobility.data.beckn.model.SearchResponse
import com.worklet.mobility.data.beckn.model.ConfirmRequest
import com.worklet.mobility.data.beckn.model.ConfirmResponse
import kotlinx.coroutines.flow.collect
import com.worklet.mobility.data.payment.SamsungPayService
import android.Manifest
import android.content.pm.PackageManager
import android.os.Looper
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.worklet.mobility.data.model.JourneyStatus
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class JourneyFragment : Fragment(R.layout.fragment_journey), OnMapReadyCallback {

    private var _binding: FragmentJourneyBinding? = null
    private val binding get() = _binding!!
    private val viewModel: JourneyViewModel by viewModels()
    private var map: GoogleMap? = null
    private val AUTOCOMPLETE_REQUEST_CODE_START = 1001
    private val AUTOCOMPLETE_REQUEST_CODE_END = 1002
    private val samsungPayService = SamsungPayService()
    private lateinit var journeyAdapter: JourneyAdapter

    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 2001
    }

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentJourneyBinding.bind(view)

        if (!Places.isInitialized()) {
            Places.initialize(requireContext(), getString(R.string.google_maps_key))
        }

        setupToolbar()
        setupMap()
        setupClickListeners()
        observeViewModel()

        // Beckn: Observe search and confirm state
        lifecycleScope.launchWhenStarted {
            viewModel.becknSearchState.collect { state ->
                when (state) {
                    is JourneyViewModel.BecknSearchState.Idle -> {}
                    is JourneyViewModel.BecknSearchState.Loading -> showLoading(true)
                    is JourneyViewModel.BecknSearchState.Success -> {
                        showLoading(false)
                        showProviders(state.response)
                    }
                    is JourneyViewModel.BecknSearchState.Error -> {
                        showLoading(false)
                        showError(state.message)
                    }
                }
            }
        }
        lifecycleScope.launchWhenStarted {
            viewModel.becknConfirmState.collect { state ->
                when (state) {
                    is JourneyViewModel.BecknConfirmState.Idle -> {}
                    is JourneyViewModel.BecknConfirmState.Loading -> showLoading(true)
                    is JourneyViewModel.BecknConfirmState.Success -> {
                        showLoading(false)
                        showBookingConfirmation(state.response)
                    }
                    is JourneyViewModel.BecknConfirmState.Error -> {
                        showLoading(false)
                        showError(state.message)
                    }
                }
            }
        }

        // Example: Trigger Beckn search on a button click
        binding.searchButton.setOnClickListener {
            val request = buildSearchRequest()
            viewModel.searchRides(request)
        }

        setupRecyclerView()
    }

    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }

    private fun setupMap() {
        val mapFragment = childFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    private fun setupClickListeners() {
        binding.startLocationInput.setOnClickListener {
            launchPlacePicker(AUTOCOMPLETE_REQUEST_CODE_START)
        }

        binding.endLocationInput.setOnClickListener {
            launchPlacePicker(AUTOCOMPLETE_REQUEST_CODE_END)
        }

        binding.confirmJourneyButton.setOnClickListener {
            viewModel.confirmJourney("current_user_id")
        }
    }

    private fun setupRecyclerView() {
        journeyAdapter = JourneyAdapter(
            onJourneyClick = { journey ->
                findNavController().navigate(
                    JourneyFragmentDirections.actionJourneyFragmentToJourneyDetailsFragment(journey.id)
                )
            },
            onJourneyCancel = { journey ->
                showCancelJourneyConfirmation(journey.id)
            }
        )

        binding.journeysRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = journeyAdapter
            setHasFixedSize(true)
        }
    }

    private fun observeViewModel() {
        viewModel.uiState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is JourneyState.Loading -> showLoading(true)
                is JourneyState.LocationSelected -> {
                    showLoading(false)
                    updateLocationInputs(state)
                    updateMap(state)
                }
                is JourneyState.JourneyCreated -> {
                    showLoading(false)
                    findNavController().navigateUp()
                }
                is JourneyState.Error -> {
                    showLoading(false)
                    showError(state.message)
                }
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.journeyState.collectLatest { state ->
                when (state) {
                    is JourneyViewModel.JourneyState.Idle -> {
                        // Load journeys when the fragment is created
                        viewModel.loadJourneys("current_user_id") // Replace with actual user ID
                    }
                    is JourneyViewModel.JourneyState.Loading -> {
                        binding.progressBar.visibility = View.VISIBLE
                    }
                    is JourneyViewModel.JourneyState.Success -> {
                        binding.progressBar.visibility = View.GONE
                    }
                    is JourneyViewModel.JourneyState.Error -> {
                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(requireContext(), state.message, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.journeys.collectLatest { journeys ->
                journeyAdapter.submitList(journeys)
                binding.emptyStateView.visibility = if (journeys.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private fun updateLocationInputs(state: JourneyState.LocationSelected) {
        binding.startLocationInput.setText(state.startLocation?.address ?: "")
        binding.endLocationInput.setText(state.endLocation?.address ?: "")
        binding.distanceText.text = state.distance
        binding.estimatedFareText.text = state.estimatedFare
    }

    private fun updateMap(state: JourneyState.LocationSelected) {
        map?.let { googleMap ->
            googleMap.clear()
            
            state.startLocation?.let { location ->
                googleMap.addMarker(MarkerOptions().position(location.latLng).title("Start"))
            }
            
            state.endLocation?.let { location ->
                googleMap.addMarker(MarkerOptions().position(location.latLng).title("End"))
            }
            
            if (state.startLocation != null && state.endLocation != null) {
                val bounds = com.google.android.gms.maps.model.LatLngBounds.Builder()
                    .include(state.startLocation.latLng)
                    .include(state.endLocation.latLng)
                    .build()
                googleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 100))
            }
        }
    }

    private fun showLoading(show: Boolean) {
        binding.progressIndicator.visibility = if (show) View.VISIBLE else View.GONE
        binding.confirmJourneyButton.isEnabled = !show
    }

    private fun showError(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show()
    }

    private fun launchPlacePicker(requestCode: Int) {
        val fields = listOf(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG, Place.Field.ADDRESS)
        val intent = Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY, fields)
            .build(requireContext())
        startActivityForResult(intent, requestCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && data != null) {
            val place = Autocomplete.getPlaceFromIntent(data)
            when (requestCode) {
                AUTOCOMPLETE_REQUEST_CODE_START -> {
                    viewModel.setStartLocation(place.latLng!!, place.address ?: "")
                }
                AUTOCOMPLETE_REQUEST_CODE_END -> {
                    viewModel.setEndLocation(place.latLng!!, place.address ?: "")
                }
            }
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        viewModel.onMapReady()
    }

    private fun showCancelJourneyConfirmation(journeyId: String) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.cancel_journey)
            .setMessage(R.string.cancel_journey_confirmation)
            .setPositiveButton(R.string.cancel_journey) { _, _ ->
                viewModel.cancelJourney(journeyId)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        stopLocationTracking()
        _binding = null
    }

    // --- Beckn Helper Functions ---
    private fun buildSearchRequest(): SearchRequest {
        val startLocation = viewModel.startLocation.value
        val endLocation = viewModel.endLocation.value
        val now = java.time.Instant.now().toString()
        val transactionId = java.util.UUID.randomUUID().toString()
        val messageId = java.util.UUID.randomUUID().toString()
        return SearchRequest(
            context = SearchRequest.Context(
                country = "IN",
                city = "std:080",
                bap_id = "your-bap-id",
                bap_uri = "https://your-bap-uri",
                transaction_id = transactionId,
                message_id = messageId,
                timestamp = now
            ),
            message = SearchRequest.Message(
                intent = SearchRequest.Intent(
                    fulfillment = SearchRequest.Fulfillment(
                        start = SearchRequest.Location(
                            gps = "${startLocation?.latLng?.latitude},${startLocation?.latLng?.longitude}",
                            address = startLocation?.address
                        ),
                        end = SearchRequest.Location(
                            gps = "${endLocation?.latLng?.latitude},${endLocation?.latLng?.longitude}",
                            address = endLocation?.address
                        )
                    )
                )
            )
        )
    }

    private fun showProviders(response: SearchResponse) {
        val providers = response.message.catalog.providers
        val providerNames = providers.map { it.descriptor.name }
        AlertDialog.Builder(requireContext())
            .setTitle("Available Providers")
            .setItems(providerNames.toTypedArray()) { _, which ->
                val selectedProvider = providers[which]
                val confirmRequest = buildConfirmRequest(selectedProvider)
                viewModel.confirmRide(confirmRequest)
            }
            .show()
    }

    private fun buildConfirmRequest(provider: SearchResponse.Provider): ConfirmRequest {
        val itemId = provider.locations.firstOrNull()?.id ?: "item-1"
        val userName = "Test User"
        val userPhone = "1234567890"
        val userEmail = "test@example.com"
        // For demo, reuse the last search context and locations
        val lastContext = buildSearchRequest().context
        val startLocation = viewModel.startLocation.value
        val endLocation = viewModel.endLocation.value
        return ConfirmRequest(
            context = lastContext,
            message = ConfirmRequest.Message(
                order = ConfirmRequest.Order(
                    provider = ConfirmRequest.Provider(id = provider.id),
                    items = listOf(ConfirmRequest.Item(id = itemId)),
                    billing = ConfirmRequest.Billing(
                        name = userName,
                        phone = userPhone,
                        email = userEmail
                    ),
                    fulfillment = ConfirmRequest.Fulfillment(
                        start = SearchRequest.Location(
                            gps = "${startLocation?.latLng?.latitude},${startLocation?.latLng?.longitude}",
                            address = startLocation?.address
                        ),
                        end = SearchRequest.Location(
                            gps = "${endLocation?.latLng?.latitude},${endLocation?.latLng?.longitude}",
                            address = endLocation?.address
                        )
                    )
                )
            )
        )
    }

    private fun showBookingConfirmation(response: ConfirmResponse) {
        val order = response.message.order
        val confirmationMsg = """
            Booking Confirmed!\nProvider: ${order.provider.id}\nOrder ID: ${order.id}\nItems: ${order.items.joinToString { it.id }}\nBilling: ${order.billing.name}, ${order.billing.phone}
        """.trimIndent()
        AlertDialog.Builder(requireContext())
            .setTitle("Booking Confirmation")
            .setMessage(confirmationMsg)
            .setPositiveButton("Pay with Samsung Pay") { _, _ ->
                val fare = viewModel.estimatedFare.value ?: 0.0
                startSamsungPay(order, fare)
                checkLocationPermissionAndStartTracking()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun startSamsungPay(order: ConfirmResponse.Order, amount: Double) {
        if (amount <= 0.0) {
            showError("Invalid fare amount for payment.")
            return
        }
        if (samsungPayService.isSamsungPayAvailable(requireContext())) {
            // TODO: Build PaymentInfo and use real Samsung Pay SDK logic here
            samsungPayService.pay(requireContext(), amount) { success, errorMsg ->
                if (success) {
                    AlertDialog.Builder(requireContext())
                        .setTitle("Payment Status")
                        .setMessage("Payment successful! Your ride is confirmed.")
                        .setPositiveButton("OK", null)
                        .show()
                } else {
                    AlertDialog.Builder(requireContext())
                        .setTitle("Payment Failed")
                        .setMessage(errorMsg ?: "Payment failed. Please try again.")
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
        } else {
            showError("Samsung Pay is not available on this device.")
        }
    }

    // Call this when journey starts (e.g., after booking confirmation)
    private fun checkLocationPermissionAndStartTracking() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            startLocationTracking()
        } else {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_PERMISSION_REQUEST_CODE)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startLocationTracking()
        } else {
            showError("Location permission is required for journey tracking.")
        }
    }

    private fun startLocationTracking() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireContext())
        val locationRequest = LocationRequest.create().apply {
            interval = 5000 // 5 seconds
            fastestInterval = 2000
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        }
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                val location = locationResult.lastLocation
                if (location != null) {
                    updateUserLocationOnMap(location.latitude, location.longitude)
                    // Optionally: update backend or journey status here
                }
            }
        }
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper())
    }

    private fun stopLocationTracking() {
        if (::fusedLocationClient.isInitialized && ::locationCallback.isInitialized) {
            fusedLocationClient.removeLocationUpdates(locationCallback)
        }
    }

    private fun updateUserLocationOnMap(lat: Double, lng: Double) {
        val userLatLng = LatLng(lat, lng)
        map?.let { googleMap ->
            googleMap.addMarker(MarkerOptions().position(userLatLng).title("You"))
            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(userLatLng, 16f))
        }
    }
} 