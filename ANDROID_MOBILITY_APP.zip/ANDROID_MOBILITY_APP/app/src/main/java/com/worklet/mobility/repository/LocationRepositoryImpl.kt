package com.worklet.mobility.repository

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import androidx.core.content.ContextCompat
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.worklet.mobility.service.LocationService
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class LocationRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val locationService: LocationService
) : LocationRepository {

    override fun getLocationUpdates(): Flow<Location> {
        return locationService.getLocationUpdates()
    }

    override suspend fun addGeofence(
        latitude: Double,
        longitude: Double,
        radius: Float,
        id: String
    ) {
        val geofence = Geofence.Builder()
            .setRequestId(id)
            .setCircularRegion(latitude, longitude, radius)
            .setExpirationDuration(Geofence.NEVER_EXPIRE)
            .setTransitionTypes(GeofencingRequest.INITIAL_TRIGGER_ENTER or GeofencingRequest.INITIAL_TRIGGER_EXIT)
            .build()

        locationService.addGeofence(geofence)
    }

    override suspend fun removeGeofence(id: String) {
        locationService.removeGeofence(id)
    }

    override suspend fun onGeofenceEntered(id: String) {
        // Handle geofence enter event
        // You can update UI or trigger notifications here
    }

    override suspend fun onGeofenceExited(id: String) {
        // Handle geofence exit event
        // You can update UI or trigger notifications here
    }

    override suspend fun getLastKnownLocation(): Location? {
        return try {
            locationService.getLocationUpdates().first()
        } catch (e: Exception) {
            null
        }
    }

    override suspend fun checkLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    override suspend fun requestLocationPermission() {
        // This should be handled by the UI layer
        // The repository should not directly request permissions
    }
} 