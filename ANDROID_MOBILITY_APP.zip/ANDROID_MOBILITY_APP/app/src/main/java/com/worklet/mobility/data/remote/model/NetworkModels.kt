package com.worklet.mobility.data.remote.model

import com.google.gson.annotations.SerializedName

// Auth Models
data class LoginRequest(
    @SerializedName("email")
    val email: String,
    @SerializedName("password")
    val password: String
)

data class LoginResponse(
    @SerializedName("token")
    val token: String,
    @SerializedName("user")
    val user: UserDto
)

data class RegisterRequest(
    @SerializedName("email")
    val email: String,
    @SerializedName("password")
    val password: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("phone")
    val phone: String
)

data class RegisterResponse(
    @SerializedName("token")
    val token: String,
    @SerializedName("user")
    val user: UserDto
)

data class ForgotPasswordRequest(
    @SerializedName("email")
    val email: String
)

data class ForgotPasswordResponse(
    @SerializedName("message")
    val message: String
)

// User Models
data class UserDto(
    @SerializedName("id")
    val id: String,
    @SerializedName("email")
    val email: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("phone")
    val phone: String,
    @SerializedName("profile_image")
    val profileImage: String?
)

// Journey Models
data class LocationUpdate(
    @SerializedName("latitude")
    val latitude: Double,
    @SerializedName("longitude")
    val longitude: Double,
    @SerializedName("timestamp")
    val timestamp: Long
)

// Payment Models
data class PaymentRequest(
    @SerializedName("amount")
    val amount: Double,
    @SerializedName("currency")
    val currency: String,
    @SerializedName("payment_method")
    val paymentMethod: String,
    @SerializedName("journey_id")
    val journeyId: String
)

data class PaymentResponse(
    @SerializedName("id")
    val id: String,
    @SerializedName("status")
    val status: String,
    @SerializedName("amount")
    val amount: Double,
    @SerializedName("currency")
    val currency: String
)

data class PaymentHistory(
    @SerializedName("id")
    val id: String,
    @SerializedName("amount")
    val amount: Double,
    @SerializedName("currency")
    val currency: String,
    @SerializedName("status")
    val status: String,
    @SerializedName("timestamp")
    val timestamp: Long,
    @SerializedName("journey_id")
    val journeyId: String
)

// Sync Models
data class SyncResponse(
    @SerializedName("success")
    val success: Boolean,
    @SerializedName("message")
    val message: String,
    @SerializedName("timestamp")
    val timestamp: Long
)

data class UserSyncData(
    @SerializedName("user_id")
    val userId: String,
    @SerializedName("last_sync")
    val lastSync: Long,
    @SerializedName("device_info")
    val deviceInfo: DeviceInfo
)

data class DeviceInfo(
    @SerializedName("device_id")
    val deviceId: String,
    @SerializedName("os_version")
    val osVersion: String,
    @SerializedName("app_version")
    val appVersion: String
) 