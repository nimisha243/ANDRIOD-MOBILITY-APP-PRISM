package com.worklet.mobility.ui.user

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.worklet.mobility.R
import com.worklet.mobility.databinding.DialogEmailVerificationBinding
import com.worklet.mobility.databinding.FragmentRegisterBinding
import com.worklet.mobility.util.PasswordStrength
import com.worklet.mobility.util.ValidationUtils
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

@AndroidEntryPoint
class RegisterFragment : Fragment() {
    private var _binding: FragmentRegisterBinding? = null
    private val binding get() = _binding!!
    private val viewModel: RegisterViewModel by viewModels()
    private val googleSignInClient by lazy {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        GoogleSignIn.getClient(requireActivity(), gso)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentRegisterBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setupInputValidation()
        setupClickListeners()
        observeViewModel()
    }

    private fun setupInputValidation() {
        val validateInput = {
            val name = binding.nameInput.text.toString()
            val email = binding.emailInput.text.toString()
            val password = binding.passwordInput.text.toString()
            val confirmPassword = binding.confirmPasswordInput.text.toString()
            viewModel.validateInput(name, email, password, confirmPassword)
        }

        binding.nameInput.doAfterTextChanged { validateInput() }
        binding.emailInput.doAfterTextChanged { validateInput() }
        binding.passwordInput.doAfterTextChanged { validateInput() }
        binding.confirmPasswordInput.doAfterTextChanged { validateInput() }
    }

    private fun setupClickListeners() {
        binding.registerButton.setOnClickListener {
            val name = binding.nameInput.text.toString()
            val email = binding.emailInput.text.toString()
            val password = binding.passwordInput.text.toString()
            viewModel.register(name, email, password)
        }

        binding.googleSignInButton.setOnClickListener {
            startActivityForResult(googleSignInClient.signInIntent, RC_GOOGLE_SIGN_IN)
        }

        binding.facebookSignInButton.setOnClickListener {
            // Initialize Facebook SDK and handle login
            // This would require Facebook SDK setup
        }

        binding.loginLink.setOnClickListener {
            findNavController().navigate(R.id.action_registerFragment_to_loginFragment)
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launchWhenStarted {
            viewModel.validationState.collect { state ->
                updateValidationUI(state)
            }
        }

        lifecycleScope.launchWhenStarted {
            viewModel.registerState.collect { state ->
                when (state) {
                    is RegisterViewModel.RegisterState.Loading -> {
                        binding.progressBar.visibility = View.VISIBLE
                        binding.registerButton.isEnabled = false
                    }
                    is RegisterViewModel.RegisterState.Success -> {
                        binding.progressBar.visibility = View.GONE
                        binding.registerButton.isEnabled = true
                        showVerificationDialog(state.user.email)
                    }
                    is RegisterViewModel.RegisterState.Error -> {
                        binding.progressBar.visibility = View.GONE
                        binding.registerButton.isEnabled = true
                        Toast.makeText(requireContext(), state.message, Toast.LENGTH_LONG).show()
                    }
                    else -> {
                        binding.progressBar.visibility = View.GONE
                        binding.registerButton.isEnabled = true
                    }
                }
            }
        }
    }

    private fun updateValidationUI(state: RegisterViewModel.ValidationState) {
        binding.nameLayout.error = if (state.nameValid) null else "Invalid name"
        binding.emailLayout.error = if (state.emailValid) null else "Invalid email"
        binding.passwordLayout.error = if (state.passwordStrength != PasswordStrength.WEAK) null else "Password too weak"
        binding.confirmPasswordLayout.error = if (state.passwordsMatch) null else "Passwords don't match"

        binding.passwordStrengthText.text = when (state.passwordStrength) {
            PasswordStrength.WEAK -> "Weak"
            PasswordStrength.MEDIUM -> "Medium"
            PasswordStrength.STRONG -> "Strong"
        }
        binding.passwordStrengthText.setTextColor(
            when (state.passwordStrength) {
                PasswordStrength.WEAK -> resources.getColor(R.color.password_weak, null)
                PasswordStrength.MEDIUM -> resources.getColor(R.color.password_medium, null)
                PasswordStrength.STRONG -> resources.getColor(R.color.password_strong, null)
            }
        )
    }

    private fun showVerificationDialog(email: String) {
        val dialogBinding = DialogEmailVerificationBinding.inflate(layoutInflater)
        val dialog = AlertDialog.Builder(requireContext())
            .setView(dialogBinding.root)
            .setCancelable(false)
            .create()

        dialogBinding.resendButton.setOnClickListener {
            viewModel.resendVerificationEmail()
            Toast.makeText(requireContext(), "Verification email sent to $email", Toast.LENGTH_SHORT).show()
        }

        dialogBinding.continueButton.setOnClickListener {
            dialog.dismiss()
            findNavController().navigate(R.id.action_registerFragment_to_loginFragment)
        }

        dialog.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == RC_GOOGLE_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                val account = task.getResult(ApiException::class.java)
                account?.idToken?.let { token ->
                    viewModel.registerWithGoogle(token)
                }
            } catch (e: ApiException) {
                Toast.makeText(requireContext(), "Google sign in failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val RC_GOOGLE_SIGN_IN = 9001
    }
} 