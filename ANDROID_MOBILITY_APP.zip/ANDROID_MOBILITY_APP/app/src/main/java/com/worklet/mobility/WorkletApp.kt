package com.worklet.mobility

import android.app.Application
import com.worklet.mobility.di.AppComponent
import com.worklet.mobility.di.DaggerAppComponent

class WorkletApp : Application() {
    
    lateinit var appComponent: AppComponent
    
    override fun onCreate() {
        super.onCreate()
        initializeDependencyInjection()
    }
    
    private fun initializeDependencyInjection() {
        appComponent = DaggerAppComponent.builder()
            .application(this)
            .build()
    }
} 