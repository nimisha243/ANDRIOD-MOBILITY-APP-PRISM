package com.worklet.mobility.data.beckn.model

data class SearchResponse(
    val context: SearchRequest.Context,
    val message: Message
) {
    data class Message(
        val catalog: Catalog
    )
    data class Catalog(
        val providers: List<Provider>
    )
    data class Provider(
        val id: String,
        val descriptor: Descriptor,
        val locations: List<Location>
    )
    data class Descriptor(
        val name: String
    )
    data class Location(
        val id: String,
        val gps: String,
        val address: String?
    )
} 