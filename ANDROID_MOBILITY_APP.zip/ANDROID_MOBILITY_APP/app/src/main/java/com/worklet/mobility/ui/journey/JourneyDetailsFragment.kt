package com.worklet.mobility.ui.journey

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.PolylineOptions
import com.worklet.mobility.R
import com.worklet.mobility.databinding.FragmentJourneyDetailsBinding
import com.worklet.mobility.model.Journey
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.*

@AndroidEntryPoint
class JourneyDetailsFragment : Fragment(), OnMapReadyCallback {

    private var _binding: FragmentJourneyDetailsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: JourneyDetailsViewModel by viewModels()
    private val args: JourneyDetailsFragmentArgs by navArgs()
    private var googleMap: GoogleMap? = null
    private val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentJourneyDetailsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupMap()
        setupUI()
        observeViewModel()
        viewModel.loadJourney(args.journeyId)
    }

    private fun setupMap() {
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    private fun setupUI() {
        binding.toolbar.setNavigationOnClickListener {
            requireActivity().onBackPressed()
        }

        binding.shareButton.setOnClickListener {
            shareJourney()
        }
    }

    private fun observeViewModel() {
        viewModel.journey.observe(viewLifecycleOwner) { journey ->
            updateUI(journey)
        }

        viewModel.shareState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is ShareState.Success -> {
                    Toast.makeText(requireContext(), R.string.journey_shared, Toast.LENGTH_SHORT).show()
                }
                is ShareState.Error -> {
                    Toast.makeText(requireContext(), R.string.journey_share_failed, Toast.LENGTH_SHORT).show()
                }
                else -> {}
            }
        }
    }

    private fun updateUI(journey: Journey) {
        binding.apply {
            journeyStatus.text = journey.status
            journeyDate.text = dateFormat.format(journey.startTime)
            startLocation.text = journey.startLocation
            endLocation.text = journey.endLocation
            journeyDistance.text = getString(R.string.journey_distance, journey.distance)
            journeyFare.text = getString(R.string.journey_fare, journey.fare)

            // Update analytics
            val duration = calculateDuration(journey.startTime, journey.endTime)
            val avgSpeed = calculateAverageSpeed(journey.distance, duration)
            val calories = calculateCalories(duration, avgSpeed)

            durationText.text = getString(R.string.duration, duration)
            averageSpeedText.text = getString(R.string.average_speed, avgSpeed)
            caloriesText.text = getString(R.string.calories_burned, calories)
        }

        // Update map
        journey.route?.let { route ->
            drawRoute(route)
        }
    }

    private fun drawRoute(route: List<LatLng>) {
        googleMap?.let { map ->
            map.clear()
            map.addPolyline(
                PolylineOptions()
                    .addAll(route)
                    .color(requireContext().getColor(R.color.primary))
                    .width(12f)
            )

            // Zoom to show the entire route
            val bounds = LatLngBounds.builder()
            route.forEach { bounds.include(it) }
            map.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds.build(), 100))
        }
    }

    private fun shareJourney() {
        viewModel.journey.value?.let { journey ->
            val shareText = getString(
                R.string.share_journey_text,
                journey.startLocation,
                journey.endLocation,
                journey.distance,
                calculateDuration(journey.startTime, journey.endTime)
            )
            val shareIntent = Intent().apply {
                action = Intent.ACTION_SEND
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, shareText)
            }
            startActivity(Intent.createChooser(shareIntent, getString(R.string.share_journey)))
        }
    }

    private fun calculateDuration(startTime: Date, endTime: Date): String {
        val diff = endTime.time - startTime.time
        val hours = diff / (1000 * 60 * 60)
        val minutes = (diff % (1000 * 60 * 60)) / (1000 * 60)
        return String.format("%02d:%02d", hours, minutes)
    }

    private fun calculateAverageSpeed(distance: Double, duration: String): String {
        val (hours, minutes) = duration.split(":").map { it.toInt() }
        val totalHours = hours + minutes / 60.0
        return String.format("%.1f", distance / totalHours)
    }

    private fun calculateCalories(duration: String, avgSpeed: String): String {
        val (hours, minutes) = duration.split(":").map { it.toInt() }
        val totalHours = hours + minutes / 60.0
        val speed = avgSpeed.toDouble()
        // Rough estimation: 0.17 calories per kg per km at walking speed
        val caloriesPerKm = 0.17 * 70.0 // Assuming 70kg average weight
        return String.format("%.0f", caloriesPerKm * speed * totalHours)
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map
        viewModel.journey.value?.route?.let { route ->
            drawRoute(route)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 