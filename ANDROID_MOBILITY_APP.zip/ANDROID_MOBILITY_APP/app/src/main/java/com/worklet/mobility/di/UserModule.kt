package com.worklet.mobility.di

import com.worklet.mobility.data.local.dao.UserDao
import com.worklet.mobility.data.remote.UserApi
import com.worklet.mobility.repository.UserRepository
import com.worklet.mobility.repository.UserRepositoryImpl
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object UserModule {

    @Provides
    @Singleton
    fun provideUserRepository(
        userApi: UserApi,
        userDao: UserDao
    ): UserRepository {
        return UserRepositoryImpl(userApi, userDao)
    }
} 