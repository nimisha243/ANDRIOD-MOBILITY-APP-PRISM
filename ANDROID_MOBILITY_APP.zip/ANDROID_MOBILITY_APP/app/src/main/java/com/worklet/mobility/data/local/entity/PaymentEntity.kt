package com.worklet.mobility.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "payments")
data class PaymentEntity(
    @PrimaryKey
    val journeyId: String,
    val amount: Double,
    val currency: String,
    val status: String,
    val timestamp: Long
) 