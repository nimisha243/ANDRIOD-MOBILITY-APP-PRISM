package com.worklet.mobility.ui.payment

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.worklet.mobility.model.PaymentDetails
import com.worklet.mobility.model.SavedCard
import com.worklet.mobility.repository.PaymentRepository
import com.worklet.mobility.repository.LocationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class PaymentState {
    object Loading : PaymentState()
    object Success : PaymentState()
    data class Error(val message: String) : PaymentState()
}

enum class PaymentMethod {
    CREDIT_CARD,
    SAMSUNG_PAY
}

@HiltViewModel
class PaymentViewModel @Inject constructor(
    private val paymentRepository: PaymentRepository,
    private val locationRepository: LocationRepository
) : ViewModel() {

    private val _paymentState = MutableLiveData<PaymentState>()
    val paymentState: LiveData<PaymentState> = _paymentState

    private val _paymentDetails = MutableLiveData<PaymentDetails>()
    val paymentDetails: LiveData<PaymentDetails> = _paymentDetails

    private val _savedCards = MutableLiveData<List<SavedCard>>()
    val savedCards: LiveData<List<SavedCard>> = _savedCards

    private val _samsungPayAvailable = MutableLiveData<Boolean>()
    val samsungPayAvailable: LiveData<Boolean> = _samsungPayAvailable

    private var selectedCard: SavedCard? = null
    private var currentPaymentMethod = PaymentMethod.CREDIT_CARD

    fun loadPaymentDetails(journeyId: String) {
        viewModelScope.launch {
            try {
                val details = paymentRepository.getPaymentDetails(journeyId)
                _paymentDetails.value = details
                loadSavedCards()
                checkSamsungPayAvailability()
            } catch (e: Exception) {
                _paymentState.value = PaymentState.Error(e.message ?: "Failed to load payment details")
            }
        }
    }

    private fun loadSavedCards() {
        viewModelScope.launch {
            try {
                val cards = paymentRepository.getSavedCards()
                _savedCards.value = cards
            } catch (e: Exception) {
                _paymentState.value = PaymentState.Error(e.message ?: "Failed to load saved cards")
            }
        }
    }

    private fun checkSamsungPayAvailability() {
        viewModelScope.launch {
            try {
                val isAvailable = paymentRepository.isSamsungPayAvailable()
                _samsungPayAvailable.value = isAvailable
            } catch (e: Exception) {
                _samsungPayAvailable.value = false
            }
        }
    }

    fun setPaymentMethod(method: PaymentMethod) {
        currentPaymentMethod = method
    }

    fun selectSavedCard(position: Int) {
        selectedCard = _savedCards.value?.getOrNull(position)
    }

    fun processPayment(amount: Double) {
        viewModelScope.launch {
            _paymentState.value = PaymentState.Loading
            try {
                when (currentPaymentMethod) {
                    PaymentMethod.CREDIT_CARD -> {
                        selectedCard?.let { card ->
                            paymentRepository.processCreditCardPayment(card, amount)
                        } ?: run {
                            throw Exception("No card selected")
                        }
                    }
                    PaymentMethod.SAMSUNG_PAY -> {
                        paymentRepository.processSamsungPayPayment(amount)
                    }
                }
                _paymentState.value = PaymentState.Success
            } catch (e: Exception) {
                _paymentState.value = PaymentState.Error(e.message ?: "Payment failed")
            }
        }
    }

    fun deleteSelectedCard() {
        viewModelScope.launch {
            try {
                selectedCard?.let { card ->
                    paymentRepository.deleteCard(card)
                    loadSavedCards()
                }
            } catch (e: Exception) {
                _paymentState.value = PaymentState.Error(e.message ?: "Failed to delete card")
            }
        }
    }

    fun getLocationUpdates() {
        viewModelScope.launch {
            locationRepository.getLocationUpdates()
                .collect { location ->
                    // Handle location update
                }
        }
    }

    fun addGeofence() {
        viewModelScope.launch {
            try {
                locationRepository.addGeofence(
                    latitude = 37.4220,
                    longitude = -122.0841,
                    radius = 100f,
                    id = "geofence1"
                )
            } catch (e: Exception) {
                _paymentState.value = PaymentState.Error(e.message ?: "Failed to add geofence")
            }
        }
    }
} 
} 