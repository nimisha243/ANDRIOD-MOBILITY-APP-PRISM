package com.worklet.mobility.di

import android.content.Context
import androidx.room.Room
import com.worklet.mobility.data.local.AppDatabase
import com.worklet.mobility.data.local.dao.JourneyDao
import com.worklet.mobility.data.local.dao.PaymentMethodDao
import com.worklet.mobility.data.local.dao.UserDao
import com.worklet.mobility.data.remote.UserApi
import com.worklet.mobility.data.repository.UserRepository
import com.worklet.mobility.data.repository.UserRepositoryImpl
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideAppDatabase(
        @ApplicationContext context: Context
    ): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "mobility.db"
        ).build()
    }

    @Provides
    fun provideUserDao(database: AppDatabase): UserDao {
        return database.userDao()
    }

    @Provides
    fun provideJourneyDao(database: AppDatabase): JourneyDao {
        return database.journeyDao()
    }

    @Provides
    fun providePaymentMethodDao(database: AppDatabase): PaymentMethodDao {
        return database.paymentMethodDao()
    }

    @Provides
    @Singleton
    fun provideUserApi(retrofit: Retrofit): UserApi {
        return retrofit.create(UserApi::class.java)
    }

    @Provides
    @Singleton
    fun provideUserRepository(
        userDao: UserDao,
        userApi: UserApi
    ): UserRepository {
        return UserRepositoryImpl(userDao, userApi)
    }
} 