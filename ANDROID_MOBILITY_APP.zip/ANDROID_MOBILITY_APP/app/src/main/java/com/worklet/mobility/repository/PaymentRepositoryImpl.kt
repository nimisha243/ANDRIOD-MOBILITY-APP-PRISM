package com.worklet.mobility.repository

import com.worklet.mobility.data.local.dao.PaymentDao
import com.worklet.mobility.data.remote.PaymentApi
import com.worklet.mobility.model.PaymentDetails
import com.worklet.mobility.model.PaymentStatus
import com.worklet.mobility.model.SavedCard
import com.worklet.mobility.model.mapper.toEntity
import com.worklet.mobility.model.mapper.toPaymentDetails
import javax.inject.Inject

class PaymentRepositoryImpl @Inject constructor(
    private val paymentApi: PaymentApi,
    private val paymentDao: PaymentDao
) : PaymentRepository {

    override suspend fun getPaymentDetails(journeyId: String): PaymentDetails {
        // Try to get from local database first
        val localPayment = paymentDao.getPaymentByJourneyId(journeyId)
        if (localPayment != null) {
            return localPayment.toPaymentDetails()
        }

        // If not found locally, fetch from API
        val remotePayment = paymentApi.getPaymentDetails(journeyId)
        
        // Save to local database
        paymentDao.insertPayment(remotePayment.toEntity())
        
        return remotePayment
    }

    override suspend fun getSavedCards(): List<SavedCard> {
        return paymentDao.getSavedCards()
    }

    override suspend fun isSamsungPayAvailable(): Boolean {
        return paymentApi.isSamsungPayAvailable()
    }

    override suspend fun processCreditCardPayment(card: SavedCard, amount: Double) {
        val response = paymentApi.processCreditCardPayment(card, amount)
        if (!response.isSuccessful) {
            throw Exception(response.errorMessage ?: "Payment failed")
        }
        
        // Update payment status in local database
        val payment = paymentDao.getPaymentByJourneyId(card.id)
        payment?.let {
            paymentDao.updatePayment(it.copy(status = PaymentStatus.COMPLETED.name))
        }
    }

    override suspend fun processSamsungPayPayment(amount: Double) {
        val response = paymentApi.processSamsungPayPayment(amount)
        if (!response.isSuccessful) {
            throw Exception(response.errorMessage ?: "Payment failed")
        }
        
        // Update payment status in local database
        // Note: In a real app, we would need the journeyId here
        // For now, we'll just log that the payment was successful
    }

    override suspend fun deleteCard(card: SavedCard) {
        paymentDao.deleteCard(card)
    }

    override suspend fun saveCard(card: SavedCard) {
        paymentDao.insertCard(card)
    }
    
    suspend fun getAllPayments(): List<PaymentDetails> {
        return paymentDao.getAllPayments().map { it.toPaymentDetails() }
    }
    
    suspend fun getPaymentsByStatus(status: PaymentStatus): List<PaymentDetails> {
        return paymentDao.getPaymentsByStatus(status.name).map { it.toPaymentDetails() }
    }
} 