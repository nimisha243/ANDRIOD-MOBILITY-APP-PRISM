package com.worklet.mobility.repository

import com.worklet.mobility.data.beckn.model.*

interface BecknRepository {
    suspend fun searchRides(request: SearchRequest): Result<SearchResponse>
    suspend fun confirmRide(request: ConfirmRequest): Result<ConfirmResponse>
    suspend fun cancelRide(request: CancelRequest): Result<CancelResponse>
    suspend fun trackRide(request: TrackRequest): Result<TrackResponse>
    suspend fun rateRide(request: RateRequest): Result<RateResponse>
    suspend fun getRideHistory(request: HistoryRequest): Result<HistoryResponse>
} 