package com.worklet.mobility.ui.payment

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.samsung.android.sdk.samsungpay.v2.card.Card
import com.worklet.mobility.databinding.ItemCardBinding

class CardAdapter(
    private val onCardSelected: (Card) -> Unit,
    private val onCardDeleted: (Card) -> Unit
) : ListAdapter<Card, CardAdapter.CardViewHolder>(CardDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardViewHolder {
        val binding = ItemCardBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return CardViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CardViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class CardViewHolder(
        private val binding: ItemCardBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(card: Card) {
            binding.cardNumberText.text = formatCardNumber(card.cardNumber)
            binding.cardTypeText.text = card.cardType
            binding.cardTypeIcon.setImageResource(getCardTypeIcon(card.cardType))

            binding.root.setOnClickListener {
                onCardSelected(card)
            }

            binding.deleteButton.setOnClickListener {
                onCardDeleted(card)
            }
        }

        private fun formatCardNumber(cardNumber: String): String {
            return "•••• ${cardNumber.takeLast(4)}"
        }

        private fun getCardTypeIcon(cardType: String): Int {
            return when (cardType.lowercase()) {
                "visa" -> com.worklet.mobility.R.drawable.ic_visa
                "mastercard" -> com.worklet.mobility.R.drawable.ic_mastercard
                "amex" -> com.worklet.mobility.R.drawable.ic_amex
                else -> com.worklet.mobility.R.drawable.ic_credit_card
            }
        }
    }

    private class CardDiffCallback : DiffUtil.ItemCallback<Card>() {
        override fun areItemsTheSame(oldItem: Card, newItem: Card): Boolean {
            return oldItem.cardId == newItem.cardId
        }

        override fun areContentsTheSame(oldItem: Card, newItem: Card): Boolean {
            return oldItem == newItem
        }
    }
} 