package com.worklet.mobility.data.remote

import com.worklet.mobility.model.Journey
import com.worklet.mobility.model.JourneyStatus
import retrofit2.http.*

interface JourneyApi {
    @GET("journeys/history")
    suspend fun getJourneyHistory(): List<Journey>

    @GET("journeys/{id}")
    suspend fun getJourneyById(@Path("id") id: String): Journey

    @PUT("journeys/{id}/status")
    suspend fun updateJourneyStatus(
        @Path("id") id: String,
        @Body status: JourneyStatus
    ): Journey

    @DELETE("journeys/{id}")
    suspend fun deleteJourney(@Path("id") id: String)
} 