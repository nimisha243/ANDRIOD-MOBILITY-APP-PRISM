package com.worklet.mobility.model

data class PaymentDetails(
    val journeyId: String,
    val amount: Double,
    val currency: String = "USD",
    val status: PaymentStatus = PaymentStatus.PENDING,
    val timestamp: Long = System.currentTimeMillis()
)

enum class PaymentStatus {
    PENDING,
    PROCESSING,
    COMPLETED,
    FAILED,
    REFUNDED
} 