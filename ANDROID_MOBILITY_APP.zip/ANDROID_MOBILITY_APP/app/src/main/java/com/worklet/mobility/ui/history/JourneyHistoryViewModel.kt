package com.worklet.mobility.ui.history

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.worklet.mobility.model.Journey
import com.worklet.mobility.repository.JourneyRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class JourneyFilter {
    ALL,
    COMPLETED,
    CANCELLED
}

data class JourneyHistoryState(
    val journeys: List<Journey> = emptyList(),
    val isLoading: Boolean = false,
    val currentFilter: JourneyFilter = JourneyFilter.ALL,
    val sortOrder: Boolean = true, // true for ascending
    val searchQuery: String = "",
    val statistics: JourneyStatistics? = null,
    val error: String? = null
)

@HiltViewModel
class JourneyHistoryViewModel @Inject constructor(
    private val journeyRepository: JourneyRepository
) : ViewModel() {

    private val _state = MutableStateFlow(JourneyHistoryState())
    val state: StateFlow<JourneyHistoryState> = _state

    private var allJourneys: List<Journey> = emptyList()

    init {
        loadJourneyHistory()
    }

    fun loadJourneyHistory() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            try {
                allJourneys = journeyRepository.getJourneyHistory()
                val statistics = journeyRepository.getJourneyStatistics()
                applyFilterAndSort()
                _state.value = _state.value.copy(
                    isLoading = false,
                    statistics = statistics
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    isLoading = false,
                    error = e.message ?: "Failed to load journey history"
                )
            }
        }
    }

    fun setFilter(filter: JourneyFilter) {
        _state.value = _state.value.copy(currentFilter = filter)
        applyFilterAndSort()
    }

    fun toggleSortOrder() {
        _state.value = _state.value.copy(sortOrder = !_state.value.sortOrder)
        applyFilterAndSort()
    }

    fun setSearchQuery(query: String) {
        _state.value = _state.value.copy(searchQuery = query)
        applyFilterAndSort()
    }

    private fun applyFilterAndSort() {
        val filteredJourneys = when (_state.value.currentFilter) {
            JourneyFilter.ALL -> allJourneys
            JourneyFilter.COMPLETED -> allJourneys.filter { it.status == "COMPLETED" }
            JourneyFilter.CANCELLED -> allJourneys.filter { it.status == "CANCELLED" }
        }

        val searchFilteredJourneys = if (_state.value.searchQuery.isNotEmpty()) {
            filteredJourneys.filter { journey ->
                journey.startLocation.contains(_state.value.searchQuery, ignoreCase = true) ||
                journey.endLocation.contains(_state.value.searchQuery, ignoreCase = true)
            }
        } else {
            filteredJourneys
        }

        val sortedJourneys = if (_state.value.sortOrder) {
            searchFilteredJourneys.sortedByDescending { it.startTime }
        } else {
            searchFilteredJourneys.sortedBy { it.startTime }
        }

        _state.value = _state.value.copy(journeys = sortedJourneys)
    }
} 