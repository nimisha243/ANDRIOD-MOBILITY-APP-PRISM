package com.worklet.mobility.network.api

import com.worklet.mobility.model.Journey
import com.worklet.mobility.model.PaymentMethod
import com.worklet.mobility.model.User
import com.worklet.mobility.model.UserSettings
import retrofit2.Response
import retrofit2.http.*

interface ApiService {
    @POST("auth/login")
    suspend fun login(@Body credentials: LoginRequest): Response<LoginResponse>

    @POST("auth/register")
    suspend fun register(@Body user: RegisterRequest): Response<RegisterResponse>

    @POST("auth/forgot-password")
    suspend fun forgotPassword(@Body request: ForgotPasswordRequest): Response<ForgotPasswordResponse>

    @GET("user/profile")
    suspend fun getUserProfile(): Response<User>

    @PUT("user/profile")
    suspend fun updateUserProfile(@Body user: User): Response<User>

    @GET("user/settings")
    suspend fun getUserSettings(): Response<UserSettings>

    @PUT("user/settings/notifications")
    suspend fun updateNotificationPreference(@Body enabled: Boolean): Response<Unit>

    @PUT("user/settings/dark-mode")
    suspend fun updateDarkModePreference(@Body enabled: Boolean): Response<Unit>

    @GET("journeys")
    suspend fun getJourneys(): Response<List<Journey>>

    @GET("journeys/{id}")
    suspend fun getJourneyDetails(@Path("id") journeyId: String): Response<Journey>

    @POST("journeys")
    suspend fun createJourney(@Body journey: Journey): Response<Journey>

    @PUT("journeys/{id}/cancel")
    suspend fun cancelJourney(@Path("id") journeyId: String): Response<Journey>

    @GET("payment/methods")
    suspend fun getPaymentMethods(): Response<List<PaymentMethod>>

    @POST("payment/methods")
    suspend fun addPaymentMethod(@Body paymentMethod: PaymentMethod): Response<PaymentMethod>

    @DELETE("payment/methods/{id}")
    suspend fun deletePaymentMethod(@Path("id") paymentMethodId: String): Response<Unit>
}

data class LoginRequest(
    val email: String,
    val password: String
)

data class LoginResponse(
    val token: String,
    val user: User
)

data class RegisterRequest(
    val name: String,
    val email: String,
    val password: String,
    val phone: String
)

data class RegisterResponse(
    val token: String,
    val user: User
)

data class ForgotPasswordRequest(
    val email: String
)

data class ForgotPasswordResponse(
    val message: String
) 