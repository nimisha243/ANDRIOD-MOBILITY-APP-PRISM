package com.worklet.mobility.data.beckn.api

import com.worklet.mobility.data.beckn.model.*
import retrofit2.http.*

interface BecknApiService {
    @POST("search")
    suspend fun search(@Body request: SearchRequest): SearchResponse

    @POST("select")
    suspend fun select(@Body request: SelectRequest): SelectResponse

    @POST("init")
    suspend fun initialize(@Body request: InitializeRequest): InitializeResponse

    @POST("confirm")
    suspend fun confirm(@Body request: ConfirmRequest): ConfirmResponse

    @POST("update")
    suspend fun update(@Body request: UpdateRequest): UpdateResponse

    @POST("cancel")
    suspend fun cancel(@Body request: CancelRequest): CancelResponse

    @POST("status")
    suspend fun status(@Body request: StatusRequest): StatusResponse

    @POST("track")
    suspend fun track(@Body request: TrackRequest): TrackResponse

    companion object {
        fun create(): BecknApiService {
            return retrofit2.Retrofit.Builder()
                .baseUrl(BuildConfig.BECKN_API_BASE_URL)
                .addConverterFactory(retrofit2.converter.gson.GsonConverterFactory.create())
                .build()
                .create(BecknApiService::class.java)
        }
    }
} 