package com.worklet.mobility.data.remote

import com.worklet.mobility.model.User
import com.worklet.mobility.model.UserSettings
import retrofit2.http.*

// Data classes for auth
data class RegisterRequest(val name: String, val email: String, val password: String)
data class RegisterResponse(val user: User, val token: String)
data class LoginRequest(val email: String, val password: String)
data class LoginResponse(val user: User, val token: String)
data class SocialAuthRequest(val token: String)
data class UpdateProfileRequest(val name: String, val email: String)
data class ApiResponse(val success: Boolean, val message: String?)

interface UserApi {
    @POST("users")
    suspend fun register(@Body request: RegisterRequest): RegisterResponse

    @POST("auth/google")
    suspend fun registerWithGoogle(@Body request: SocialAuthRequest): RegisterResponse

    @POST("auth/facebook")
    suspend fun registerWithFacebook(@Body request: SocialAuthRequest): RegisterResponse

    @POST("auth/login")
    suspend fun login(@Body request: LoginRequest): LoginResponse

    @GET("users/{userId}")
    suspend fun getUser(@Path("userId") userId: String): User

    @PUT("users/{userId}")
    suspend fun updateUser(@Path("userId") userId: String, @Body user: User): User

    @PUT("users/{userId}/settings")
    suspend fun updateUserSettings(
        @Path("userId") userId: String,
        @Body settings: UserSettings
    ): UserSettings

    @GET("users/{userId}/settings")
    suspend fun getUserSettings(@Path("userId") userId: String): UserSettings

    @DELETE("users/{userId}")
    suspend fun deleteUser(@Path("userId") userId: String): ApiResponse

    @POST("auth/verify-email")
    suspend fun verifyEmail(@Query("token") token: String): ApiResponse

    @POST("auth/resend-verification")
    suspend fun resendVerificationEmail(): ApiResponse

    @POST("auth/reset-password")
    suspend fun resetPassword(@Query("email") email: String): ApiResponse

    @PUT("users/{userId}/profile-picture")
    suspend fun updateProfilePicture(
        @Path("userId") userId: String,
        @Query("imageUrl") imageUrl: String
    ): User

    @POST("auth/logout")
    suspend fun logout(): ApiResponse
} 