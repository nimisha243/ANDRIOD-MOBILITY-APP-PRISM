package com.worklet.mobility.data.local.dao

import androidx.room.*
import com.worklet.mobility.data.local.entity.PaymentEntity
import com.worklet.mobility.model.SavedCard

@Dao
interface PaymentDao {
    @Query("SELECT * FROM saved_cards")
    suspend fun getSavedCards(): List<SavedCard>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCard(card: SavedCard)

    @Delete
    suspend fun deleteCard(card: SavedCard)

    @Query("SELECT * FROM payments WHERE journeyId = :journeyId")
    suspend fun getPaymentByJourneyId(journeyId: String): PaymentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: PaymentEntity)

    @Update
    suspend fun updatePayment(payment: PaymentEntity)

    @Query("SELECT * FROM payments ORDER BY timestamp DESC")
    suspend fun getAllPayments(): List<PaymentEntity>

    @Query("SELECT * FROM payments WHERE status = :status ORDER BY timestamp DESC")
    suspend fun getPaymentsByStatus(status: String): List<PaymentEntity>
} 