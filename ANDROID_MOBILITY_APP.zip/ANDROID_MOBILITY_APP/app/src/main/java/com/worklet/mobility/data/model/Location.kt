package com.worklet.mobility.data.model

import com.google.android.gms.maps.model.LatLng

data class Location(
    val latLng: LatLng,
    val address: String
) 