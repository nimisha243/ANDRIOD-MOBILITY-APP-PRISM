package com.worklet.mobility.ui.journey

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import com.worklet.mobility.databinding.FragmentJourneyDetailBinding
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat
import java.util.*

@AndroidEntryPoint
class JourneyDetailFragment : Fragment() {
    private var _binding: FragmentJourneyDetailBinding? = null
    private val binding get() = _binding!!
    private val viewModel: JourneyDetailViewModel by viewModels()
    private val args: JourneyDetailFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentJourneyDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        observeViewModel()
        viewModel.loadJourney(args.journeyId)
    }

    private fun observeViewModel() {
        viewModel.journey.observe(viewLifecycleOwner) { journey ->
            binding.startLocationDetail.text = journey.startLocation.address
            binding.endLocationDetail.text = journey.endLocation.address
            binding.distanceDetail.text = String.format("%.2f km", journey.distance)
            binding.fareDetail.text = String.format("$%.2f", journey.estimatedFare)
            binding.timestampDetail.text = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(journey.timestamp))
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 