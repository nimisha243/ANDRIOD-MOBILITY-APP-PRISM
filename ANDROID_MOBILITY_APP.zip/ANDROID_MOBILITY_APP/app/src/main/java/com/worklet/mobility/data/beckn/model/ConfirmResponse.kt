package com.worklet.mobility.data.beckn.model

data class ConfirmResponse(
    val context: SearchRequest.Context,
    val message: Message
) {
    data class Message(
        val order: Order
    )
    data class Order(
        val id: String,
        val provider: ConfirmRequest.Provider,
        val items: List<ConfirmRequest.Item>,
        val billing: ConfirmRequest.Billing,
        val fulfillment: ConfirmRequest.Fulfillment
    )
} 