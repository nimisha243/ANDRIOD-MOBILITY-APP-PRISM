package com.worklet.mobility.data.beckn

import com.worklet.mobility.data.beckn.model.*
import com.worklet.mobility.data.beckn.api.BecknApiService
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BecknRepository @Inject constructor(
    private val becknApiService: BecknApiService
) {
    suspend fun searchRides(request: SearchRequest): Result<SearchResponse> {
        return try {
            val response = becknApiService.search(request)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun confirmRide(request: ConfirmRequest): Result<ConfirmResponse> {
        return try {
            val response = becknApiService.confirm(request)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun initializeRide(request: InitializeRequest): Result<InitializeResponse> {
        return try {
            val response = becknApiService.initialize(request)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun selectRide(request: SelectRequest): Result<SelectResponse> {
        return try {
            val response = becknApiService.select(request)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateRide(request: UpdateRequest): Result<UpdateResponse> {
        return try {
            val response = becknApiService.update(request)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun cancelRide(request: CancelRequest): Result<CancelResponse> {
        return try {
            val response = becknApiService.cancel(request)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
} 