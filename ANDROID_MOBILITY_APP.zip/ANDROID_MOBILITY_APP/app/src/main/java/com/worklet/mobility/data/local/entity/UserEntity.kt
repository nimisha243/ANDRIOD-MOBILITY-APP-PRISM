package com.worklet.mobility.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.worklet.mobility.model.User
import java.util.Date

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val email: String,
    val phone: String,
    val profilePictureUrl: String?,
    val createdAt: Date,
    val updatedAt: Date
) {
    fun toUser(): User {
        return User(
            id = id,
            name = name,
            email = email,
            phone = phone,
            profilePictureUrl = profilePictureUrl,
            createdAt = createdAt,
            updatedAt = updatedAt
        )
    }

    companion object {
        fun fromUser(user: User): UserEntity {
            return UserEntity(
                id = user.id,
                name = user.name,
                email = user.email,
                phone = user.phone,
                profilePictureUrl = user.profilePictureUrl,
                createdAt = user.createdAt,
                updatedAt = user.updatedAt
            )
        }
    }
} 