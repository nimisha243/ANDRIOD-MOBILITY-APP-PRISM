package com.worklet.mobility.repository

import com.worklet.mobility.model.Journey
import com.worklet.mobility.model.JourneyStatus
import kotlinx.coroutines.flow.Flow

interface JourneyRepository {
    suspend fun getJourneyHistory(): List<Journey>
    suspend fun getJourneyById(id: String): Journey?
    suspend fun saveJourney(journey: Journey)
    suspend fun updateJourney(journey: Journey)
    suspend fun deleteJourney(journey: Journey)
    fun observeJourneyHistory(): Flow<List<Journey>>
    fun observeJourneyById(id: String): Flow<Journey?>
    suspend fun updateJourneyStatus(id: String, status: JourneyStatus)
    suspend fun getJourneyStatistics(): JourneyStatistics
}

data class JourneyStatistics(
    val totalJourneys: Int,
    val completedJourneys: Int,
    val cancelledJourneys: Int,
    val totalDistance: Double,
    val totalDuration: Long,
    val averageSpeed: Double
) 